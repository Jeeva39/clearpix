"""ClearPix background-removal API.

Real AI segmentation using rembg (U^2-Net family of ONNX models).
"""

from __future__ import annotations

import asyncio
import io
import logging
import os
import shutil
import tempfile
import time
import zipfile
from collections import defaultdict, deque
from pathlib import Path

# Load backend/.env in local and container runs. Real environment variables keep
# precedence, so platform configuration is never overwritten.
try:
    from dotenv import load_dotenv

    load_dotenv()
except ImportError:  # pragma: no cover - optional dependency guard
    pass

from fastapi import FastAPI, File, Form, Request, UploadFile
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, Response
from PIL import Image, ImageOps, UnidentifiedImageError

logging.basicConfig(level=os.getenv("LOG_LEVEL", "INFO"))
logger = logging.getLogger("clearpix")

MAX_UPLOAD_BYTES = int(os.getenv("MAX_UPLOAD_BYTES", str(10 * 1024 * 1024)))
MAX_IMAGES = int(os.getenv("MAX_BATCH_IMAGES", "5"))
MAX_PIXELS = int(os.getenv("MAX_IMAGE_PIXELS", str(40_000_000)))
MIN_DIMENSION = 16
MAX_DIMENSION = int(os.getenv("MAX_IMAGE_DIMENSION", "12000"))
PROCESS_TIMEOUT = int(os.getenv("PROCESS_TIMEOUT_SECONDS", "180"))
MAX_CONCURRENT = int(os.getenv("MAX_CONCURRENT_JOBS", "2"))
MODEL_NAME = os.getenv("REMBG_MODEL", "u2net")
PORTRAIT_MODEL = os.getenv("REMBG_PORTRAIT_MODEL", "u2net_human_seg")
TEMP_ROOT = os.getenv("TEMP_DIR") or tempfile.gettempdir()
ALLOWED_MIME = {"image/jpeg", "image/png", "image/webp"}
ALLOWED_FORMATS = {"JPEG", "PNG", "WEBP"}
MAX_PIXELS_GUARD = 50_000_000
Image.MAX_IMAGE_PIXELS = MAX_PIXELS_GUARD

DEFAULT_ORIGINS = ",".join(
    f"http://{host}:{port}"
    for port in (3000, 4173, 5173, 8000, 8080)
    for host in ("localhost", "127.0.0.1")
)

ALLOWED_ORIGINS = [
    origin.strip()
    for origin in os.getenv("ALLOWED_ORIGINS", DEFAULT_ORIGINS).split(",")
    if origin.strip()
]
# Optional extra origins by pattern. Disabled by default: production CORS is the
# explicit ALLOWED_ORIGINS allowlist. Set this only for hosts that need pattern
# matching (for example temporary preview deployments on your own domain).
ALLOWED_ORIGIN_REGEX = os.getenv("ALLOWED_ORIGIN_REGEX", "")

app = FastAPI(
    title="ClearPix API",
    version="1.0.0",
    description="Free AI background removal. Upload an image, receive a transparent PNG.",
    docs_url="/api/docs",
    openapi_url="/api/openapi.json",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=ALLOWED_ORIGINS,
    allow_origin_regex=ALLOWED_ORIGIN_REGEX or None,
    allow_credentials=False,
    allow_methods=["GET", "POST", "OPTIONS"],
    allow_headers=["*"],
    expose_headers=["X-Processing-Ms", "Retry-After", "X-Batch-Failures"],
    max_age=86400,
)

_jobs = asyncio.Semaphore(MAX_CONCURRENT)
_sessions: dict[str, object] = {}
_session_lock = asyncio.Lock()

_rate_windows: dict[str, deque[float]] = defaultdict(deque)
_rate_lock = asyncio.Lock()
RATE_LIMIT_REQUESTS = int(os.getenv("RATE_LIMIT_REQUESTS", "20"))
RATE_LIMIT_WINDOW = int(os.getenv("RATE_LIMIT_WINDOW_SECONDS", "600"))


class ApiError(Exception):
    def __init__(self, status: int, code: str, message: str, retry_after: int | None = None):
        self.status = status
        self.code = code
        self.message = message
        self.retry_after = retry_after
        super().__init__(message)


@app.exception_handler(ApiError)
async def api_error_handler(_: Request, exc: ApiError) -> JSONResponse:
    headers = {"Retry-After": str(exc.retry_after)} if exc.retry_after else None
    return JSONResponse(
        status_code=exc.status,
        headers=headers,
        content={"error": {"code": exc.code, "message": exc.message}},
    )


@app.exception_handler(RequestValidationError)
async def validation_error_handler(_: Request, exc: RequestValidationError) -> JSONResponse:
    missing = [
        error.get("loc", ["body"])[-1]
        for error in exc.errors()
        if error.get("type") in {"missing", "value_error"}
    ]
    message = (
        f"Please include a file in the '{missing[0]}' field."
        if missing
        else "The request could not be read. Please check the file and try again."
    )
    return JSONResponse(status_code=422, content={"error": {"code": "invalid_request", "message": message}})


@app.exception_handler(Exception)
async def unhandled_error_handler(_: Request, exc: Exception) -> JSONResponse:
    logger.exception("Unhandled error: %s", exc)
    return JSONResponse(
        status_code=500,
        content={
            "error": {
                "code": "processing_failed",
                "message": "We could not process this image. Please try again.",
            }
        },
    )


def client_ip(request: Request) -> str:
    forwarded = request.headers.get("x-forwarded-for")
    if forwarded:
        return forwarded.split(",")[0].strip()
    return request.client.host if request.client else "unknown"


async def enforce_rate_limit(request: Request, limit: int, window: int) -> None:
    ip = client_ip(request)
    now = time.monotonic()
    async with _rate_lock:
        bucket = _rate_windows[ip]
        while bucket and now - bucket[0] > window:
            bucket.popleft()
        if len(bucket) >= limit:
            retry_after = max(1, int(window - (now - bucket[0])))
            raise ApiError(
                429,
                "rate_limited",
                "You have reached the request limit. Please wait a moment and try again.",
                retry_after=retry_after,
            )
        bucket.append(now)


async def get_session(model: str):
    """Lazily load one rembg session per model name (thread-safe enough for our use)."""
    async with _session_lock:
        if model in _sessions:
            return _sessions[model]

        def load():
            from rembg import new_session

            return new_session(model)

        try:
            session = await asyncio.to_thread(load)
        except Exception as exc:  # pragma: no cover - depends on runtime env
            logger.exception("Failed to load model %s", model)
            raise ApiError(
                503,
                "model_unavailable",
                "The AI model is unavailable right now. Please try again shortly.",
            ) from exc
        _sessions[model] = session
        return session


def read_limited(upload: UploadFile, limit: int) -> bytes:
    upload.file.seek(0, os.SEEK_END)
    size = upload.file.tell()
    upload.file.seek(0)
    if size == 0:
        raise ApiError(400, "empty_file", "That file looks empty. Please choose another image.")
    if size > limit:
        raise ApiError(
            413,
            "file_too_large",
            "Your image is too large. Please upload an image smaller than 10 MB.",
        )
    return upload.file.read(limit + 1)


def validate_and_prepare(data: bytes, content_type: str | None, path: Path) -> tuple[int, int]:
    """Write bytes to a private temp file and validate it by content, not by name."""
    declared = (content_type or "").split(";")[0].strip().lower()
    if declared and declared not in ALLOWED_MIME and declared != "application/octet-stream":
        raise ApiError(
            415,
            "unsupported_type",
            "Unsupported file type. Please upload a JPG, JPEG, PNG, or WEBP image.",
        )

    path.write_bytes(data)

    try:
        with Image.open(path) as probe:
            image_format = probe.format
            width, height = probe.size
    except (UnidentifiedImageError, OSError, ValueError):
        raise ApiError(
            415,
            "invalid_image",
            "That file is not a valid image, or it is corrupted. Please choose another image.",
        )

    if image_format not in ALLOWED_FORMATS:
        raise ApiError(
            415,
            "unsupported_type",
            "Unsupported file type. Please upload a JPG, JPEG, PNG, or WEBP image.",
        )

    with Image.open(path) as probe:
        width, height = probe.size
        if width < MIN_DIMENSION or height < MIN_DIMENSION:
            raise ApiError(
                422,
                "image_too_small",
                f"That image is too small. Please use an image at least {MIN_DIMENSION}x{MIN_DIMENSION} pixels.",
            )
        if width > MAX_DIMENSION or height > MAX_DIMENSION:
            raise ApiError(
                422,
                "image_dimensions_too_large",
                f"That image is too large to process. Maximum dimensions are {MAX_DIMENSION}x{MAX_DIMENSION} pixels.",
            )
        if width * height > MAX_PIXELS:
            raise ApiError(
                422,
                "image_dimensions_too_large",
                "That image has too many pixels to process. Please resize it and try again.",
            )
        try:
            probe.load()
        except Exception:
            raise ApiError(
                415,
                "invalid_image",
                "That image could not be read. It may be corrupted. Please try another file.",
            )

    return width, height


def normalise_image(path: Path) -> None:
    """Apply EXIF orientation and flatten exotic modes so the model sees correct pixels."""
    with Image.open(path) as image:
        fixed = ImageOps.exif_transpose(image)
        if fixed.mode not in ("RGB", "RGBA", "L"):
            fixed = fixed.convert("RGBA")
        if fixed.mode == "L":
            fixed = fixed.convert("RGB")
        fixed.save(path, format="PNG")


def run_removal(path: Path, model: str, alpha_matting: bool = False) -> bytes:
    from rembg import remove

    session = _sessions.get(model)
    if session is None:
        raise ApiError(503, "model_unavailable", "The AI model is not ready yet. Please try again.")

    with Image.open(path) as image:
        source = image.copy()

    payload = io.BytesIO()
    source.save(payload, format="PNG")
    result = remove(
        payload.getvalue(),
        session=session,
        alpha_matting=alpha_matting,
        alpha_matting_foreground_threshold=270 if alpha_matting else 240,
        alpha_matting_background_threshold=20 if alpha_matting else 10,
        alpha_matting_erode_size=11 if alpha_matting else 10,
    )

    with Image.open(io.BytesIO(result)) as cut:
        cut = cut.convert("RGBA")
        out = io.BytesIO()
        cut.save(out, format="PNG", optimize=True)
    return out.getvalue()


async def process_upload(
    upload: UploadFile,
    *,
    mode: str = "general",
    alpha_matting: bool = False,
) -> tuple[bytes, dict[str, object]]:
    data = read_limited(upload, MAX_UPLOAD_BYTES)
    model = PORTRAIT_MODEL if mode == "portrait" else MODEL_NAME
    await get_session(model)

    temp_dir = Path(tempfile.mkdtemp(prefix="clearpix-", dir=TEMP_ROOT))
    path = temp_dir / "input"
    started = time.perf_counter()
    try:
        width, height = validate_and_prepare(data, upload.content_type, path)
        normalise_image(path)

        acquired = False
        try:
            await asyncio.wait_for(_jobs.acquire(), timeout=30)
            acquired = True
        except asyncio.TimeoutError:
            raise ApiError(
                503,
                "server_busy",
                "Our servers are busy right now. Please try again in a few moments.",
                retry_after=10,
            )

        try:
            png = await asyncio.wait_for(
                asyncio.to_thread(run_removal, path, model, alpha_matting),
                timeout=PROCESS_TIMEOUT,
            )
        except asyncio.TimeoutError:
            raise ApiError(
                504,
                "processing_timeout",
                "That image took too long to process. Please try a smaller image.",
            )
        finally:
            _jobs.release()
    finally:
        shutil.rmtree(temp_dir, ignore_errors=True)

    meta = {
        "width": width,
        "height": height,
        "mode": mode,
        "model": model,
        "processing_ms": int((time.perf_counter() - started) * 1000),
    }
    return png, meta


def png_response(png: bytes, filename: str = "clearpix-background-removed.png", ms: int | None = None) -> Response:
    headers = {
        "Content-Disposition": f'inline; filename="{filename}"',
        "Cache-Control": "no-store",
        "X-Content-Type-Options": "nosniff",
    }
    if ms is not None:
        headers["X-Processing-Ms"] = str(ms)
    return Response(content=png, media_type="image/png", headers=headers)


@app.get("/api/health")
async def health() -> dict[str, object]:
    return {
        "status": "ok",
        "service": "clearpix-api",
        "model": MODEL_NAME,
        "model_loaded": MODEL_NAME in _sessions,
        "max_upload_mb": round(MAX_UPLOAD_BYTES / (1024 * 1024), 1),
        "max_batch_images": MAX_IMAGES,
        "max_concurrent_jobs": MAX_CONCURRENT,
    }


@app.post("/api/remove-background")
async def remove_background(
    request: Request,
    image: UploadFile = File(..., description="JPG, PNG or WEBP image up to 10 MB"),
    mode: str = Form("general"),
    alpha_matting: bool = Form(False),
) -> Response:
    await enforce_rate_limit(request, RATE_LIMIT_REQUESTS, RATE_LIMIT_WINDOW)
    if mode not in {"general", "portrait"}:
        raise ApiError(422, "invalid_mode", "Mode must be 'general' or 'portrait'.")

    png, meta = await process_upload(image, mode=mode, alpha_matting=alpha_matting)
    return png_response(png, ms=int(meta["processing_ms"]))


@app.post("/api/remove-background-batch")
async def remove_background_batch(
    request: Request,
    images: list[UploadFile] = File(...),
    mode: str = Form("general"),
) -> Response:
    await enforce_rate_limit(request, RATE_LIMIT_REQUESTS, RATE_LIMIT_WINDOW)
    if not images:
        raise ApiError(400, "no_files", "Please upload at least one image.")
    if len(images) > MAX_IMAGES:
        raise ApiError(422, "too_many_files", f"You can process up to {MAX_IMAGES} images at a time.")
    if mode not in {"general", "portrait"}:
        raise ApiError(422, "invalid_mode", "Mode must be 'general' or 'portrait'.")

    results: list[tuple[str, bytes]] = []
    failures: list[dict[str, str]] = []
    for index, upload in enumerate(images, start=1):
        original = Path(upload.filename or f"image-{index}").stem[:60] or f"image-{index}"
        try:
            png, _ = await process_upload(upload, mode=mode)
            results.append((f"clearpix-{index:02d}-{original}.png", png))
        except ApiError as exc:
            failures.append({"filename": original, "code": exc.code, "message": exc.message})
        except Exception:
            logger.exception("Batch item %s failed", original)
            failures.append(
                {
                    "filename": original,
                    "code": "processing_failed",
                    "message": "We could not process this image.",
                }
            )

    if not results:
        raise ApiError(
            422,
            "batch_failed" if failures else "no_results",
            failures[0]["message"] if failures else "None of the images could be processed.",
        )

    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w", zipfile.ZIP_DEFLATED) as archive:
        for name, png in results:
            archive.writestr(name, png)
        if failures:
            archive.writestr(
                "errors.txt",
                "\n".join(f"{f['filename']}: {f['message']}" for f in failures),
            )

    headers = {"Cache-Control": "no-store"}
    headers["X-Batch-Failures"] = str(len(failures))
    return Response(
        content=buffer.getvalue(),
        media_type="application/zip",
        headers={**headers, "Content-Disposition": 'attachment; filename="clearpix-results.zip"'},
    )


@app.post("/api/zip")
async def zip_results(
    request: Request,
    images: list[UploadFile] = File(...),
    filenames: str = Form(""),
) -> Response:
    """Bundle already-processed PNGs into a ZIP without re-running AI processing."""
    await enforce_rate_limit(request, RATE_LIMIT_REQUESTS * 3, RATE_LIMIT_WINDOW)
    if not images:
        raise ApiError(400, "no_files", "There are no processed images to download yet.")
    if len(images) > 50:
        raise ApiError(422, "too_many_files", "You can download up to 50 images at a time.")

    requested_names = [
        name.strip() for name in filenames.split(",") if name.strip()
    ]
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w", zipfile.ZIP_DEFLATED) as archive:
        for index, upload in enumerate(images, start=1):
            data = read_limited(upload, MAX_UPLOAD_BYTES)
            if len(data) > MAX_UPLOAD_BYTES:
                continue
            base = requested_names[index - 1] if index - 1 < len(requested_names) else f"image-{index}"
            stem = Path(base).stem[:60] or f"image-{index}"
            archive.writestr(f"clearpix-{index:02d}-{stem}.png", data)

    if buffer.tell() == 0:
        raise ApiError(422, "empty_zip", "There are no processed images to download yet.")

    return Response(
        content=buffer.getvalue(),
        media_type="application/zip",
        headers={
            "Cache-Control": "no-store",
            "Content-Disposition": 'attachment; filename="clearpix-results.zip"',
        },
    )


@app.get("/")
async def root() -> dict[str, str]:
    return {"service": "ClearPix API", "docs": "/api/docs", "health": "/api/health"}
