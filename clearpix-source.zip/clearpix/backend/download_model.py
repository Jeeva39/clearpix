from __future__ import annotations

import sys

from rembg import new_session

MODEL = sys.argv[1] if len(sys.argv) > 1 else "u2net"


def main() -> None:
    print(f"Downloading rembg model: {MODEL}")
    new_session(MODEL)
    print("Model ready.")


if __name__ == "__main__":
    main()
