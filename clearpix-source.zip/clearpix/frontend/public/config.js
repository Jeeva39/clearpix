/*
 * ClearPix runtime configuration.
 *
 * This file is served as-is, so a static build can be pointed at a different
 * API host without rebuilding. Leave apiBaseUrl empty to call `/api/...` on the
 * same origin (Vite proxies it in development, and your reverse proxy can do the
 * same in production).
 *
 * Example:
 *   window.__CLEARPIX_CONFIG__ = { apiBaseUrl: "https://clearpix-api.onrender.com" };
 *
 * A value set here is only used when VITE_API_BASE_URL is empty at build time.
 */
window.__CLEARPIX_CONFIG__ = { apiBaseUrl: "" };
