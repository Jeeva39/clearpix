/**
 * Makes sure the background-removal model is present before a build, and
 * fetches it if it is missing from the repository.
 */
import { mkdir, stat, writeFile } from "node:fs/promises";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const root = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const modelPath = resolve(root, "public/models/u2netp.onnx");
const MODEL_URL =
  "https://github.com/danielgatis/rembg/releases/download/v0.0.0/u2netp.onnx";

await mkdir(dirname(modelPath), { recursive: true });

try {
  const info = await stat(modelPath);
  if (info.size < 1_000_000) throw new Error("model file looks truncated");
  console.log(`[model] u2netp.onnx ready (${(info.size / 1024 / 1024).toFixed(1)} MB)`);
} catch {
  console.log("[model] Downloading u2netp.onnx…");
  const response = await fetch(MODEL_URL);
  if (!response.ok) {
    console.error(`[model] Download failed with HTTP ${response.status}.`);
    process.exit(1);
  }
  await writeFile(modelPath, new Uint8Array(await response.arrayBuffer()));
  console.log("[model] u2netp.onnx downloaded.");
}
