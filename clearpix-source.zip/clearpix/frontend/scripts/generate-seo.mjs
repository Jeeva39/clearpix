import { mkdirSync, readFileSync, writeFileSync, existsSync, rmSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const root = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const publicDir = resolve(root, "public");

function readEnvFile(name) {
  const path = resolve(root, name);
  if (!existsSync(path)) return {};
  return Object.fromEntries(
    readFileSync(path, "utf8")
      .split("\n")
      .map((line) => line.trim())
      .filter((line) => line && !line.startsWith("#") && line.includes("="))
      .map((line) => {
        const index = line.indexOf("=");
        return [line.slice(0, index).trim(), line.slice(index + 1).trim().replace(/^["']|["']$/g, "")];
      }),
  );
}

const fileEnv = { ...readEnvFile(".env"), ...readEnvFile(".env.production") };
const rawSiteUrl = (process.env.VITE_SITE_URL || fileEnv.VITE_SITE_URL || "").trim();
const siteUrl = rawSiteUrl.replace(/\/$/, "");

const pages = [
  { path: "/", priority: "1.0", changefreq: "weekly" },
  { path: "/editor", priority: "0.9", changefreq: "weekly" },
  { path: "/remove-background", priority: "0.9", changefreq: "monthly" },
  { path: "/remove-background-from-image", priority: "0.9", changefreq: "monthly" },
  { path: "/background-changer", priority: "0.8", changefreq: "monthly" },
  { path: "/image-resizer", priority: "0.8", changefreq: "monthly" },
  { path: "/image-cropper", priority: "0.8", changefreq: "monthly" },
  { path: "/rotate-image", priority: "0.8", changefreq: "monthly" },
  { path: "/photo-editor-online", priority: "0.8", changefreq: "monthly" },
  { path: "/transparent-png", priority: "0.8", changefreq: "monthly" },
  { path: "/product-photo-background-remover", priority: "0.8", changefreq: "monthly" },
  { path: "/free-background-remover", priority: "0.8", changefreq: "monthly" },
  { path: "/how-to-remove-background", priority: "0.7", changefreq: "monthly" },
  { path: "/privacy-policy", priority: "0.3", changefreq: "yearly" },
  { path: "/terms-of-use", priority: "0.3", changefreq: "yearly" },
  { path: "/contact", priority: "0.4", changefreq: "yearly" },
];

mkdirSync(publicDir, { recursive: true });

const sitemapPath = resolve(publicDir, "sitemap.xml");

if (!siteUrl) {
  // No site URL means no valid absolute URLs for a sitemap. Do not invent a
  // placeholder domain: publish robots.txt without a Sitemap line and remove a
  // stale sitemap from a previous build.
  if (existsSync(sitemapPath)) rmSync(sitemapPath);
  writeFileSync(
    resolve(publicDir, "robots.txt"),
    "# ClearPix robots.txt\nUser-agent: *\nAllow: /\nDisallow: /api/\n",
    "utf8",
  );
  console.warn(
    "[seo] VITE_SITE_URL is not set. robots.txt was written without a Sitemap line and sitemap.xml was not generated. Set VITE_SITE_URL to your production origin before deploying.",
  );
} else {
  if (!/^https?:\/\//i.test(siteUrl)) {
    throw new Error(
      `[seo] VITE_SITE_URL must start with http:// or https:// (received "${siteUrl}").`,
    );
  }

  const lastmod = new Date().toISOString().slice(0, 10);

  const sitemap = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${pages
  .map(
    (page) => `  <url>
    <loc>${siteUrl}${page.path}</loc>
    <lastmod>${lastmod}</lastmod>
    <changefreq>${page.changefreq}</changefreq>
    <priority>${page.priority}</priority>
  </url>`,
  )
  .join("\n")}
</urlset>
`;

  const robots = `# ClearPix robots.txt
User-agent: *
Allow: /
Disallow: /api/

Sitemap: ${siteUrl}/sitemap.xml
`;

  writeFileSync(sitemapPath, sitemap, "utf8");
  writeFileSync(resolve(publicDir, "robots.txt"), robots, "utf8");
  console.log(`[seo] robots.txt and sitemap.xml written for ${siteUrl}`);
}
