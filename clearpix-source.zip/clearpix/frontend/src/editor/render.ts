import type {
  Adjustments,
  BackgroundKind,
  BackgroundState,
  EditorState,
  Layer,
  ShapeLayer,
  StickerLayer,
  TextLayer,
} from "./model";
import { BACKGROUND_LIBRARY, STICKERS, filterById, stickerById } from "./presets";

export const PREVIEW_MAX_SIZE = 1600;
export const MAX_EXPORT_PIXELS = 40_000_000;

export type EditorAssets = {
  original: HTMLImageElement | null;
  cutout: HTMLImageElement | null;
  /** Any background image (library SVG or user upload), keyed by URL. */
  backgroundImages: Map<string, HTMLImageElement>;
  stickers: Map<string, HTMLImageElement>;
};

export function createAssets(): EditorAssets {
  return {
    original: null,
    cutout: null,
    backgroundImages: new Map(),
    stickers: new Map(),
  };
}

function loadInto(cache: Map<string, HTMLImageElement>, url: string): Promise<void> {
  if (cache.has(url)) return Promise.resolve();
  return new Promise((resolve) => {
    const image = new Image();
    image.decoding = "async";
    image.onload = () => {
      cache.set(url, image);
      resolve();
    };
    image.onerror = () => resolve();
    image.src = url;
  });
}

export async function preloadPresetAssets(assets: EditorAssets): Promise<void> {
  await Promise.all([
    ...BACKGROUND_LIBRARY.map((item) => loadInto(assets.backgroundImages, item.url)),
    ...STICKERS.map((item) => loadInto(assets.stickers, item.url)),
  ]);
}

export function loadBackgroundAsset(assets: EditorAssets, url: string): Promise<void> {
  return loadInto(assets.backgroundImages, url);
}

/* ------------------------------------------------------------------ */
/* Adjustments                                                         */
/* ------------------------------------------------------------------ */

const ADJUST_KEYS: (keyof Adjustments)[] = [
  "brightness",
  "contrast",
  "saturation",
  "exposure",
  "temperature",
  "tint",
  "highlights",
  "shadows",
  "sharpness",
  "blur",
  "opacity",
];

export function effectiveAdjustments(state: EditorState): Adjustments {
  const merged: Adjustments = { ...state.adjustments };
  const filter = filterById(state.filter.id);
  const strength = Math.max(0, Math.min(100, state.filter.intensity)) / 100;
  if (filter.id !== "original" && strength > 0) {
    ADJUST_KEYS.forEach((key) => {
      const delta = filter.adjustments[key];
      if (typeof delta === "number") merged[key] += delta * strength;
    });
  }
  merged.brightness = clamp(merged.brightness, -100, 100);
  merged.contrast = clamp(merged.contrast, -100, 100);
  merged.saturation = clamp(merged.saturation, -100, 100);
  merged.exposure = clamp(merged.exposure, -100, 100);
  merged.temperature = clamp(merged.temperature, -100, 100);
  merged.tint = clamp(merged.tint, -100, 100);
  merged.highlights = clamp(merged.highlights, -100, 100);
  merged.shadows = clamp(merged.shadows, -100, 100);
  merged.sharpness = clamp(merged.sharpness, 0, 100);
  merged.blur = clamp(merged.blur, 0, 20);
  merged.opacity = clamp(merged.opacity, 0, 100);
  return merged;
}

function clamp(value: number, min: number, max: number): number {
  return Math.min(max, Math.max(min, value));
}

export function hasPixelAdjustments(adj: Adjustments): boolean {
  return (
    adj.brightness !== 0 ||
    adj.contrast !== 0 ||
    adj.saturation !== 0 ||
    adj.exposure !== 0 ||
    adj.temperature !== 0 ||
    adj.tint !== 0 ||
    adj.highlights !== 0 ||
    adj.shadows !== 0 ||
    adj.sharpness > 0
  );
}

function applyPixelAdjustments(canvas: HTMLCanvasElement, adj: Adjustments): void {
  const ctx = canvas.getContext("2d", { willReadFrequently: true });
  if (!ctx || canvas.width === 0 || canvas.height === 0) return;
  const image = ctx.getImageData(0, 0, canvas.width, canvas.height);
  const data = image.data;

  const exposure = Math.pow(2, adj.exposure / 55);
  const brightness = adj.brightness * 1.9;
  const c = adj.contrast * 2.2;
  const contrast = (259 * (c + 255)) / (255 * (259 - c));
  const saturation = 1 + adj.saturation / 100;
  const temperature = adj.temperature * 0.5;
  const tint = adj.tint * 0.45;
  const highlights = adj.highlights / 100;
  const shadows = adj.shadows / 100;

  for (let i = 0; i < data.length; i += 4) {
    if (data[i + 3] === 0) continue;
    let r = data[i];
    let g = data[i + 1];
    let b = data[i + 2];

    r *= exposure;
    g *= exposure;
    b *= exposure;
    r += brightness;
    g += brightness;
    b += brightness;

    r = (r - 128) * contrast + 128;
    g = (g - 128) * contrast + 128;
    b = (b - 128) * contrast + 128;

    r += temperature * 0.9;
    b -= temperature * 0.9;
    r += tint * 0.35;
    b += tint * 0.35;
    g -= tint * 0.5;

    const luma = 0.2126 * r + 0.7152 * g + 0.0722 * b;
    r = luma + (r - luma) * saturation;
    g = luma + (g - luma) * saturation;
    b = luma + (b - luma) * saturation;

    if (highlights !== 0 || shadows !== 0) {
      const level = clamp(luma / 255, 0, 1);
      const shadowMask = (1 - level) * (1 - level);
      const highlightMask = level * level;
      const delta = shadows * 80 * shadowMask + highlights * 80 * highlightMask;
      r += delta;
      g += delta;
      b += delta;
    }

    data[i] = r;
    data[i + 1] = g;
    data[i + 2] = b;
  }

  if (adj.sharpness > 1) {
    sharpen(image, canvas.width, canvas.height, adj.sharpness / 100);
  }

  ctx.putImageData(image, 0, 0);
}

function sharpen(image: ImageData, width: number, height: number, amount: number): void {
  const src = new Uint8ClampedArray(image.data);
  const data = image.data;
  const center = 1 + 4 * amount;
  const side = -amount;
  for (let y = 1; y < height - 1; y += 1) {
    for (let x = 1; x < width - 1; x += 1) {
      const i = (y * width + x) * 4;
      if (src[i + 3] === 0) continue;
      for (let channel = 0; channel < 3; channel += 1) {
        const value =
          center * src[i + channel] +
          side * src[i - 4 + channel] +
          side * src[i + 4 + channel] +
          side * src[i - width * 4 + channel] +
          side * src[i + width * 4 + channel];
        data[i + channel] = value;
      }
    }
  }
}

/* ------------------------------------------------------------------ */
/* Photo + background                                                  */
/* ------------------------------------------------------------------ */

function rotatedDimensions(width: number, height: number, rotate: number) {
  return rotate % 180 === 0 ? { width, height } : { width: height, height: width };
}

function drawPhoto(
  target: CanvasRenderingContext2D,
  state: EditorState,
  source: HTMLImageElement,
  width: number,
  height: number,
): void {
  const sw = source.naturalWidth || source.width;
  const sh = source.naturalHeight || source.height;
  const { rotate, flipH, flipV, crop, straighten } = state.photo;
  const rotated = rotatedDimensions(sw, sh, rotate);
  const cropX = clamp(crop.x, 0, 1) * rotated.width;
  const cropY = clamp(crop.y, 0, 1) * rotated.height;
  const cropW = Math.max(1, clamp(crop.w, 0.001, 1) * rotated.width);
  const cropH = Math.max(1, clamp(crop.h, 0.001, 1) * rotated.height);

  const staged = document.createElement("canvas");
  staged.width = Math.max(1, Math.round(width));
  staged.height = Math.max(1, Math.round(height));
  const ctx = staged.getContext("2d");
  if (!ctx) return;
  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = "high";

  // Build the affine map original pixels → crop rectangle → output canvas.
  let matrix = new DOMMatrix([width / cropW, 0, 0, height / cropH, 0, 0]);
  matrix = matrix.translate(-cropX, -cropY);

  if (flipH) {
    matrix = matrix.translate(rotated.width, 0).scale(-1, 1);
  }
  if (flipV) {
    matrix = matrix.translate(0, rotated.height).scale(-1, 1);
  }

  let rotationMatrix: DOMMatrix;
  switch (rotate) {
    case 90:
      rotationMatrix = new DOMMatrix([0, 1, -1, 0, sh, 0]);
      break;
    case 180:
      rotationMatrix = new DOMMatrix([-1, 0, 0, -1, sw, sh]);
      break;
    case 270:
      rotationMatrix = new DOMMatrix([0, -1, 1, 0, 0, sw]);
      break;
    default:
      rotationMatrix = new DOMMatrix();
  }

  ctx.setTransform(matrix.multiply(rotationMatrix));
  ctx.drawImage(source, 0, 0);
  ctx.setTransform(1, 0, 0, 1, 0, 0);

  if (straighten !== 0) {
    const angle = (straighten * Math.PI) / 180;
    const cos = Math.abs(Math.cos(angle));
    const sin = Math.abs(Math.sin(angle));
    const cover = Math.max((width * cos + height * sin) / width, (width * sin + height * cos) / height);
    target.save();
    target.translate(width / 2, height / 2);
    target.rotate(angle);
    target.scale(cover, cover);
    target.drawImage(staged, -width / 2, -height / 2);
    target.restore();
  } else {
    target.drawImage(staged, 0, 0);
  }
}

const cutoutCache = new WeakMap<HTMLImageElement, { key: string; canvas: HTMLCanvasElement }>();

/**
 * The cut-out is a separate image from the original, so rotate / flip / straighten
 * have to be applied to it as well — otherwise rotating the canvas would move the
 * background but leave the subject upright. Results are cached per image + transform.
 */
function transformedCutout(cutout: HTMLImageElement, state: EditorState): HTMLCanvasElement {
  const { rotate, flipH, flipV, straighten } = state.photo;
  const key = `${rotate}:${flipH}:${flipV}:${straighten}`;
  const cached = cutoutCache.get(cutout);
  if (cached && cached.key === key) return cached.canvas;

  const sw = cutout.naturalWidth || cutout.width;
  const sh = cutout.naturalHeight || cutout.height;
  const rotated = rotatedDimensions(sw, sh, rotate);
  const canvas = document.createElement("canvas");
  canvas.width = Math.max(1, rotated.width);
  canvas.height = Math.max(1, rotated.height);
  const ctx = canvas.getContext("2d");
  if (!ctx) return canvas;

  let matrix = new DOMMatrix();
  if (flipH) matrix = matrix.translate(rotated.width, 0).scale(-1, 1);
  if (flipV) matrix = matrix.translate(0, rotated.height).scale(-1, 1);
  switch (rotate) {
    case 90:
      matrix = matrix.multiply(new DOMMatrix([0, 1, -1, 0, sh, 0]));
      break;
    case 180:
      matrix = matrix.multiply(new DOMMatrix([-1, 0, 0, -1, sw, sh]));
      break;
    case 270:
      matrix = matrix.multiply(new DOMMatrix([0, -1, 1, 0, 0, sw]));
      break;
    default:
      break;
  }
  ctx.setTransform(matrix);
  ctx.drawImage(cutout, 0, 0);
  ctx.setTransform(1, 0, 0, 1, 0, 0);

  let result = canvas;
  if (straighten !== 0) {
    const angle = (straighten * Math.PI) / 180;
    const cos = Math.abs(Math.cos(angle));
    const sin = Math.abs(Math.sin(angle));
    const cover = Math.max(
      (canvas.width * cos + canvas.height * sin) / canvas.width,
      (canvas.width * sin + canvas.height * cos) / canvas.height,
    );
    const straightened = document.createElement("canvas");
    straightened.width = canvas.width;
    straightened.height = canvas.height;
    const sctx = straightened.getContext("2d");
    if (sctx) {
      sctx.translate(canvas.width / 2, canvas.height / 2);
      sctx.rotate(angle);
      sctx.scale(cover, cover);
      sctx.drawImage(canvas, -canvas.width / 2, -canvas.height / 2);
      result = straightened;
    }
  }

  cutoutCache.set(cutout, { key, canvas: result });
  return result;
}

function drawSubject(
  target: CanvasRenderingContext2D,
  state: EditorState,
  cutout: HTMLImageElement,
  width: number,
  height: number,
): void {
  const source = transformedCutout(cutout, state);
  const sw = source.width;
  const sh = source.height;
  const fit = Math.min(width / sw, height / sh);
  const scale = fit * (state.subject.scale / 100);
  const drawW = sw * scale;
  const drawH = sh * scale;
  const x = (width - drawW) / 2 + state.subject.x;
  const y = (height - drawH) / 2 + state.subject.y;
  target.drawImage(source, x, y, drawW, drawH);
}

function drawBackground(
  ctx: CanvasRenderingContext2D,
  background: BackgroundState,
  width: number,
  height: number,
  assets: EditorAssets,
  overrideKind?: BackgroundKind,
  previewColor?: string,
): void {
  const kind = overrideKind ?? background.kind;
  if (kind === "transparent") return;

  if (kind === "color") {
    ctx.fillStyle = previewColor ?? background.color;
    ctx.fillRect(0, 0, width, height);
    return;
  }

  if (kind === "gradient") {
    const angle = (background.gradient.angle * Math.PI) / 180;
    const cx = width / 2;
    const cy = height / 2;
    const radius = Math.max(width, height);
    const dx = Math.cos(angle) * radius;
    const dy = Math.sin(angle) * radius;
    const gradient = ctx.createLinearGradient(cx - dx, cy - dy, cx + dx, cy + dy);
    gradient.addColorStop(0, background.gradient.from);
    if (background.gradient.via) gradient.addColorStop(0.5, background.gradient.via);
    gradient.addColorStop(1, background.gradient.to);
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, width, height);
    return;
  }

  const image = background.imageUrl ? assets.backgroundImages.get(background.imageUrl) : null;
  if (!image) {
    ctx.fillStyle = "#f3f4f6";
    ctx.fillRect(0, 0, width, height);
    return;
  }

  const iw = image.naturalWidth || image.width;
  const ih = image.naturalHeight || image.height;
  const fit = background.imageFit === "contain" ? Math.min : Math.max;
  const base = fit(width / iw, height / ih);
  const scale = base * (background.imageScale / 100);
  const drawW = iw * scale;
  const drawH = ih * scale;
  const x = (width - drawW) / 2 + background.imageX;
  const y = (height - drawH) / 2 + background.imageY;
  ctx.save();
  ctx.beginPath();
  ctx.rect(0, 0, width, height);
  ctx.clip();
  ctx.drawImage(image, x, y, drawW, drawH);
  ctx.restore();
}

/* ------------------------------------------------------------------ */
/* Subject effects                                                     */
/* ------------------------------------------------------------------ */

function silhouette(source: HTMLCanvasElement, color: string): HTMLCanvasElement {
  const canvas = document.createElement("canvas");
  canvas.width = source.width;
  canvas.height = source.height;
  const ctx = canvas.getContext("2d");
  if (!ctx) return canvas;
  ctx.drawImage(source, 0, 0);
  ctx.globalCompositeOperation = "source-in";
  ctx.fillStyle = color;
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  return canvas;
}

function drawSubjectEffects(
  ctx: CanvasRenderingContext2D,
  subject: HTMLCanvasElement,
  state: EditorState,
  scale: number,
): void {
  if (state.outline.enabled && state.outline.width > 0) {
    const solid = silhouette(subject, state.outline.color);
    const radius = Math.max(1, state.outline.width * scale);
    const steps = Math.max(12, Math.round(radius * 1.6));
    for (let step = 0; step < steps; step += 1) {
      const angle = (step / steps) * Math.PI * 2;
      ctx.drawImage(solid, Math.cos(angle) * radius, Math.sin(angle) * radius);
    }
  }

  if (state.shadow.enabled && state.shadow.opacity > 0) {
    const solid = silhouette(subject, state.shadow.color);
    const angle = (state.shadow.angle * Math.PI) / 180;
    const distance = state.shadow.distance * scale;
    ctx.save();
    ctx.globalAlpha = clamp(state.shadow.opacity / 100, 0, 1);
    const blur = Math.max(0, state.shadow.blur * scale);
    if (blur > 0) ctx.filter = `blur(${blur}px)`;
    ctx.drawImage(solid, Math.cos(angle) * distance, Math.sin(angle) * distance);
    ctx.restore();
  }
}

/* ------------------------------------------------------------------ */
/* Layers                                                              */
/* ------------------------------------------------------------------ */

const measureCanvas = document.createElement("canvas");
const measureCtx = measureCanvas.getContext("2d");

function fontString(layer: TextLayer): string {
  return `${layer.italic ? "italic " : ""}${layer.bold ? "700" : "400"} ${layer.size}px ${layer.font}`;
}

export type LayerBounds = { width: number; height: number };

export function measureLayer(layer: Layer): LayerBounds {
  if (layer.kind === "text") {
    if (!measureCtx) return { width: layer.size * 6, height: layer.size };
    measureCtx.font = fontString(layer);
    const lines = layer.text.split("\n");
    const widths = lines.map((line) => measureCtx.measureText(line).width + Math.max(0, layer.letterSpacing) * line.length);
    return {
      width: Math.max(1, ...widths),
      height: Math.max(layer.size, lines.length * layer.size * layer.lineHeight),
    };
  }
  if (layer.kind === "shape") return { width: layer.w, height: layer.h };
  return { width: layer.size, height: layer.size };
}

function drawTextLayer(ctx: CanvasRenderingContext2D, layer: TextLayer): void {
  const lines = layer.text.split("\n");
  const { height, width } = measureLayer(layer);
  ctx.font = fontString(layer);
  ctx.textBaseline = "middle";
  ctx.textAlign = layer.align === "center" ? "center" : layer.align === "right" ? "right" : "left";
  const spacing = layer.letterSpacing;
  if (spacing && "letterSpacing" in ctx) {
    (ctx as CanvasRenderingContext2D & { letterSpacing: string }).letterSpacing = `${spacing}px`;
  }
  const anchorX = layer.align === "center" ? 0 : layer.align === "right" ? width / 2 : -width / 2;
  const lineHeight = layer.size * layer.lineHeight;
  lines.forEach((line, index) => {
    const y = -height / 2 + lineHeight * (index + 0.5);
    if (layer.shadow) {
      ctx.shadowColor = layer.shadowColor;
      ctx.shadowBlur = Math.max(2, layer.size * 0.12);
      ctx.shadowOffsetY = Math.max(1, layer.size * 0.04);
    }
    if (layer.outline) {
      ctx.lineWidth = Math.max(2, layer.size * 0.07);
      ctx.strokeStyle = layer.outlineColor;
      ctx.lineJoin = "round";
      ctx.strokeText(line, anchorX, y);
    }
    ctx.fillStyle = layer.color;
    ctx.fillText(line, anchorX, y);
    ctx.shadowColor = "transparent";
    ctx.shadowBlur = 0;
    ctx.shadowOffsetY = 0;
  });
  if (spacing && "letterSpacing" in ctx) {
    (ctx as CanvasRenderingContext2D & { letterSpacing: string }).letterSpacing = "0px";
  }
}

function drawShapeLayer(ctx: CanvasRenderingContext2D, layer: ShapeLayer): void {
  const halfW = layer.w / 2;
  const halfH = layer.h / 2;
  ctx.fillStyle = layer.fill;
  ctx.strokeStyle = layer.border;
  ctx.lineWidth = layer.borderWidth;
  ctx.beginPath();
  switch (layer.shape) {
    case "circle":
      ctx.ellipse(0, 0, Math.abs(halfW), Math.abs(halfH), 0, 0, Math.PI * 2);
      break;
    case "line":
      ctx.moveTo(-halfW, 0);
      ctx.lineTo(halfW, 0);
      ctx.lineWidth = Math.max(layer.borderWidth, layer.h / 8, 2);
      ctx.stroke();
      return;
    case "arrow": {
      const head = Math.max(12, layer.h * 0.4);
      ctx.moveTo(-halfW, 0);
      ctx.lineTo(halfW - head * 0.4, 0);
      ctx.lineWidth = Math.max(layer.borderWidth, layer.h / 8, 2);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(halfW, 0);
      ctx.lineTo(halfW - head, -head * 0.6);
      ctx.lineTo(halfW - head, head * 0.6);
      ctx.closePath();
      ctx.fill();
      return;
    }
    case "triangle":
      ctx.moveTo(0, -halfH);
      ctx.lineTo(halfW, halfH);
      ctx.lineTo(-halfW, halfH);
      ctx.closePath();
      break;
    default:
      ctx.rect(-halfW, -halfH, layer.w, layer.h);
  }
  if (layer.fill !== "transparent") ctx.fill();
  if (layer.borderWidth > 0) ctx.stroke();
}

function drawStickerLayer(ctx: CanvasRenderingContext2D, layer: StickerLayer, assets: EditorAssets): void {
  // Layers store the preset id; the image cache is keyed by asset URL.
  const definition = stickerById(layer.sticker);
  const image = definition ? assets.stickers.get(definition.url) : undefined;
  if (!image) return;
  const ratio = (image.naturalHeight || 1) / (image.naturalWidth || 1);
  const width = layer.size;
  const height = layer.size * ratio;
  ctx.drawImage(image, -width / 2, -height / 2, width, height);
}

export function drawLayers(ctx: CanvasRenderingContext2D, layers: Layer[], assets: EditorAssets): void {
  layers.forEach((layer) => {
    if (!layer.visible) return;
    ctx.save();
    ctx.globalAlpha = clamp(layer.opacity / 100, 0, 1);
    ctx.translate(layer.x, layer.y);
    if (layer.rotation) ctx.rotate((layer.rotation * Math.PI) / 180);
    if (layer.kind === "text") drawTextLayer(ctx, layer);
    else if (layer.kind === "shape") drawShapeLayer(ctx, layer);
    else drawStickerLayer(ctx, layer, assets);
    ctx.restore();
  });
}

export function layerAtPoint(layers: Layer[], x: number, y: number): Layer | null {
  for (let index = layers.length - 1; index >= 0; index -= 1) {
    const layer = layers[index];
    if (!layer.visible) continue;
    const bounds = measureLayer(layer);
    const angle = (-layer.rotation * Math.PI) / 180;
    const dx = x - layer.x;
    const dy = y - layer.y;
    const localX = dx * Math.cos(angle) - dy * Math.sin(angle);
    const localY = dx * Math.sin(angle) + dy * Math.cos(angle);
    if (Math.abs(localX) <= bounds.width / 2 + 4 && Math.abs(localY) <= bounds.height / 2 + 4) {
      return layer;
    }
  }
  return null;
}

/* ------------------------------------------------------------------ */
/* Document render                                                     */
/* ------------------------------------------------------------------ */

export type RenderOptions = {
  /** Cap the long edge, used for the on-screen preview. 0 = full resolution. */
  maxSize?: number;
  /** Transparent checkerboard is drawn by CSS, never baked into a preview. */
  previewBackground?: string;
};

export function renderDocument(
  state: EditorState,
  assets: EditorAssets,
  options: RenderOptions = {},
): HTMLCanvasElement {
  const maxSize = options.maxSize ?? PREVIEW_MAX_SIZE;
  const longEdge = Math.max(state.doc.width, state.doc.height) || 1;
  const scale = maxSize > 0 ? Math.min(1, maxSize / longEdge) : 1;
  const width = Math.max(1, Math.round(state.doc.width * scale));
  const height = Math.max(1, Math.round(state.doc.height * scale));

  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext("2d", { willReadFrequently: true });
  if (!ctx) return canvas;
  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = "high";

  drawBackground(ctx, state.background, width, height, assets, undefined, options.previewBackground);

  const photo = document.createElement("canvas");
  photo.width = width;
  photo.height = height;
  const photoCtx = photo.getContext("2d", { willReadFrequently: true });
  if (!photoCtx) return canvas;

  const useCutout = state.subject.useCutout && assets.cutout;
  if (useCutout && assets.cutout) {
    drawSubject(photoCtx, state, assets.cutout, width, height);
  } else if (assets.original) {
    drawPhoto(photoCtx, state, assets.original, width, height);
  }

  const adj = effectiveAdjustments(state);
  if (hasPixelAdjustments(adj)) applyPixelAdjustments(photo, adj);

  if (useCutout) drawSubjectEffects(ctx, photo, state, scale);

  ctx.save();
  ctx.globalAlpha = clamp(adj.opacity / 100, 0, 1);
  if (adj.blur > 0) ctx.filter = `blur(${Math.max(0.2, adj.blur * scale)}px)`;
  ctx.drawImage(photo, 0, 0);
  ctx.restore();

  drawLayers(ctx, state.layers, assets);
  return canvas;
}

export function renderExportCanvas(state: EditorState, assets: EditorAssets): HTMLCanvasElement {
  if (state.doc.width * state.doc.height > MAX_EXPORT_PIXELS) {
    throw new Error(
      `That export is too large (${state.doc.width}×${state.doc.height}). Please resize below ${MAX_EXPORT_PIXELS / 1_000_000} megapixels.`,
    );
  }
  return renderDocument(state, assets, { maxSize: 0 });
}

export function canvasToBlob(
  canvas: HTMLCanvasElement,
  type: string,
  quality?: number,
): Promise<Blob> {
  return new Promise((resolve, reject) => {
    canvas.toBlob(
      (blob) => {
        if (blob) resolve(blob);
        else reject(new Error("The browser could not export this image."));
      },
      type,
      quality,
    );
  });
}
