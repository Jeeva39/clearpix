import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Link, useSearchParams } from "react-router-dom";
import { Icon, Logo } from "../components/Icon";
import { Seo } from "../components/Seo";
import { usePasteImages, useBackendStatus, useFullscreen } from "../lib/hooks";
import { CanvasStage } from "./components/CanvasStage";
import { EditorToolbar } from "./components/Toolbar";
import { ToolPanel, type CropControls } from "./components/Panels";
import { ActionButton } from "./components/controls";
import type { CropRect, ToolId } from "./model";
import { useEditorWorkspace } from "./workspace";

const TOOLS: { id: ToolId; label: string; icon: React.ComponentProps<typeof Icon>["name"] }[] = [
  { id: "background", label: "Background", icon: "scissors" },
  { id: "resize", label: "Resize", icon: "compress" },
  { id: "crop", label: "Crop", icon: "grid" },
  { id: "rotate", label: "Rotate", icon: "refresh" },
  { id: "adjust", label: "Adjust", icon: "wand" },
  { id: "filters", label: "Filters", icon: "palette" },
  { id: "text", label: "Text", icon: "file" },
  { id: "stickers", label: "Stickers", icon: "heart" },
  { id: "layers", label: "Layers", icon: "layers" },
  { id: "shadow", label: "Effects", icon: "sparkles" },
  { id: "export", label: "Export", icon: "download" },
  { id: "batch", label: "Batch", icon: "package" },
];

const TOOL_IDS = new Set<string>(TOOLS.map((tool) => tool.id));

const SHORTCUTS = [
  ["Ctrl / ⌘ + Z", "Undo"],
  ["Ctrl / ⌘ + Shift + Z", "Redo"],
  ["Ctrl / ⌘ + S", "Open the export panel"],
  ["Delete", "Delete the selected layer"],
  ["Esc", "Cancel crop / clear selection"],
  ["Double-click a slider", "Reset that value"],
];

export function EditorPage() {
  const ws = useEditorWorkspace();
  const [searchParams, setSearchParams] = useSearchParams();
  const initialTool = searchParams.get("tool");
  const [tool, setTool] = useState<ToolId>(
    initialTool && TOOL_IDS.has(initialTool) ? (initialTool as ToolId) : "background",
  );
  const [zoom, setZoom] = useState(100);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [panelOpen, setPanelOpen] = useState(false);
  const [cropDraft, setCropDraft] = useState<CropRect | null>(null);
  const [cropAspect, setCropAspect] = useState<number | null>(null);
  const [showShortcuts, setShowShortcuts] = useState(false);
  const [quickBusy, setQuickBusy] = useState(false);
  const [notice, setNotice] = useState<string | null>(null);

  const rootRef = useRef<HTMLDivElement>(null);
  const replaceRef = useRef<HTMLInputElement>(null);
  const backend = useBackendStatus();
  const fullscreen = useFullscreen(rootRef);

  usePasteImages((files) => {
    if (!ws.loaded) void ws.loadFile(files[0]);
  }, !ws.loaded);

  useEffect(() => {
    ws.setLoadError(null);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tool]);

  useEffect(() => {
    if (!ws.loaded) setPanelOpen(false);
  }, [ws.loaded]);

  const chooseTool = useCallback(
    (id: ToolId) => {
      setTool(id);
      setPanelOpen(true);
      setSearchParams((params) => {
        params.set("tool", id);
        return params;
      }, { replace: true });
      if (id === "crop") {
        setCropDraft((current) =>
          current ?? {
            x: ws.state.doc.width * 0.1,
            y: ws.state.doc.height * 0.1,
            w: ws.state.doc.width * 0.8,
            h: ws.state.doc.height * 0.8,
          },
        );
      } else {
        setCropDraft(null);
      }
    },
    [setSearchParams, ws.state.doc.height, ws.state.doc.width],
  );

  const applyCrop = useCallback(() => {
    if (!cropDraft) return;
    const { doc } = ws.state;
    const nx = cropDraft.x / doc.width;
    const ny = cropDraft.y / doc.height;
    const nw = cropDraft.w / doc.width;
    const nh = cropDraft.h / doc.height;
    ws.update((current) => {
      const old = current.photo.crop;
      return {
        ...current,
        doc: {
          width: Math.max(16, Math.round(cropDraft.w)),
          height: Math.max(16, Math.round(cropDraft.h)),
        },
        photo: {
          ...current.photo,
          crop: {
            x: old.x + nx * old.w,
            y: old.y + ny * old.h,
            w: nw * old.w,
            h: nh * old.h,
          },
        },
        layers: current.layers.map((layer) => ({
          ...layer,
          x: layer.x - cropDraft.x,
          y: layer.y - cropDraft.y,
        })),
      };
    });
    setCropDraft(null);
    setNotice(`Cropped to ${Math.round(cropDraft.w)} × ${Math.round(cropDraft.h)} px.`);
  }, [cropDraft, ws]);

  const resetAll = useCallback(() => {
    const original = ws.assets.original;
    const width = original?.naturalWidth ?? ws.state.doc.width;
    const height = original?.naturalHeight ?? ws.state.doc.height;
    ws.dispatch({ type: "reset", width, height, sourceName: ws.sourceName });
    setSelectedId(null);
    setCropDraft(null);
    setZoom(100);
    setNotice("Everything is back to the original image.");
  }, [ws]);

  const replaceImage = useCallback(() => {
    if (
      ws.state.layers.length > 0 ||
      ws.state.subject.useCutout ||
      ws.state.filter.id !== "original"
    ) {
      const confirmed = window.confirm(
        "Replacing the image starts a new edit and discards the current changes. Continue?",
      );
      if (!confirmed) return;
    }
    replaceRef.current?.click();
  }, [ws.state.filter.id, ws.state.layers.length, ws.state.subject.useCutout]);

  /* Keyboard shortcuts */
  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      const target = event.target as HTMLElement | null;
      const typing =
        target &&
        (target.tagName === "INPUT" ||
          target.tagName === "TEXTAREA" ||
          target.tagName === "SELECT" ||
          target.isContentEditable);
      const meta = event.ctrlKey || event.metaKey;

      if (meta && event.key.toLowerCase() === "z") {
        event.preventDefault();
        if (event.shiftKey) ws.dispatch({ type: "redo" });
        else ws.dispatch({ type: "undo" });
        return;
      }
      if (meta && event.key.toLowerCase() === "y") {
        event.preventDefault();
        ws.dispatch({ type: "redo" });
        return;
      }
      if (meta && event.key.toLowerCase() === "s") {
        event.preventDefault();
        chooseTool("export");
        return;
      }
      if (event.key === "Escape") {
        if (cropDraft) {
          setCropDraft(null);
        } else {
          setSelectedId(null);
          setShowShortcuts(false);
        }
        return;
      }
      if ((event.key === "Delete" || event.key === "Backspace") && !typing && selectedId) {
        event.preventDefault();
        ws.update((current) => ({
          ...current,
          layers: current.layers.filter((layer) => layer.id !== selectedId),
        }));
        setSelectedId(null);
      }
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [chooseTool, cropDraft, selectedId, ws]);

  const crop: CropControls = useMemo(
    () => ({
      draft: cropDraft,
      setDraft: setCropDraft,
      aspect: cropAspect,
      setAspect: setCropAspect,
      apply: applyCrop,
      reset: () => setCropDraft(null),
    }),
    [applyCrop, cropAspect, cropDraft],
  );

  const quickDownload = async () => {
    setQuickBusy(true);
    try {
      await ws.quickDownloadPng();
      setNotice("Transparent PNG downloaded.");
    } catch (error) {
      setNotice(error instanceof Error ? error.message : "The download failed.");
    } finally {
      setQuickBusy(false);
    }
  };

  if (!ws.loaded) {
    return (
      <>
        <Seo
          title="Free Online Photo Editor — Remove Backgrounds & Edit Images | ClearPix"
          description="Edit photos online for free with ClearPix. Remove backgrounds with AI, change backgrounds, resize, crop, add text and export transparent PNGs without signing up."
          path="/editor"
        />
        <div className="min-h-[100dvh] bg-mist">
          <header className="flex h-16 items-center justify-between border-b border-ink/[0.06] bg-white/90 px-4 backdrop-blur sm:px-6">
            <Link to="/" aria-label="ClearPix home">
              <Logo />
            </Link>
            <div className="flex items-center gap-2">
              <span
                className={`hidden items-center gap-1.5 rounded-full px-2.5 py-1 text-[11px] font-semibold sm:inline-flex ${
                  backend.status === "online"
                    ? "bg-emerald-50 text-emerald-700"
                    : backend.status === "checking"
                      ? "bg-mist text-ink-muted"
                      : "bg-amber-50 text-amber-700"
                }`}
              >
                <span
                  className={`h-1.5 w-1.5 rounded-full ${
                    backend.status === "online"
                      ? "bg-emerald-500"
                      : backend.status === "checking"
                        ? "bg-ink/30"
                        : "bg-amber-500"
                  }`}
                />
                {backend.status === "online"
                  ? "AI ready"
                  : backend.status === "checking"
                    ? "Checking AI"
                    : "AI offline"}
              </span>
              <Link to="/" className="btn-secondary px-4 py-2 text-xs">
                Back to home
              </Link>
            </div>
          </header>

          <UploadScreen
            ws={ws}
            backendStatus={backend.status}
            onRetryBackend={() => void backend.refresh()}
          />
        </div>
      </>
    );
  }

  return (
    <>
      <Seo
        title="ClearPix Editor — Background Removal, Resize, Crop & Text"
        description="Edit your image in the ClearPix workspace: AI background removal, background replacement, resize, crop, filters, text, stickers and real PNG/JPEG/WEBP export."
        path="/editor"
        noindex={false}
      />
      <div ref={rootRef} className="flex h-[100dvh] flex-col bg-mist text-ink">
        <h1 className="sr-only">ClearPix image editor — remove backgrounds, edit and export</h1>
        <EditorToolbar
          canUndo={ws.canUndo}
          canRedo={ws.canRedo}
          onUndo={() => ws.dispatch({ type: "undo" })}
          onRedo={() => ws.dispatch({ type: "redo" })}
          onReset={resetAll}
          onSaveProject={() => void ws.saveProject()}
          onDownload={() => void quickDownload()}
          onExport={() => chooseTool("export")}
          onReplace={replaceImage}
          zoom={zoom}
          setZoom={setZoom}
          onFullscreen={() => void fullscreen.toggle()}
          isFullscreen={fullscreen.isFullscreen}
          onShortcuts={() => setShowShortcuts(true)}
          exportBusy={quickBusy}
        />

        <input
          ref={replaceRef}
          type="file"
          accept="image/jpeg,image/png,image/webp,.jpg,.jpeg,.png,.webp"
          className="sr-only"
          aria-label="Choose a replacement image"
          tabIndex={-1}
          onChange={(event) => {
            const file = event.target.files?.[0];
            if (file) void ws.loadFile(file);
            event.target.value = "";
          }}
        />

        <div className="flex min-h-0 flex-1">
          <nav
            aria-label="Editing tools"
            className="hidden w-[76px] shrink-0 flex-col gap-1 overflow-y-auto border-r border-ink/[0.07] bg-white px-1.5 py-2 lg:flex"
          >
            {TOOLS.map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() => chooseTool(item.id)}
                aria-pressed={tool === item.id}
                className={`flex flex-col items-center gap-1 rounded-xl px-1 py-2 text-[10px] font-semibold transition ${
                  tool === item.id
                    ? "bg-brand-50 text-brand-700 ring-1 ring-brand-200"
                    : "text-ink-muted hover:bg-mist hover:text-ink"
                }`}
              >
                <Icon name={item.icon} size={18} />
                {item.label}
              </button>
            ))}
          </nav>

          <div className="flex min-w-0 flex-1 flex-col">
            <div className="flex min-h-0 flex-1 overflow-hidden">
              <CanvasStage
                state={ws.state}
                assets={ws.assets}
                assetsVersion={ws.assetsVersion}
                tool={tool}
                zoom={zoom}
                selectedId={selectedId}
                onSelect={setSelectedId}
                cropDraft={cropDraft}
                onCropDraft={setCropDraft}
                cropAspect={cropAspect}
                onMoveLayer={(id, x, y) =>
                  ws.update(
                    (current) => ({
                      ...current,
                      layers: current.layers.map((layer) =>
                        layer.id === id ? { ...layer, x, y } : layer,
                      ),
                    }),
                    `drag:${id}`,
                  )
                }
                onMoveSubject={(x, y) =>
                  ws.update(
                    (current) => ({ ...current, subject: { ...current.subject, x, y } }),
                    "subject:drag",
                  )
                }
                fullscreen={fullscreen.isFullscreen}
              />

              <aside className="hidden w-[320px] shrink-0 overflow-y-auto border-l border-ink/[0.07] bg-white p-4 lg:block">
                <div className="mb-4 flex items-center justify-between">
                  <h2 className="text-sm font-bold capitalize text-ink">
                    {TOOLS.find((item) => item.id === tool)?.label}
                  </h2>
                  <span className="rounded-full bg-mist px-2 py-0.5 text-[10px] font-semibold text-ink-muted">
                    {ws.state.doc.width} × {ws.state.doc.height}
                  </span>
                </div>
                <ToolPanel
                  tool={tool}
                  ws={ws}
                  selectedId={selectedId}
                  setSelectedId={setSelectedId}
                  crop={crop}
                  onReplaceImage={replaceImage}
                />
              </aside>
            </div>

            <div className="flex h-11 shrink-0 items-center gap-2 border-t border-ink/[0.07] bg-white px-2 sm:px-3">
              <div className="flex items-center gap-1 lg:hidden">
                <button
                  type="button"
                  onClick={() => setPanelOpen(true)}
                  className="inline-flex items-center gap-1.5 rounded-lg bg-brand-600 px-2.5 py-1.5 text-[11px] font-semibold text-white"
                >
                  <Icon name="grid" size={13} />
                  Tools
                </button>
              </div>

              <div className="hidden items-center gap-1 sm:flex">
                <button
                  type="button"
                  onClick={() => setZoom(Math.max(25, zoom - 25))}
                  className="rounded-md p-1 text-ink-muted hover:bg-mist"
                  aria-label="Zoom out"
                >
                  <Icon name="zoom-out" size={14} />
                </button>
                <span className="min-w-[2.8rem] text-center text-[11px] font-semibold tabular-nums">
                  {zoom}%
                </span>
                <button
                  type="button"
                  onClick={() => setZoom(Math.min(400, zoom + 25))}
                  className="rounded-md p-1 text-ink-muted hover:bg-mist"
                  aria-label="Zoom in"
                >
                  <Icon name="zoom-in" size={14} />
                </button>
                <button
                  type="button"
                  onClick={() => setZoom(100)}
                  className="ml-1 rounded-md border border-ink/10 px-2 py-1 text-[10px] font-semibold text-ink-soft hover:bg-mist"
                >
                  Fit
                </button>
              </div>

              <div className="ml-auto flex min-w-0 items-center gap-2">
                {notice && (
                  <span className="hidden truncate text-[11px] text-ink-muted md:inline" role="status">
                    {notice}
                  </span>
                )}
                <span className="hidden items-center gap-1 text-[11px] tabular-nums text-ink-muted sm:flex">
                  <Icon name="image" size={12} />
                  {ws.state.doc.width} × {ws.state.doc.height}px
                </span>
                <span
                  className={`inline-flex items-center gap-1.5 rounded-full px-2 py-1 text-[10px] font-semibold ${
                    backend.status === "online"
                      ? "bg-emerald-50 text-emerald-700"
                      : backend.status === "checking"
                        ? "bg-mist text-ink-muted"
                        : "bg-amber-50 text-amber-700"
                  }`}
                  title={
                    backend.status === "online"
                      ? `AI model: ${backend.info?.model ?? "u2net"}`
                      : "The background-removal API is not reachable"
                  }
                >
                  <span
                    className={`h-1.5 w-1.5 rounded-full ${
                      backend.status === "online"
                        ? "bg-emerald-500"
                        : backend.status === "checking"
                          ? "bg-ink/30"
                          : "bg-amber-500"
                    }`}
                  />
                  {backend.status === "online" ? "AI ready" : backend.status === "checking" ? "Checking" : "AI offline"}
                </span>
                <button
                  type="button"
                  onClick={() => setShowShortcuts(true)}
                  className="rounded-md p-1 text-ink-muted transition hover:bg-mist hover:text-ink"
                  aria-label="Keyboard shortcuts"
                >
                  <Icon name="info" size={14} />
                </button>
              </div>
            </div>

            <nav
              aria-label="Editing tools"
              className="flex shrink-0 gap-1 overflow-x-auto border-t border-ink/[0.07] bg-white px-2 py-1.5 lg:hidden"
            >
              {TOOLS.map((item) => (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => chooseTool(item.id)}
                  aria-pressed={tool === item.id}
                  className={`flex min-w-[56px] flex-col items-center gap-0.5 rounded-lg px-2 py-1 text-[9px] font-semibold transition ${
                    tool === item.id ? "bg-brand-50 text-brand-700" : "text-ink-muted"
                  }`}
                >
                  <Icon name={item.icon} size={16} />
                  {item.label}
                </button>
              ))}
            </nav>
          </div>
        </div>

        {panelOpen && (
          <div className="fixed inset-0 z-40 lg:hidden">
            <button
              type="button"
              aria-label="Close tool panel"
              className="absolute inset-0 bg-ink/40"
              onClick={() => setPanelOpen(false)}
            />
            <div className="absolute inset-x-0 bottom-0 max-h-[70vh] overflow-y-auto rounded-t-2xl bg-white p-4 pb-8 shadow-2xl">
              <div className="mb-2 flex items-center justify-between">
                <h2 className="text-sm font-bold capitalize">{TOOLS.find((item) => item.id === tool)?.label}</h2>
                <button
                  type="button"
                  onClick={() => setPanelOpen(false)}
                  className="rounded-md p-1 text-ink-muted"
                  aria-label="Close panel"
                >
                  <Icon name="close" size={18} />
                </button>
              </div>
              <div className="mb-4 flex gap-1.5 border-b border-ink/[0.06] pb-3">
                <ActionButton icon="refresh" onClick={resetAll}>
                  Reset
                </ActionButton>
                <ActionButton icon="upload" onClick={replaceImage}>
                  Replace
                </ActionButton>
                <ActionButton icon="file" onClick={() => void ws.saveProject()}>
                  Save project
                </ActionButton>
              </div>
              <ToolPanel
                tool={tool}
                ws={ws}
                selectedId={selectedId}
                setSelectedId={setSelectedId}
                crop={crop}
                onReplaceImage={replaceImage}
              />
            </div>
          </div>
        )}

        {showShortcuts && (
          <div className="fixed inset-0 z-50 grid place-items-center p-4">
            <button
              type="button"
              className="absolute inset-0 bg-ink/50"
              aria-label="Close keyboard shortcuts"
              onClick={() => setShowShortcuts(false)}
            />
            <div className="relative w-full max-w-sm rounded-xl2 bg-white p-5 shadow-2xl">
              <div className="flex items-center justify-between">
                <h2 className="text-sm font-bold">Keyboard shortcuts</h2>
                <button
                  type="button"
                  onClick={() => setShowShortcuts(false)}
                  className="rounded-md p-1 text-ink-muted hover:bg-mist"
                  aria-label="Close"
                >
                  <Icon name="close" size={16} />
                </button>
              </div>
              <dl className="mt-3 space-y-2">
                {SHORTCUTS.map(([keys, action]) => (
                  <div key={keys} className="flex items-center justify-between gap-3">
                    <dt className="rounded bg-mist px-2 py-1 text-[11px] font-semibold text-ink-soft">
                      {keys}
                    </dt>
                    <dd className="text-xs text-ink-soft">{action}</dd>
                  </div>
                ))}
              </dl>
            </div>
          </div>
        )}
      </div>
    </>
  );
}

/* ------------------------------------------------------------------ */
/* Upload screen                                                       */
/* ------------------------------------------------------------------ */

function UploadScreen({
  ws,
  backendStatus,
  onRetryBackend,
}: {
  ws: ReturnType<typeof useEditorWorkspace>;
  backendStatus: "checking" | "online" | "offline";
  onRetryBackend: () => void;
}) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [dragging, setDragging] = useState(false);
  const [busy, setBusy] = useState(false);
  const projectRef = useRef<HTMLInputElement>(null);

  const openPicker = () => inputRef.current?.click();

  const handleFiles = async (files: File[]) => {
    if (!files[0]) return;
    setBusy(true);
    await ws.loadFile(files[0]);
    setBusy(false);
  };

  return (
    <div className="container-page py-8 sm:py-12">
      <div className="mx-auto max-w-3xl">
        <div className="text-center">
          <span className="eyebrow">
            <Icon name="sparkles" size={13} />
            ClearPix editor
          </span>
          <h1 className="mt-4 text-3xl font-extrabold tracking-tight text-ink sm:text-4xl">
            Edit photos. Remove backgrounds. Create anything.
          </h1>
          <p className="mx-auto mt-3 max-w-xl text-sm leading-6 text-ink-soft sm:text-base">
            Upload an image to open the full editor. Crop, resize, change the background, add text
            and filters, then export a real PNG, JPEG or WEBP.
          </p>
        </div>

        <div className="card mt-8 p-3 shadow-card sm:p-5">
          <div
            role="button"
            tabIndex={0}
            aria-label="Upload an image"
            onClick={openPicker}
            onKeyDown={(event) => {
              if (event.key === "Enter" || event.key === " ") {
                event.preventDefault();
                openPicker();
              }
            }}
            onDragEnter={(event) => {
              event.preventDefault();
              setDragging(true);
            }}
            onDragOver={(event) => {
              event.preventDefault();
              event.dataTransfer.dropEffect = "copy";
            }}
            onDragLeave={(event) => {
              event.preventDefault();
              setDragging(false);
            }}
            onDrop={(event) => {
              event.preventDefault();
              setDragging(false);
              void handleFiles(Array.from(event.dataTransfer.files ?? []));
            }}
            className={`flex cursor-pointer flex-col items-center justify-center rounded-xl2 border-2 border-dashed px-5 py-12 text-center transition ${
              dragging ? "border-brand-500 bg-brand-50/70" : "border-ink/15 bg-white hover:border-brand-400"
            }`}
          >
            <span className="grid h-14 w-14 place-items-center rounded-2xl bg-brand-50 text-brand-600">
              <Icon name={busy ? "loader" : "upload"} size={26} className={busy ? "animate-spin" : ""} />
            </span>
            <span className="mt-4 text-lg font-bold text-ink">
              {busy ? "Opening your image…" : "Drag an image here, or click to browse"}
            </span>
            <span className="mt-1 text-xs text-ink-muted">
              JPG, JPEG, PNG or WEBP · up to 10 MB · you can also paste with Ctrl / ⌘ + V
            </span>
            <span className="btn-primary mt-5 px-6">
              <Icon name="upload" size={17} />
              Choose image
            </span>
          </div>

          <input
            ref={inputRef}
            type="file"
            accept="image/jpeg,image/png,image/webp,.jpg,.jpeg,.png,.webp"
            className="sr-only"
            aria-label="Choose an image to edit"
            tabIndex={-1}
            onChange={(event) => {
              void handleFiles(Array.from(event.target.files ?? []));
              event.target.value = "";
            }}
          />

          {ws.loadError && (
            <div className="mt-3 flex items-start gap-2 rounded-xl border border-red-200 bg-red-50 px-3 py-2.5 text-sm text-red-700" role="alert">
              <Icon name="alert" size={16} className="mt-0.5 shrink-0" />
              <div>
                <p className="font-semibold">{ws.loadError}</p>
                <p className="text-xs text-red-600/80">Try another JPG, PNG or WEBP file.</p>
              </div>
            </div>
          )}

          <div className="mt-4 flex flex-wrap items-center justify-between gap-3 rounded-xl border border-ink/[0.07] px-3 py-2.5">
            <div className="flex items-center gap-2 text-xs">
              <span
                className={`h-2 w-2 rounded-full ${
                  backendStatus === "online"
                    ? "bg-emerald-500"
                    : backendStatus === "checking"
                      ? "bg-ink/30"
                      : "bg-amber-500"
                }`}
              />
              <span className="font-semibold text-ink">
                {backendStatus === "online"
                  ? "AI background removal is online"
                  : backendStatus === "checking"
                    ? "Checking the AI service…"
                    : "AI service not reachable"}
              </span>
              {backendStatus === "offline" && (
                <button
                  type="button"
                  onClick={onRetryBackend}
                  className="inline-flex items-center gap-1 rounded-md bg-mist px-2 py-1 text-[11px] font-semibold text-ink-soft hover:bg-brand-50"
                >
                  <Icon name="refresh" size={12} /> Retry
                </button>
              )}
            </div>
            <button
              type="button"
              onClick={() => projectRef.current?.click()}
              className="inline-flex items-center gap-1.5 rounded-md border border-ink/10 px-2.5 py-1.5 text-[11px] font-semibold text-ink-soft transition hover:bg-mist"
            >
              <Icon name="file" size={13} />
              Open a saved project
            </button>
            <input
              ref={projectRef}
              type="file"
              accept=".json,.clearpix.json,application/json"
              className="sr-only"
              aria-label="Open a saved ClearPix project"
              tabIndex={-1}
              onChange={(event) => {
                const file = event.target.files?.[0];
                if (!file) return;
                setBusy(true);
                void ws.openProject(file).finally(() => setBusy(false));
                event.target.value = "";
              }}
            />
          </div>

          {backendStatus === "offline" && (
            <p className="mt-2 text-[11px] leading-5 text-ink-muted">
              Editing works offline, but AI background removal needs the FastAPI backend. Start it
              with <code className="rounded bg-mist px-1">uvicorn main:app --port 8000</code> or set{" "}
              <code className="rounded bg-mist px-1">VITE_API_BASE_URL</code> to your deployed API.
            </p>
          )}
        </div>

        <ul className="mt-6 grid grid-cols-2 gap-2 text-xs text-ink-soft sm:grid-cols-4">
          {[
            "Real AI cut-outs",
            "Background library",
            "Text & stickers",
            "PNG / JPEG / WEBP",
          ].map((item) => (
            <li key={item} className="flex items-center gap-1.5 rounded-lg bg-white px-2.5 py-2 shadow-soft">
              <Icon name="check" size={13} className="text-emerald-600" />
              {item}
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
