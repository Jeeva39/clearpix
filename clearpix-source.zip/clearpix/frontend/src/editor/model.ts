export type ToolId =
  | "background"
  | "resize"
  | "crop"
  | "rotate"
  | "adjust"
  | "filters"
  | "text"
  | "stickers"
  | "layers"
  | "shadow"
  | "export"
  | "batch";

export type Adjustments = {
  brightness: number;
  contrast: number;
  saturation: number;
  exposure: number;
  temperature: number;
  tint: number;
  highlights: number;
  shadows: number;
  sharpness: number;
  blur: number;
  opacity: number;
};

export type CropRect = { x: number; y: number; w: number; h: number };

export type PhotoState = {
  rotate: 0 | 90 | 180 | 270;
  flipH: boolean;
  flipV: boolean;
  /** Normalised crop within the rotated + flipped source image. */
  crop: CropRect;
  /** Free rotation applied on top of the 90° steps. */
  straighten: number;
};

export type BackgroundKind = "transparent" | "color" | "gradient" | "image";

export type BackgroundState = {
  kind: BackgroundKind;
  color: string;
  gradient: { from: string; to: string; via: string | null; angle: number };
  imageUrl: string | null;
  imageFit: "cover" | "contain";
  imageScale: number;
  imageX: number;
  imageY: number;
};

export type SubjectState = {
  useCutout: boolean;
  x: number;
  y: number;
  scale: number;
};

export type ShadowState = {
  enabled: boolean;
  color: string;
  blur: number;
  opacity: number;
  distance: number;
  angle: number;
};

export type OutlineState = {
  enabled: boolean;
  color: string;
  width: number;
};

export type LayerBase = {
  id: string;
  name: string;
  visible: boolean;
  locked: boolean;
  x: number;
  y: number;
  rotation: number;
  opacity: number;
};

export type TextLayer = LayerBase & {
  kind: "text";
  text: string;
  font: string;
  size: number;
  color: string;
  bold: boolean;
  italic: boolean;
  align: "left" | "center" | "right";
  lineHeight: number;
  letterSpacing: number;
  shadow: boolean;
  shadowColor: string;
  outline: boolean;
  outlineColor: string;
};

export type ShapeKind = "rect" | "circle" | "line" | "arrow" | "triangle";

export type ShapeLayer = LayerBase & {
  kind: "shape";
  shape: ShapeKind;
  w: number;
  h: number;
  fill: string;
  border: string;
  borderWidth: number;
};

export type StickerLayer = LayerBase & {
  kind: "sticker";
  sticker: string;
  size: number;
};

export type Layer = TextLayer | ShapeLayer | StickerLayer;

export type FilterState = { id: string; intensity: number };

export type EditorState = {
  doc: { width: number; height: number };
  photo: PhotoState;
  subject: SubjectState;
  background: BackgroundState;
  adjustments: Adjustments;
  filter: FilterState;
  shadow: ShadowState;
  outline: OutlineState;
  layers: Layer[];
  sourceName: string;
};

export const DEFAULT_ADJUSTMENTS: Adjustments = {
  brightness: 0,
  contrast: 0,
  saturation: 0,
  exposure: 0,
  temperature: 0,
  tint: 0,
  highlights: 0,
  shadows: 0,
  sharpness: 0,
  blur: 0,
  opacity: 100,
};

export const DEFAULT_SHADOW: ShadowState = {
  enabled: false,
  color: "#0f172a",
  blur: 24,
  opacity: 32,
  distance: 18,
  angle: 90,
};

export const DEFAULT_OUTLINE: OutlineState = {
  enabled: false,
  color: "#ffffff",
  width: 6,
};

export const DEFAULT_BACKGROUND: BackgroundState = {
  kind: "transparent",
  color: "#ffffff",
  gradient: { from: "#7a63f6", to: "#2563eb", via: null, angle: 135 },
  imageUrl: null,
  imageFit: "cover",
  imageScale: 100,
  imageX: 0,
  imageY: 0,
};

export function editId(prefix = "layer"): string {
  return `${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`;
}

export function initialState(width: number, height: number, sourceName: string): EditorState {
  return {
    doc: { width: Math.round(width), height: Math.round(height) },
    photo: { rotate: 0, flipH: false, flipV: false, crop: { x: 0, y: 0, w: 1, h: 1 }, straighten: 0 },
    subject: { useCutout: false, x: 0, y: 0, scale: 100 },
    background: { ...DEFAULT_BACKGROUND },
    adjustments: { ...DEFAULT_ADJUSTMENTS },
    filter: { id: "original", intensity: 100 },
    shadow: { ...DEFAULT_SHADOW },
    outline: { ...DEFAULT_OUTLINE },
    layers: [],
    sourceName,
  };
}

export function createTextLayer(state: EditorState, preset?: Partial<TextLayer>): TextLayer {
  const width = Math.min(state.doc.width, 1200);
  return {
    id: editId("text"),
    kind: "text",
    name: preset?.text ? preset.text.slice(0, 24) : "Text",
    visible: true,
    locked: false,
    x: state.doc.width / 2,
    y: state.doc.height / 2,
    rotation: 0,
    opacity: 100,
    text: "Your text here",
    font: "Inter, system-ui, sans-serif",
    size: Math.max(18, Math.round(width * 0.08)),
    color: "#111827",
    bold: true,
    italic: false,
    align: "center",
    lineHeight: 1.15,
    letterSpacing: 0,
    shadow: false,
    shadowColor: "#000000",
    outline: false,
    outlineColor: "#ffffff",
    ...preset,
  };
}

export function createShapeLayer(state: EditorState, shape: ShapeKind): ShapeLayer {
  const base = Math.min(state.doc.width, state.doc.height);
  return {
    id: editId("shape"),
    kind: "shape",
    name: shape === "rect" ? "Rectangle" : shape[0].toUpperCase() + shape.slice(1),
    visible: true,
    locked: false,
    x: state.doc.width / 2,
    y: state.doc.height / 2,
    rotation: 0,
    opacity: 100,
    shape,
    w: Math.round(base * 0.3),
    h: Math.round(base * 0.3),
    fill: "#7a63f6",
    border: "#1f2937",
    borderWidth: 0,
  };
}

export function createStickerLayer(state: EditorState, sticker: string, name: string): StickerLayer {
  return {
    id: editId("sticker"),
    kind: "sticker",
    name,
    visible: true,
    locked: false,
    x: state.doc.width / 2,
    y: state.doc.height / 2,
    rotation: 0,
    opacity: 100,
    sticker,
    size: Math.round(Math.min(state.doc.width, state.doc.height) * 0.22),
  };
}

/* ------------------------------------------------------------------ */
/* History store                                                       */
/* ------------------------------------------------------------------ */

export type EditorStore = {
  present: EditorState;
  past: EditorState[];
  future: EditorState[];
  lastKey: string;
  lastAt: number;
};

export type EditorAction =
  | { type: "update"; produce: (state: EditorState) => EditorState; key?: string }
  | { type: "undo" }
  | { type: "redo" }
  | { type: "replace"; state: EditorState; history?: boolean }
  | { type: "reset"; width: number; height: number; sourceName: string };

const HISTORY_LIMIT = 80;
const COALESCE_MS = 700;

export function createStore(state: EditorState): EditorStore {
  return { present: state, past: [], future: [], lastKey: "", lastAt: 0 };
}

export function editorReducer(store: EditorStore, action: EditorAction): EditorStore {
  switch (action.type) {
    case "update": {
      const next = action.produce(store.present);
      if (next === store.present) return store;
      const now = Date.now();
      const key = action.key ?? "";
      const coalesce = Boolean(key) && key === store.lastKey && now - store.lastAt < COALESCE_MS;
      return {
        present: next,
        past: coalesce ? store.past : [...store.past, store.present].slice(-HISTORY_LIMIT),
        future: [],
        lastKey: key,
        lastAt: now,
      };
    }
    case "undo": {
      if (store.past.length === 0) return store;
      const previous = store.past[store.past.length - 1];
      return {
        present: previous,
        past: store.past.slice(0, -1),
        future: [store.present, ...store.future].slice(0, HISTORY_LIMIT),
        lastKey: "",
        lastAt: 0,
      };
    }
    case "redo": {
      if (store.future.length === 0) return store;
      const [next, ...rest] = store.future;
      return {
        present: next,
        past: [...store.past, store.present].slice(-HISTORY_LIMIT),
        future: rest,
        lastKey: "",
        lastAt: 0,
      };
    }
    case "replace":
      return {
        present: action.state,
        past: action.history ? [...store.past, store.present].slice(-HISTORY_LIMIT) : [],
        future: [],
        lastKey: "",
        lastAt: 0,
      };
    case "reset":
      return createStore(initialState(action.width, action.height, action.sourceName));
    default:
      return store;
  }
}
