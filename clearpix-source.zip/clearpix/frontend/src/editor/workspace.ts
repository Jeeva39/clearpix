import { useCallback, useEffect, useMemo, useReducer, useRef, useState } from "react";
import { ApiError, loadImageElement, removeBackground, validateImageFile } from "../lib/api";
import { saveBlob } from "../lib/download";
import { track } from "../lib/analytics";
import {
  canvasToBlob,
  createAssets,
  loadBackgroundAsset,
  preloadPresetAssets,
  renderExportCanvas,
  renderDocument,
  type EditorAssets,
} from "./render";
import {
  createStore,
  createTextLayer,
  editorReducer,
  initialState,
  type EditorState,
  type TextLayer,
} from "./model";

export type ExportFormat = "png" | "jpeg" | "webp";

export type ExportOptions = {
  format: ExportFormat;
  quality: number;
  width: number;
  height: number;
  filename: string;
  flattenColor?: string;
};

export type BackgroundRemovalStatus = "idle" | "working" | "done" | "error";

type ProjectFile = {
  format: "clearpix-project";
  version: number;
  savedAt: string;
  source: { name: string; dataUrl: string };
  cutout: { dataUrl: string } | null;
  state: EditorState;
};

const EMPTY_STATE = initialState(1080, 1080, "clearpix-image");
const MAX_PROJECT_BYTES = 40 * 1024 * 1024;

function blobToDataUrl(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(new Error("Could not read the project image"));
    reader.readAsDataURL(blob);
  });
}

export function useEditorWorkspace() {
  const [store, dispatch] = useReducer(editorReducer, undefined, () => createStore(EMPTY_STATE));
  const state = store.present;

  const assetsRef = useRef<EditorAssets>(createAssets());
  const originalBlobRef = useRef<Blob | null>(null);
  const cutoutBlobRef = useRef<Blob | null>(null);
  const [assetsVersion, setAssetsVersion] = useState(0);
  const [loaded, setLoaded] = useState(false);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [sourceName, setSourceName] = useState("clearpix-image");
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const controller = useRef<AbortController | null>(null);

  const [removal, setRemoval] = useState<BackgroundRemovalStatus>("idle");
  const [removalError, setRemovalError] = useState<string | null>(null);
  const [removalProgress, setRemovalProgress] = useState(0);
  const [lastProcessingMs, setLastProcessingMs] = useState<number | null>(null);

  const bumpAssets = useCallback(() => setAssetsVersion((value) => value + 1), []);

  useEffect(() => {
    const assets = assetsRef.current;
    void preloadPresetAssets(assets).then(bumpAssets);
  }, [bumpAssets]);

  useEffect(
    () => () => {
      controller.current?.abort();
      if (previewUrl) URL.revokeObjectURL(previewUrl);
    },
    [previewUrl],
  );

  const update = useCallback(
    (produce: (current: EditorState) => EditorState, key?: string) => {
      dispatch({ type: "update", produce, key });
    },
    [],
  );

  const loadFile = useCallback(
    async (file: File): Promise<{ ok: boolean; message?: string }> => {
      try {
        setLoadError(null);
        const info = await validateImageFile(file);
        const image = await loadImageElement(file);

        if (previewUrl) URL.revokeObjectURL(previewUrl);
        assetsRef.current.original = image;
        assetsRef.current.cutout = null;
        originalBlobRef.current = file;
        cutoutBlobRef.current = null;
        setPreviewUrl(URL.createObjectURL(file));
        setSourceName(info.name);
        setRemoval("idle");
        setRemovalError(null);
        setLastProcessingMs(null);
        dispatch({ type: "replace", state: initialState(info.width, info.height, info.name) });
        setLoaded(true);
        setAssetsVersion((value) => value + 1);
        track("image_loaded", { width: info.width, height: info.height });
        return { ok: true };
      } catch (error) {
        const message =
          error instanceof ApiError
            ? error.message
            : "That file could not be opened. Please try a different image.";
        setLoadError(message);
        return { ok: false, message };
      }
    },
    [previewUrl],
  );

  const closeImage = useCallback(() => {
    controller.current?.abort();
    assetsRef.current.original = null;
    assetsRef.current.cutout = null;
    originalBlobRef.current = null;
    cutoutBlobRef.current = null;
    if (previewUrl) URL.revokeObjectURL(previewUrl);
    setPreviewUrl(null);
    setLoaded(false);
    setLoadError(null);
    setRemoval("idle");
    setRemovalError(null);
    dispatch({ type: "replace", state: EMPTY_STATE });
    bumpAssets();
  }, [bumpAssets, previewUrl]);

  const runRemoval = useCallback(
    async (mode: "general" | "portrait" = "general") => {
      const blob = originalBlobRef.current;
      if (!blob) return;
      controller.current?.abort();
      const abort = new AbortController();
      controller.current = abort;
      setRemoval("working");
      setRemovalError(null);
      setRemovalProgress(0);
      try {
        const file = new File([blob], sourceName, { type: blob.type || "image/png" });
        const startedAt = performance.now();
        const result = await removeBackground(file, {
          mode,
          signal: abort.signal,
          onUploadProgress: (percent) => setRemovalProgress(percent),
        });
        const image = await loadImageElement(result);
        assetsRef.current.cutout = image;
        cutoutBlobRef.current = result;
        setRemoval("done");
        setRemovalProgress(100);
        setLastProcessingMs(Math.round(performance.now() - startedAt));
        dispatch({
          type: "update",
          produce: (current) => ({
            ...current,
            subject: { ...current.subject, useCutout: true, x: 0, y: 0, scale: 100 },
          }),
        });
        bumpAssets();
        track("background_removal_completed", { mode, source: "editor" });
      } catch (error) {
        if (error instanceof ApiError && error.code === "aborted") {
          setRemoval("idle");
          return;
        }
        setRemoval("error");
        setRemovalError(
          error instanceof ApiError
            ? error.message
            : "The background could not be removed. Please try again.",
        );
        track("error_occurred", { code: "editor_removal_failed" });
      }
    },
    [bumpAssets, sourceName],
  );

  const restoreOriginal = useCallback(() => {
    update((current) => ({ ...current, subject: { ...current.subject, useCutout: false } }));
  }, [update]);

  const useCutoutAgain = useCallback(() => {
    update((current) => ({ ...current, subject: { ...current.subject, useCutout: true } }));
  }, [update]);

  const chooseBackgroundImage = useCallback(
    async (url: string) => {
      await loadBackgroundAsset(assetsRef.current, url);
      update((current) => ({
        ...current,
        background: { ...current.background, kind: "image", imageUrl: url, imageX: 0, imageY: 0, imageScale: 100 },
      }));
      bumpAssets();
    },
    [bumpAssets, update],
  );

  const uploadBackgroundImage = useCallback(
    async (file: File): Promise<{ ok: boolean; message?: string }> => {
      try {
        const info = await validateImageFile(file);
        void info;
        const dataUrl = await blobToDataUrl(file);
        await chooseBackgroundImage(dataUrl);
        return { ok: true };
      } catch (error) {
        return {
          ok: false,
          message:
            error instanceof ApiError
              ? error.message
              : "That background image could not be opened. Please try another file.",
        };
      }
    },
    [chooseBackgroundImage],
  );

  const exportImage = useCallback(
    async (options: ExportOptions) => {
      const width = Math.max(16, Math.round(options.width));
      const height = Math.max(16, Math.round(options.height));
      let exportState: EditorState = { ...state, doc: { width, height } };
      if (options.format === "jpeg" && exportState.background.kind === "transparent") {
        exportState = {
          ...exportState,
          background: {
            ...exportState.background,
            kind: "color",
            color: options.flattenColor || "#ffffff",
          },
        };
      }
      const canvas = renderExportCanvas(exportState, assetsRef.current);
      const mime =
        options.format === "png" ? "image/png" : options.format === "webp" ? "image/webp" : "image/jpeg";
      const blob = await canvasToBlob(
        canvas,
        mime,
        options.format === "png" ? undefined : Math.min(100, Math.max(10, options.quality)) / 100,
      );
      const extension = options.format === "jpeg" ? "jpg" : options.format;
      const base = (options.filename || "clearpix-edited-image").replace(/\.[^.]+$/, "").trim() || "clearpix-edited-image";
      saveBlob(blob, `${base}.${extension}`);
      track("download_completed", { format: options.format, type: "editor" });
      return { blob, width, height };
    },
    [state],
  );

  const quickDownloadPng = useCallback(async () => {
    const canvas = renderExportCanvas(state, assetsRef.current);
    const blob = await canvasToBlob(canvas, "image/png");
    saveBlob(blob, "clearpix-edited-image.png");
    track("download_completed", { format: "png", type: "editor-quick" });
  }, [state]);

  const saveProject = useCallback(async () => {
    const original = originalBlobRef.current;
    if (!original) return;
    const project: ProjectFile = {
      format: "clearpix-project",
      version: 1,
      savedAt: new Date().toISOString(),
      source: { name: sourceName, dataUrl: await blobToDataUrl(original) },
      cutout: cutoutBlobRef.current ? { dataUrl: await blobToDataUrl(cutoutBlobRef.current) } : null,
      state,
    };
    const blob = new Blob([JSON.stringify(project)], { type: "application/json" });
    const base = sourceName.replace(/\.[^.]+$/, "") || "clearpix-project";
    saveBlob(blob, `${base}.clearpix.json`);
  }, [sourceName, state]);

  const openProject = useCallback(
    async (file: File): Promise<{ ok: boolean; message?: string }> => {
      try {
        if (file.size > MAX_PROJECT_BYTES) {
          return { ok: false, message: "That project file is too large to open." };
        }
        const parsed = JSON.parse(await file.text()) as ProjectFile;
        if (parsed.format !== "clearpix-project" || !parsed.state?.doc) {
          return { ok: false, message: "That file is not a ClearPix project." };
        }
        const originalImage = await loadImageElement(parsed.source.dataUrl);
        assetsRef.current.original = originalImage;
        assetsRef.current.cutout = parsed.cutout ? await loadImageElement(parsed.cutout.dataUrl) : null;
        originalBlobRef.current = await (await fetch(parsed.source.dataUrl)).blob();
        cutoutBlobRef.current = parsed.cutout
          ? await (await fetch(parsed.cutout.dataUrl)).blob()
          : null;
        if (parsed.state.background.imageUrl) {
          await loadBackgroundAsset(assetsRef.current, parsed.state.background.imageUrl);
        }
        setSourceName(parsed.source.name || "clearpix-image");
        setPreviewUrl(parsed.source.dataUrl);
        setLoaded(true);
        setRemoval(parsed.cutout ? "done" : "idle");
        setRemovalError(null);
        dispatch({ type: "replace", state: parsed.state });
        bumpAssets();
        return { ok: true };
      } catch {
        return { ok: false, message: "That project file could not be read." };
      }
    },
    [bumpAssets],
  );

  const addTextLayer = useCallback(
    (preset?: Partial<TextLayer>) => {
      update((current) => {
        const layer = {
          ...createTextLayer(current, preset),
          ...preset,
        };
        return { ...current, layers: [...current.layers, layer] };
      });
    },
    [update],
  );

  const renderPreview = useCallback(
    (maxSize: number) => renderDocument(state, assetsRef.current, { maxSize }),
    [state],
  );

  const canUndo = store.past.length > 0;
  const canRedo = store.future.length > 0;

  return useMemo(
    () => ({
      state,
      dispatch,
      update,
      assets: assetsRef.current,
      assetsVersion,
      loaded,
      loadError,
      setLoadError,
      sourceName,
      previewUrl,
      loadFile,
      closeImage,
      removal,
      removalError,
      removalProgress,
      lastProcessingMs,
      runRemoval,
      restoreOriginal,
      useCutoutAgain,
      chooseBackgroundImage,
      uploadBackgroundImage,
      exportImage,
      quickDownloadPng,
      saveProject,
      openProject,
      addTextLayer,
      renderPreview,
      canUndo,
      canRedo,
    }),
    [
      state,
      update,
      assetsVersion,
      loaded,
      loadError,
      sourceName,
      previewUrl,
      loadFile,
      closeImage,
      removal,
      removalError,
      removalProgress,
      lastProcessingMs,
      runRemoval,
      restoreOriginal,
      useCutoutAgain,
      chooseBackgroundImage,
      uploadBackgroundImage,
      exportImage,
      quickDownloadPng,
      saveProject,
      openProject,
      addTextLayer,
      renderPreview,
      canUndo,
      canRedo,
    ],
  );
}

