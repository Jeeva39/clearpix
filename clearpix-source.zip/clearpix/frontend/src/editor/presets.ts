import type { Adjustments, ShapeKind } from "./model";

function svgDataUrl(svg: string): string {
  return `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg.replace(/\s+/g, " ").trim())}`;
}

export const SOLID_COLORS = [
  "#ffffff",
  "#f3f4f6",
  "#9ca3af",
  "#111827",
  "#ef4444",
  "#3b82f6",
  "#22c55e",
  "#facc15",
  "#f472b6",
  "#a855f7",
  "#f97316",
  "#14b8a6",
];

export type GradientPreset = {
  id: string;
  name: string;
  from: string;
  to: string;
  via: string | null;
  angle: number;
};

export const GRADIENT_PRESETS: GradientPreset[] = [
  { id: "violet", name: "Violet dusk", from: "#7a63f6", to: "#2f4dff", via: null, angle: 135 },
  { id: "sunset", name: "Sunset", from: "#fb7185", to: "#f59e0b", via: null, angle: 120 },
  { id: "mint", name: "Mint", from: "#34d399", to: "#06b6d4", via: null, angle: 135 },
  { id: "peach", name: "Peach", from: "#fecdd3", to: "#fed7aa", via: null, angle: 160 },
  { id: "ocean", name: "Ocean", from: "#0ea5e9", to: "#1e3a8a", via: null, angle: 120 },
  { id: "berry", name: "Berry", from: "#c026d3", to: "#4c1d95", via: "#fb7185", angle: 135 },
  { id: "graphite", name: "Graphite", from: "#334155", to: "#0f172a", via: null, angle: 180 },
  { id: "cream", name: "Cream", from: "#fef3c7", to: "#fde68a", via: "#ffffff", angle: 90 },
  { id: "forest", name: "Forest", from: "#14532d", to: "#4ade80", via: null, angle: 140 },
  { id: "candy", name: "Candy", from: "#a5b4fc", to: "#f0abfc", via: "#fbcfe8", angle: 115 },
];

type BackgroundPreset = {
  id: string;
  name: string;
  category: string;
  url: string;
};

function studioScene(id: string, name: string, top: string, mid: string, bottom: string, glow: string): BackgroundPreset {
  return {
    id,
    name,
    category: "Studio",
    url: svgDataUrl(`
      <svg xmlns="http://www.w3.org/2000/svg" width="1000" height="1000" viewBox="0 0 1000 1000">
        <defs>
          <linearGradient id="g" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stop-color="${top}"/><stop offset="0.55" stop-color="${mid}"/><stop offset="1" stop-color="${bottom}"/>
          </linearGradient>
          <radialGradient id="r" cx="0.5" cy="0.32" r="0.55">
            <stop offset="0" stop-color="${glow}" stop-opacity="0.95"/><stop offset="1" stop-color="${glow}" stop-opacity="0"/>
          </radialGradient>
        </defs>
        <rect width="1000" height="1000" fill="url(#g)"/>
        <rect width="1000" height="1000" fill="url(#r)"/>
        <ellipse cx="500" cy="905" rx="430" ry="90" fill="#000" opacity="0.12"/>
      </svg>`),
  };
}

export const BACKGROUND_LIBRARY: BackgroundPreset[] = [
  studioScene("studio-white", "White studio", "#ffffff", "#f4f4f8", "#e6e6ee", "#ffffff"),
  studioScene("studio-grey", "Grey studio", "#d7d9e2", "#c3c6d4", "#a7abba", "#eef0f7"),
  studioScene("studio-blue", "Blue studio", "#e6efff", "#cfe0ff", "#a9c4f7", "#ffffff"),
  studioScene("studio-warm", "Warm studio", "#fff2e6", "#ffe0c7", "#f4c69c", "#fff9f2"),

  {
    id: "nature-forest",
    name: "Forest",
    category: "Nature",
    url: svgDataUrl(`
      <svg xmlns="http://www.w3.org/2000/svg" width="1000" height="1000" viewBox="0 0 1000 1000">
        <defs>
          <linearGradient id="sky" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stop-color="#dff3e4"/><stop offset="1" stop-color="#8ec9a2"/>
          </linearGradient>
        </defs>
        <rect width="1000" height="1000" fill="url(#sky)"/>
        <circle cx="500" cy="330" r="240" fill="#ffffff" opacity="0.35"/>
        <path d="M0 760h1000v240H0z" fill="#4f8f68" opacity="0.65"/>
        <g fill="#2f6b4a" opacity="0.55">
          <path d="M120 760c-60-90-90-150-60-220 40 40 60 60 90 60 20-60 50-90 80-110 10 80-10 150-30 270z"/>
          <path d="M840 780c-60-90-90-150-60-220 40 40 60 60 90 60 20-60 50-90 80-110 10 80-10 150-30 270z"/>
        </g>
      </svg>`),
  },
  {
    id: "nature-meadow",
    name: "Meadow",
    category: "Nature",
    url: svgDataUrl(`
      <svg xmlns="http://www.w3.org/2000/svg" width="1000" height="1000" viewBox="0 0 1000 1000">
        <defs>
          <linearGradient id="m" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stop-color="#cbe9ff"/><stop offset="0.6" stop-color="#f0f7e0"/><stop offset="1" stop-color="#cfe3a8"/>
          </linearGradient>
        </defs>
        <rect width="1000" height="1000" fill="url(#m)"/>
        <circle cx="760" cy="220" r="110" fill="#fff6c9" opacity="0.9"/>
        <path d="M0 720c180-90 330-40 520 0 190 40 320 10 480-60v340H0z" fill="#a9c979" opacity="0.75"/>
        <path d="M0 840c220-70 380-30 560 10 160 35 300 20 440-40v190H0z" fill="#7fae55" opacity="0.7"/>
      </svg>`),
  },
  {
    id: "nature-tropical",
    name: "Tropical leaves",
    category: "Nature",
    url: svgDataUrl(`
      <svg xmlns="http://www.w3.org/2000/svg" width="1000" height="1000" viewBox="0 0 1000 1000">
        <rect width="1000" height="1000" fill="#dff2e0"/>
        <g fill="#2f8f5b" opacity="0.45">
          <path d="M-40 120c220 10 360 130 380 320C180 420 40 300-40 120z"/>
          <path d="M1040 140c-220 10-360 130-380 320 160-20 300-140 380-320z"/>
          <path d="M-30 900c200-20 340-140 360-330-160 20-300 150-360 330z"/>
        </g>
        <g fill="#7cc79a" opacity="0.45">
          <path d="M1040 880c-200-20-340-140-360-330 160 20 300 150 360 330z"/>
        </g>
      </svg>`),
  },

  {
    id: "office-modern",
    name: "Modern office",
    category: "Office",
    url: svgDataUrl(`
      <svg xmlns="http://www.w3.org/2000/svg" width="1000" height="1000" viewBox="0 0 1000 1000">
        <defs>
          <linearGradient id="o" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stop-color="#eef1f7"/><stop offset="1" stop-color="#cfd6e4"/>
          </linearGradient>
        </defs>
        <rect width="1000" height="1000" fill="url(#o)"/>
        <rect x="90" y="120" width="360" height="420" rx="14" fill="#ffffff" opacity="0.6"/>
        <rect x="500" y="120" width="410" height="420" rx="14" fill="#b9c6dc" opacity="0.6"/>
        <rect x="0" y="720" width="1000" height="280" fill="#aab4c6" opacity="0.55"/>
        <rect x="60" y="760" width="420" height="180" rx="18" fill="#7b879b" opacity="0.45"/>
      </svg>`),
  },
  {
    id: "office-desk",
    name: "Desk corner",
    category: "Office",
    url: svgDataUrl(`
      <svg xmlns="http://www.w3.org/2000/svg" width="1000" height="1000" viewBox="0 0 1000 1000">
        <rect width="1000" height="1000" fill="#f2ede6"/>
        <rect x="0" y="0" width="1000" height="620" fill="#e6dccd"/>
        <rect x="640" y="120" width="260" height="330" rx="12" fill="#cdd9e5" opacity="0.9"/>
        <rect x="0" y="620" width="1000" height="380" fill="#c9b79c"/>
        <rect x="90" y="550" width="300" height="40" rx="8" fill="#f7f3ec"/>
        <circle cx="180" cy="530" r="34" fill="#fff" opacity="0.8"/>
      </svg>`),
  },

  {
    id: "home-living",
    name: "Living room",
    category: "Home",
    url: svgDataUrl(`
      <svg xmlns="http://www.w3.org/2000/svg" width="1000" height="1000" viewBox="0 0 1000 1000">
        <rect width="1000" height="1000" fill="#f6efe8"/>
        <rect x="0" y="0" width="1000" height="700" fill="#eee1d3"/>
        <rect x="120" y="130" width="330" height="300" rx="10" fill="#dbe8ee"/>
        <rect x="0" y="700" width="1000" height="300" fill="#d9c6b0"/>
        <rect x="520" y="520" width="420" height="200" rx="26" fill="#c9b6a1"/>
        <ellipse cx="500" cy="760" rx="420" ry="80" fill="#c8b49d" opacity="0.7"/>
      </svg>`),
  },
  {
    id: "home-kitchen",
    name: "Kitchen shelf",
    category: "Home",
    url: svgDataUrl(`
      <svg xmlns="http://www.w3.org/2000/svg" width="1000" height="1000" viewBox="0 0 1000 1000">
        <rect width="1000" height="1000" fill="#f4f6f4"/>
        <rect x="0" y="0" width="1000" height="640" fill="#e6ebe6"/>
        <rect x="80" y="140" width="840" height="26" rx="6" fill="#c6b49b"/>
        <g fill="#a9bfae">
          <rect x="130" y="60" width="70" height="80" rx="8"/>
          <rect x="240" y="80" width="60" height="60" rx="8"/>
          <rect x="700" y="50" width="80" height="90" rx="8"/>
        </g>
        <rect x="0" y="640" width="1000" height="360" fill="#cfd8cf"/>
      </svg>`),
  },

  {
    id: "beach",
    name: "Beach",
    category: "Beach",
    url: svgDataUrl(`
      <svg xmlns="http://www.w3.org/2000/svg" width="1000" height="1000" viewBox="0 0 1000 1000">
        <defs>
          <linearGradient id="sky" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stop-color="#9fd8ff"/><stop offset="1" stop-color="#e8f7ff"/>
          </linearGradient>
          <linearGradient id="sea" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stop-color="#3aa6cf"/><stop offset="1" stop-color="#8fd6e6"/>
          </linearGradient>
        </defs>
        <rect width="1000" height="1000" fill="url(#sky)"/>
        <circle cx="760" cy="200" r="90" fill="#fff4c2"/>
        <rect x="0" y="430" width="1000" height="240" fill="url(#sea)"/>
        <path d="M0 670h1000v330H0z" fill="#f3e2bd"/>
        <path d="M0 670c180 30 360 30 520 0 160-30 320-30 480 0v60H0z" fill="#ffffff" opacity="0.6"/>
      </svg>`),
  },
  {
    id: "beach-pool",
    name: "Poolside",
    category: "Beach",
    url: svgDataUrl(`
      <svg xmlns="http://www.w3.org/2000/svg" width="1000" height="1000" viewBox="0 0 1000 1000">
        <rect width="1000" height="1000" fill="#e8f6fb"/>
        <rect x="0" y="0" width="1000" height="420" fill="#cfeefb"/>
        <rect x="0" y="420" width="1000" height="280" fill="#59c3e6"/>
        <path d="M0 420c80 30 180 30 260 0s180-30 260 0 180 30 260 0 140-20 220 0" stroke="#bfeefc" stroke-width="14" fill="none"/>
        <rect x="0" y="700" width="1000" height="300" fill="#f0e3c8"/>
      </svg>`),
  },

  {
    id: "sky-clouds",
    name: "Clouds",
    category: "Sky",
    url: svgDataUrl(`
      <svg xmlns="http://www.w3.org/2000/svg" width="1000" height="1000" viewBox="0 0 1000 1000">
        <defs>
          <linearGradient id="s" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stop-color="#7dc4f8"/><stop offset="0.7" stop-color="#cfe9fd"/><stop offset="1" stop-color="#f4fbff"/>
          </linearGradient>
        </defs>
        <rect width="1000" height="1000" fill="url(#s)"/>
        <g fill="#ffffff" opacity="0.85">
          <ellipse cx="260" cy="260" rx="150" ry="60"/>
          <ellipse cx="360" cy="230" rx="110" ry="70"/>
          <ellipse cx="720" cy="400" rx="170" ry="64"/>
          <ellipse cx="620" cy="370" rx="110" ry="58"/>
          <ellipse cx="500" cy="720" rx="220" ry="70" opacity="0.6"/>
        </g>
      </svg>`),
  },
  {
    id: "sky-sunset",
    name: "Golden hour",
    category: "Sky",
    url: svgDataUrl(`
      <svg xmlns="http://www.w3.org/2000/svg" width="1000" height="1000" viewBox="0 0 1000 1000">
        <defs>
          <linearGradient id="g" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stop-color="#3b2f63"/><stop offset="0.45" stop-color="#f2748a"/><stop offset="0.75" stop-color="#ffb56b"/><stop offset="1" stop-color="#ffe7b8"/>
          </linearGradient>
        </defs>
        <rect width="1000" height="1000" fill="url(#g)"/>
        <circle cx="500" cy="700" r="120" fill="#fff1c9" opacity="0.9"/>
        <path d="M0 800h1000v200H0z" fill="#2b2140" opacity="0.45"/>
      </svg>`),
  },

  {
    id: "luxury-marble",
    name: "Marble",
    category: "Luxury",
    url: svgDataUrl(`
      <svg xmlns="http://www.w3.org/2000/svg" width="1000" height="1000" viewBox="0 0 1000 1000">
        <rect width="1000" height="1000" fill="#f7f5f2"/>
        <g stroke="#d9d3ca" stroke-width="3" fill="none" opacity="0.9">
          <path d="M-40 220c240 60 360 10 520 120s300 180 560 120"/>
          <path d="M-40 520c260-40 380 80 560 40s280-160 520-100"/>
          <path d="M-40 780c220 60 400-40 580 60s300 80 500 20"/>
        </g>
        <g stroke="#c9c1b6" stroke-width="2" fill="none" opacity="0.7">
          <path d="M120 0c40 200-40 320 40 520s160 380 120 520"/>
          <path d="M760 0c-60 220 40 340-40 540s-120 320-60 480"/>
        </g>
      </svg>`),
  },
  {
    id: "luxury-gold",
    name: "Gold silk",
    category: "Luxury",
    url: svgDataUrl(`
      <svg xmlns="http://www.w3.org/2000/svg" width="1000" height="1000" viewBox="0 0 1000 1000">
        <defs>
          <linearGradient id="gold" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stop-color="#f7e6b0"/><stop offset="0.5" stop-color="#c9a24a"/><stop offset="1" stop-color="#f5e2a6"/>
          </linearGradient>
        </defs>
        <rect width="1000" height="1000" fill="url(#gold)"/>
        <g fill="#ffffff" opacity="0.22">
          <path d="M0 300c220 90 380 40 520 120s280 160 480 100v120c-220 60-360-40-520-110S220 470 0 420z"/>
          <path d="M0 660c240 90 400 30 540 110s300 140 460 90v140H0z"/>
        </g>
      </svg>`),
  },

  {
    id: "abstract-waves",
    name: "Waves",
    category: "Abstract",
    url: svgDataUrl(`
      <svg xmlns="http://www.w3.org/2000/svg" width="1000" height="1000" viewBox="0 0 1000 1000">
        <defs>
          <linearGradient id="a" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stop-color="#eef2ff"/><stop offset="1" stop-color="#e0e7ff"/>
          </linearGradient>
        </defs>
        <rect width="1000" height="1000" fill="url(#a)"/>
        <g fill="none" stroke-width="28" opacity="0.55">
          <path d="M-100 300c180-140 320 140 500 0s320 140 500 0" stroke="#a5b4fc"/>
          <path d="M-100 460c180-140 320 140 500 0s320 140 500 0" stroke="#c4b5fd"/>
          <path d="M-100 620c180-140 320 140 500 0s320 140 500 0" stroke="#93c5fd"/>
          <path d="M-100 780c180-140 320 140 500 0s320 140 500 0" stroke="#bae6fd"/>
        </g>
      </svg>`),
  },
  {
    id: "abstract-blobs",
    name: "Soft blobs",
    category: "Abstract",
    url: svgDataUrl(`
      <svg xmlns="http://www.w3.org/2000/svg" width="1000" height="1000" viewBox="0 0 1000 1000">
        <rect width="1000" height="1000" fill="#fbfaff"/>
        <g opacity="0.75">
          <circle cx="230" cy="230" r="220" fill="#e0d9ff"/>
          <circle cx="760" cy="300" r="190" fill="#cfe6ff"/>
          <circle cx="500" cy="800" r="260" fill="#ffe0ef"/>
        </g>
      </svg>`),
  },

  {
    id: "social-gradient",
    name: "Social gradient",
    category: "Social media",
    url: svgDataUrl(`
      <svg xmlns="http://www.w3.org/2000/svg" width="1080" height="1080" viewBox="0 0 1080 1080">
        <defs>
          <linearGradient id="s" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stop-color="#833ab4"/><stop offset="0.5" stop-color="#fd1d1d"/><stop offset="1" stop-color="#fcb045"/>
          </linearGradient>
        </defs>
        <rect width="1080" height="1080" fill="url(#s)"/>
        <circle cx="820" cy="240" r="260" fill="#fff" opacity="0.12"/>
        <circle cx="240" cy="860" r="320" fill="#fff" opacity="0.1"/>
      </svg>`),
  },
  {
    id: "social-dark",
    name: "Dark neon",
    category: "Social media",
    url: svgDataUrl(`
      <svg xmlns="http://www.w3.org/2000/svg" width="1080" height="1080" viewBox="0 0 1080 1080">
        <rect width="1080" height="1080" fill="#0b1020"/>
        <circle cx="860" cy="200" r="280" fill="#6d5cff" opacity="0.55"/>
        <circle cx="200" cy="900" r="320" fill="#18c7d8" opacity="0.35"/>
        <rect width="1080" height="1080" fill="none" stroke="#7a63f6" stroke-width="20" opacity="0.4"/>
      </svg>`),
  },

  {
    id: "product-plinth",
    name: "Product plinth",
    category: "Product",
    url: svgDataUrl(`
      <svg xmlns="http://www.w3.org/2000/svg" width="1000" height="1000" viewBox="0 0 1000 1000">
        <defs>
          <linearGradient id="b" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stop-color="#f5f6fa"/><stop offset="1" stop-color="#dfe3ee"/>
          </linearGradient>
        </defs>
        <rect width="1000" height="1000" fill="url(#b)"/>
        <ellipse cx="500" cy="760" rx="300" ry="70" fill="#c3c9da" opacity="0.7"/>
        <rect x="300" y="600" width="400" height="150" rx="16" fill="#ffffff" opacity="0.9"/>
        <ellipse cx="500" cy="620" rx="200" ry="46" fill="#ffffff"/>
      </svg>`),
  },
  {
    id: "product-dark",
    name: "Dark product",
    category: "Product",
    url: svgDataUrl(`
      <svg xmlns="http://www.w3.org/2000/svg" width="1000" height="1000" viewBox="0 0 1000 1000">
        <defs>
          <radialGradient id="d" cx="0.5" cy="0.35" r="0.75">
            <stop offset="0" stop-color="#3a3f52"/><stop offset="1" stop-color="#10131c"/>
          </radialGradient>
        </defs>
        <rect width="1000" height="1000" fill="url(#d)"/>
        <ellipse cx="500" cy="800" rx="340" ry="70" fill="#000" opacity="0.45"/>
        <ellipse cx="500" cy="700" rx="240" ry="50" fill="#ffffff" opacity="0.06"/>
      </svg>`),
  },
];

const backgroundsById = new Map(BACKGROUND_LIBRARY.map((item) => [item.id, item]));

export function backgroundById(id: string): BackgroundPreset | undefined {
  return backgroundsById.get(id);
}

export function backgroundCategories(): string[] {
  return Array.from(new Set(BACKGROUND_LIBRARY.map((item) => item.category)));
}

/* ------------------------------------------------------------------ */
/* Filters                                                             */
/* ------------------------------------------------------------------ */

export type FilterPreset = {
  id: string;
  name: string;
  category: string;
  adjustments: Partial<Adjustments>;
};

export const FILTERS: FilterPreset[] = [
  { id: "original", name: "Original", category: "Original", adjustments: {} },
  {
    id: "natural",
    name: "Natural",
    category: "Natural",
    adjustments: { contrast: 6, saturation: 8, brightness: 2 },
  },
  {
    id: "sunlight",
    name: "Sunlight",
    category: "Natural",
    adjustments: { temperature: 14, brightness: 6, shadows: 8 },
  },
  {
    id: "warm",
    name: "Warm",
    category: "Warm",
    adjustments: { temperature: 26, saturation: 8, brightness: 3 },
  },
  {
    id: "golden",
    name: "Golden",
    category: "Warm",
    adjustments: { temperature: 34, exposure: 6, highlights: 10, saturation: 6 },
  },
  {
    id: "cool",
    name: "Cool",
    category: "Cool",
    adjustments: { temperature: -26, tint: -4, contrast: 6 },
  },
  {
    id: "arctic",
    name: "Arctic",
    category: "Cool",
    adjustments: { temperature: -34, exposure: 5, saturation: -6, highlights: 8 },
  },
  {
    id: "vintage",
    name: "Vintage",
    category: "Vintage",
    adjustments: { saturation: -22, temperature: 20, contrast: -8, shadows: 16, brightness: 3 },
  },
  {
    id: "faded",
    name: "Faded film",
    category: "Vintage",
    adjustments: { saturation: -16, contrast: -16, brightness: 8, shadows: 14, temperature: 8 },
  },
  {
    id: "mono",
    name: "Black & white",
    category: "Black and White",
    adjustments: { saturation: -100, contrast: 12 },
  },
  {
    id: "noir",
    name: "Noir",
    category: "Black and White",
    adjustments: { saturation: -100, contrast: 30, shadows: -18, highlights: 10 },
  },
  {
    id: "cinematic",
    name: "Cinematic",
    category: "Cinematic",
    adjustments: { contrast: 16, saturation: -10, shadows: -12, highlights: 10, temperature: -6 },
  },
  {
    id: "teal-orange",
    name: "Teal & orange",
    category: "Cinematic",
    adjustments: { contrast: 12, temperature: 18, tint: -8, saturation: 10, shadows: 8 },
  },
  {
    id: "bright",
    name: "Bright",
    category: "Bright",
    adjustments: { brightness: 12, exposure: 9, contrast: 4 },
  },
  {
    id: "air",
    name: "Airy",
    category: "Bright",
    adjustments: { exposure: 14, shadows: 18, contrast: -4, saturation: -4 },
  },
  {
    id: "portrait",
    name: "Portrait",
    category: "Portrait",
    adjustments: { brightness: 6, contrast: 4, saturation: 5, shadows: 10, sharpness: 14 },
  },
  {
    id: "soft-skin",
    name: "Soft skin",
    category: "Portrait",
    adjustments: { brightness: 8, contrast: -4, shadows: 14, sharpness: 6, temperature: 6 },
  },
  {
    id: "dramatic",
    name: "Dramatic",
    category: "Dramatic",
    adjustments: { contrast: 26, saturation: -12, shadows: -20, highlights: 12, sharpness: 18 },
  },
  {
    id: "punch",
    name: "Punch",
    category: "Dramatic",
    adjustments: { contrast: 18, saturation: 22, sharpness: 12 },
  },
];

export function filterById(id: string): FilterPreset {
  return FILTERS.find((filter) => filter.id === id) ?? FILTERS[0];
}

export function filterCategories(): string[] {
  return Array.from(new Set(FILTERS.map((filter) => filter.category)));
}

/* ------------------------------------------------------------------ */
/* Text, shapes, stickers                                              */
/* ------------------------------------------------------------------ */

export const FONT_OPTIONS = [
  { label: "Inter (modern)", value: "Inter, system-ui, sans-serif" },
  { label: "Helvetica / Arial", value: "Helvetica, Arial, sans-serif" },
  { label: "Georgia (serif)", value: "Georgia, 'Times New Roman', serif" },
  { label: "Times", value: "'Times New Roman', Times, serif" },
  { label: "Courier (mono)", value: "'Courier New', Courier, monospace" },
  { label: "Impact (poster)", value: "Impact, 'Arial Black', sans-serif" },
  { label: "Trebuchet", value: "'Trebuchet MS', sans-serif" },
  { label: "Verdana", value: "Verdana, Geneva, sans-serif" },
];

export const TEXT_PRESETS = [
  { label: "Heading", text: "Your headline", size: 0.1, bold: true, color: "#111827", font: FONT_OPTIONS[0].value },
  { label: "Subtitle", text: "A short supporting line", size: 0.055, bold: false, color: "#374151", font: FONT_OPTIONS[0].value },
  { label: "Caption", text: "Small caption text", size: 0.032, bold: false, color: "#4b5563", font: FONT_OPTIONS[0].value },
  { label: "Sale", text: "50% OFF", size: 0.12, bold: true, color: "#ffffff", font: FONT_OPTIONS[5].value },
  { label: "Product title", text: "Product name", size: 0.06, bold: true, color: "#111827", font: FONT_OPTIONS[1].value },
];

export const SHAPE_OPTIONS: { shape: ShapeKind; label: string }[] = [
  { shape: "rect", label: "Rectangle" },
  { shape: "circle", label: "Circle" },
  { shape: "line", label: "Line" },
  { shape: "arrow", label: "Arrow" },
  { shape: "triangle", label: "Triangle" },
];

function sticker(svg: string): string {
  return svgDataUrl(svg);
}

export type StickerDefinition = { id: string; name: string; category: string; url: string };

export const STICKERS: StickerDefinition[] = [
  {
    id: "star-gold",
    name: "Gold star",
    category: "Stars",
    url: sticker(`<svg xmlns="http://www.w3.org/2000/svg" width="200" height="200" viewBox="0 0 200 200"><path d="M100 14l24 56 60 6-45 40 13 59-52-31-52 31 13-59-45-40 60-6z" fill="#fbbf24" stroke="#f59e0b" stroke-width="6" stroke-linejoin="round"/></svg>`),
  },
  {
    id: "star-sparkle",
    name: "Sparkle",
    category: "Stars",
    url: sticker(`<svg xmlns="http://www.w3.org/2000/svg" width="200" height="200" viewBox="0 0 200 200"><path d="M100 12l18 58 58 18-58 18-18 58-18-58-58-18 58-18z" fill="#7a63f6"/><path d="M158 24l7 22 22 7-22 7-7 22-7-22-22-7 22-7z" fill="#a5b4fc"/></svg>`),
  },
  {
    id: "star-3d",
    name: "Sparkle burst",
    category: "Stars",
    url: sticker(`<svg xmlns="http://www.w3.org/2000/svg" width="200" height="200" viewBox="0 0 200 200"><g fill="#fde68a"><path d="M100 20l9 32 32 9-32 9-9 32-9-32-32-9 32-9z"/><path d="M52 96l6 20 20 6-20 6-6 20-6-20-20-6 20-6z"/><path d="M148 112l6 20 20 6-20 6-6 20-6-20-20-6 20-6z"/></g></svg>`),
  },
  {
    id: "heart-red",
    name: "Heart",
    category: "Hearts",
    url: sticker(`<svg xmlns="http://www.w3.org/2000/svg" width="200" height="200" viewBox="0 0 200 200"><path d="M100 172S26 128 26 78a40 40 0 0174-21 40 40 0 0174 21c0 50-74 94-74 94z" fill="#ef4444"/></svg>`),
  },
  {
    id: "heart-outline",
    name: "Heart outline",
    category: "Hearts",
    url: sticker(`<svg xmlns="http://www.w3.org/2000/svg" width="200" height="200" viewBox="0 0 200 200"><path d="M100 166S34 126 34 82a34 34 0 0166-16 34 34 0 0166 16c0 44-66 84-66 84z" fill="none" stroke="#ffffff" stroke-width="12"/></svg>`),
  },
  {
    id: "arrow-right",
    name: "Arrow",
    category: "Arrows",
    url: sticker(`<svg xmlns="http://www.w3.org/2000/svg" width="220" height="120" viewBox="0 0 220 120"><path d="M12 60h150" stroke="#111827" stroke-width="14" stroke-linecap="round"/><path d="M144 22l58 38-58 38" fill="none" stroke="#111827" stroke-width="14" stroke-linecap="round" stroke-linejoin="round"/></svg>`),
  },
  {
    id: "arrow-curve",
    name: "Curved arrow",
    category: "Arrows",
    url: sticker(`<svg xmlns="http://www.w3.org/2000/svg" width="200" height="200" viewBox="0 0 200 200"><path d="M30 168c0-70 40-116 116-122" fill="none" stroke="#ffffff" stroke-width="12" stroke-linecap="round"/><path d="M120 18l40 26-34 32" fill="none" stroke="#ffffff" stroke-width="12" stroke-linecap="round" stroke-linejoin="round"/></svg>`),
  },
  {
    id: "badge-sale",
    name: "Sale badge",
    category: "Badges",
    url: sticker(`<svg xmlns="http://www.w3.org/2000/svg" width="220" height="220" viewBox="0 0 220 220"><circle cx="110" cy="110" r="104" fill="#ef4444"/><circle cx="110" cy="110" r="88" fill="none" stroke="#ffffff" stroke-width="5" stroke-dasharray="10 8"/><text x="110" y="100" text-anchor="middle" font-family="Arial Black, Arial" font-size="42" fill="#fff">SALE</text><text x="110" y="142" text-anchor="middle" font-family="Arial" font-size="28" fill="#fff">-50%</text></svg>`),
  },
  {
    id: "badge-new",
    name: "New badge",
    category: "Badges",
    url: sticker(`<svg xmlns="http://www.w3.org/2000/svg" width="220" height="220" viewBox="0 0 220 220"><path d="M110 10l26 18 31-4 10 30 26 18-14 28 8 31-28 14-14 28-31-8-28 14-18-26-31-8 4-31-18-26 26-18 8-31 31 4z" fill="#7a63f6"/><text x="110" y="122" text-anchor="middle" font-family="Arial Black, Arial" font-size="40" fill="#fff">NEW</text></svg>`),
  },
  {
    id: "social-instagram",
    name: "Instagram",
    category: "Social",
    url: sticker(`<svg xmlns="http://www.w3.org/2000/svg" width="200" height="200" viewBox="0 0 200 200"><rect x="18" y="18" width="164" height="164" rx="46" fill="#ffffff"/><rect x="34" y="34" width="132" height="132" rx="36" fill="none" stroke="#e1306c" stroke-width="12"/><circle cx="100" cy="100" r="34" fill="none" stroke="#e1306c" stroke-width="12"/><circle cx="146" cy="54" r="10" fill="#e1306c"/></svg>`),
  },
  {
    id: "social-youtube",
    name: "YouTube",
    category: "Social",
    url: sticker(`<svg xmlns="http://www.w3.org/2000/svg" width="240" height="180" viewBox="0 0 240 180"><rect x="12" y="34" width="216" height="112" rx="30" fill="#ff0000"/><path d="M100 68l46 22-46 22z" fill="#fff"/></svg>`),
  },
  {
    id: "social-tiktok",
    name: "TikTok",
    category: "Social",
    url: sticker(`<svg xmlns="http://www.w3.org/2000/svg" width="200" height="200" viewBox="0 0 200 200"><circle cx="100" cy="100" r="96" fill="#111827"/><path d="M118 46v70a26 26 0 11-26-26" fill="none" stroke="#ffffff" stroke-width="12"/><path d="M118 52c6 18 20 28 38 30" fill="none" stroke="#22d3ee" stroke-width="12"/><path d="M118 46c6 18 20 28 38 30" fill="none" stroke="#f472b6" stroke-width="6" transform="translate(2 6)"/></svg>`),
  },
  {
    id: "deco-circle",
    name: "Circle outline",
    category: "Decorative",
    url: sticker(`<svg xmlns="http://www.w3.org/2000/svg" width="200" height="200" viewBox="0 0 200 200"><circle cx="100" cy="100" r="86" fill="none" stroke="#ffffff" stroke-width="10"/></svg>`),
  },
  {
    id: "deco-confetti",
    name: "Confetti",
    category: "Decorative",
    url: sticker(`<svg xmlns="http://www.w3.org/2000/svg" width="200" height="200" viewBox="0 0 200 200"><g><rect x="30" y="40" width="14" height="26" rx="4" fill="#f472b6" transform="rotate(-24 37 53)"/><rect x="120" y="30" width="14" height="26" rx="4" fill="#38bdf8" transform="rotate(32 127 43)"/><rect x="70" y="120" width="14" height="26" rx="4" fill="#facc15" transform="rotate(18 77 133)"/><rect x="140" y="120" width="14" height="26" rx="4" fill="#34d399" transform="rotate(-40 147 133)"/><circle cx="52" cy="140" r="8" fill="#a855f7"/><circle cx="156" cy="66" r="8" fill="#fb7185"/><circle cx="24" cy="100" r="6" fill="#22d3ee"/></g></svg>`),
  },
  {
    id: "deco-leaf",
    name: "Leaf",
    category: "Decorative",
    url: sticker(`<svg xmlns="http://www.w3.org/2000/svg" width="160" height="200" viewBox="0 0 160 200"><path d="M80 12C24 48 18 124 76 188c60-64 58-140 4-176z" fill="#34d399"/><path d="M80 26v150" stroke="#047857" stroke-width="6"/></svg>`),
  },
];

export function stickerById(id: string): StickerDefinition | undefined {
  return STICKERS.find((item) => item.id === id);
}

export function stickerCategories(): string[] {
  return Array.from(new Set(STICKERS.map((item) => item.category)));
}

/* ------------------------------------------------------------------ */
/* Sizes                                                               */
/* ------------------------------------------------------------------ */

export type SizePreset = { id: string; label: string; group: string; width: number; height: number };

export const SIZE_PRESETS: SizePreset[] = [
  { id: "256", label: "256 × 256", group: "Square", width: 256, height: 256 },
  { id: "512", label: "512 × 512", group: "Square", width: 512, height: 512 },
  { id: "1024", label: "1024 × 1024", group: "Square", width: 1024, height: 1024 },
  { id: "1080", label: "1080 × 1080", group: "Square", width: 1080, height: 1080 },
  { id: "1080x1350", label: "1080 × 1350", group: "Portrait", width: 1080, height: 1350 },
  { id: "1080x1920", label: "1080 × 1920", group: "Portrait", width: 1080, height: 1920 },
  { id: "1920x1080", label: "1920 × 1080", group: "Landscape", width: 1920, height: 1080 },
  { id: "instagram-post", label: "Instagram post", group: "Social", width: 1080, height: 1080 },
  { id: "instagram-story", label: "Instagram story", group: "Social", width: 1080, height: 1920 },
  { id: "youtube-thumb", label: "YouTube thumbnail", group: "Social", width: 1280, height: 720 },
  { id: "facebook-post", label: "Facebook post", group: "Social", width: 1200, height: 630 },
  { id: "profile-picture", label: "Profile picture", group: "Social", width: 400, height: 400 },
  { id: "website-banner", label: "Website banner", group: "Web", width: 1500, height: 500 },
  { id: "product-image", label: "Product image", group: "Shop", width: 1000, height: 1000 },
];

export const ASPECT_RATIOS: { id: string; label: string; value: number | null }[] = [
  { id: "free", label: "Free", value: null },
  { id: "1:1", label: "1:1", value: 1 },
  { id: "4:5", label: "4:5", value: 4 / 5 },
  { id: "3:4", label: "3:4", value: 3 / 4 },
  { id: "16:9", label: "16:9", value: 16 / 9 },
  { id: "9:16", label: "9:16", value: 9 / 16 },
  { id: "3:2", label: "3:2", value: 3 / 2 },
  { id: "2:3", label: "2:3", value: 2 / 3 },
];
