import type { ReactNode } from "react";
import { Icon } from "../../components/Icon";

export function PanelSection({
  title,
  description,
  children,
  actions,
}: {
  title?: string;
  description?: string;
  children: ReactNode;
  actions?: ReactNode;
}) {
  return (
    <section className="space-y-3">
      {(title || actions) && (
        <div className="flex items-center justify-between gap-2">
          <div>
            {title && (
              <h3 className="text-[11px] font-bold uppercase tracking-[0.14em] text-ink-muted">{title}</h3>
            )}
            {description && <p className="mt-0.5 text-xs text-ink-muted">{description}</p>}
          </div>
          {actions}
        </div>
      )}
      {children}
    </section>
  );
}

export function Slider({
  label,
  value,
  min,
  max,
  step = 1,
  suffix = "",
  onChange,
  onCommitKey,
  disabled,
}: {
  label: string;
  value: number;
  min: number;
  max: number;
  step?: number;
  suffix?: string;
  onChange: (value: number) => void;
  onCommitKey?: string;
  disabled?: boolean;
}) {
  return (
    <label className={`block ${disabled ? "opacity-50" : ""}`}>
      <span className="flex items-center justify-between gap-2">
        <span className="text-xs font-semibold text-ink-soft">{label}</span>
        <span className="min-w-[3.2rem] rounded-md bg-mist px-1.5 py-0.5 text-right text-[11px] font-semibold tabular-nums text-ink">
          {Math.round(value * 100) / 100}
          {suffix}
        </span>
      </span>
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        disabled={disabled}
        onChange={(event) => onChange(Number(event.target.value))}
        onDoubleClick={() => onChange(0)}
        aria-label={label}
        data-commit-key={onCommitKey}
        className="mt-1.5 h-1.5 w-full cursor-pointer appearance-none rounded-full bg-ink/10 accent-brand-600"
      />
    </label>
  );
}

export function NumberField({
  label,
  value,
  min = 1,
  max = 20000,
  onChange,
  suffix,
}: {
  label: string;
  value: number;
  min?: number;
  max?: number;
  onChange: (value: number) => void;
  suffix?: string;
}) {
  return (
    <label className="block">
      <span className="text-xs font-semibold text-ink-soft">{label}</span>
      <span className="relative mt-1 flex items-center">
        <input
          type="number"
          value={Number.isFinite(value) ? Math.round(value) : ""}
          min={min}
          max={max}
          onChange={(event) => {
            const next = Number(event.target.value);
            if (Number.isFinite(next)) onChange(next);
          }}
          className="w-full rounded-lg border border-ink/10 bg-white px-2.5 py-2 text-sm font-medium text-ink outline-none transition focus:border-brand-400"
        />
        {suffix && (
          <span className="pointer-events-none absolute right-2.5 text-[11px] font-medium text-ink-muted">
            {suffix}
          </span>
        )}
      </span>
    </label>
  );
}

export function Toggle({
  label,
  checked,
  onChange,
  hint,
}: {
  label: string;
  checked: boolean;
  onChange: (value: boolean) => void;
  hint?: string;
}) {
  return (
    <label className="flex cursor-pointer items-start justify-between gap-3 rounded-lg border border-ink/[0.07] px-3 py-2">
      <span>
        <span className="block text-xs font-semibold text-ink">{label}</span>
        {hint && <span className="mt-0.5 block text-[11px] leading-4 text-ink-muted">{hint}</span>}
      </span>
      <span className="relative mt-0.5 shrink-0">
        <input
          type="checkbox"
          className="peer sr-only"
          checked={checked}
          onChange={(event) => onChange(event.target.checked)}
        />
        <span className="block h-5 w-9 rounded-full bg-ink/15 transition peer-checked:bg-brand-600" />
        <span className="pointer-events-none absolute left-0.5 top-0.5 h-4 w-4 rounded-full bg-white shadow transition peer-checked:translate-x-4" />
      </span>
    </label>
  );
}

export function ColorField({
  label,
  value,
  onChange,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
}) {
  return (
    <label className="block">
      <span className="text-xs font-semibold text-ink-soft">{label}</span>
      <span className="mt-1 flex items-center gap-2 rounded-lg border border-ink/10 bg-white p-1.5">
        <input
          type="color"
          value={value}
          onChange={(event) => onChange(event.target.value)}
          aria-label={`${label} colour picker`}
          className="h-8 w-9 cursor-pointer rounded-md border-0 bg-transparent p-0"
        />
        <input
          type="text"
          value={value}
          onChange={(event) => {
            const next = event.target.value.trim();
            if (/^#[0-9a-fA-F]{0,6}$/.test(next)) onChange(next);
          }}
          spellCheck={false}
          className="w-full bg-transparent text-xs font-semibold uppercase tracking-wide text-ink outline-none"
          aria-label={`${label} hex value`}
        />
      </span>
    </label>
  );
}

export function Segmented<T extends string | number>({
  options,
  value,
  onChange,
  className = "",
}: {
  options: { value: T; label: string; disabled?: boolean }[];
  value: T;
  onChange: (value: T) => void;
  className?: string;
}) {
  return (
    <div className={`inline-flex w-full rounded-lg bg-mist p-1 ${className}`} role="group">
      {options.map((option) => (
        <button
          key={String(option.value)}
          type="button"
          disabled={option.disabled}
          onClick={() => onChange(option.value)}
          aria-pressed={value === option.value}
          className={`flex-1 rounded-md px-2 py-1.5 text-[11px] font-semibold transition disabled:opacity-40 ${
            value === option.value ? "bg-white text-ink shadow-soft" : "text-ink-muted hover:text-ink"
          }`}
        >
          {option.label}
        </button>
      ))}
    </div>
  );
}

export function ActionButton({
  children,
  onClick,
  icon,
  variant = "secondary",
  disabled,
  className = "",
  title,
}: {
  children: ReactNode;
  onClick?: () => void;
  icon?: React.ComponentProps<typeof Icon>["name"];
  variant?: "primary" | "secondary" | "danger" | "ghost";
  disabled?: boolean;
  className?: string;
  title?: string;
}) {
  const styles = {
    primary: "bg-brand-600 text-white hover:bg-brand-700",
    secondary: "border border-ink/10 bg-white text-ink hover:border-brand-300 hover:bg-brand-50",
    danger: "border border-red-200 bg-white text-red-600 hover:bg-red-50",
    ghost: "text-ink-soft hover:bg-mist hover:text-ink",
  }[variant];
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled}
      title={title}
      className={`inline-flex items-center justify-center gap-1.5 rounded-lg px-3 py-2 text-xs font-semibold transition disabled:cursor-not-allowed disabled:opacity-50 ${styles} ${className}`}
    >
      {icon && <Icon name={icon} size={14} />}
      {children}
    </button>
  );
}

export function Swatch({
  color,
  active,
  onClick,
  label,
}: {
  color: string;
  active?: boolean;
  onClick: () => void;
  label: string;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      title={label}
      aria-label={label}
      aria-pressed={active}
      className={`h-8 w-8 rounded-lg border transition hover:scale-105 ${
        active ? "border-brand-500 ring-2 ring-brand-200" : "border-ink/10"
      }`}
      style={{ backgroundColor: color }}
    />
  );
}

export function EmptyNote({ children }: { children: ReactNode }) {
  return (
    <p className="rounded-lg border border-dashed border-ink/15 bg-mist/50 px-3 py-4 text-center text-xs leading-5 text-ink-muted">
      {children}
    </p>
  );
}
