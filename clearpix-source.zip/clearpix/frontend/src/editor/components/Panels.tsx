import { useEffect, useRef, useState } from "react";
import { Icon } from "../../components/Icon";
import { BackgroundRemover } from "../../features/tool/BackgroundRemover";
import {
  DEFAULT_ADJUSTMENTS,
  createShapeLayer,
  createStickerLayer,
  createTextLayer,
  type CropRect,
  type EditorState,
  type Layer,
  type ShapeLayer,
  type ShapeKind,
  type TextLayer,
} from "../model";
import {
  ASPECT_RATIOS,
  BACKGROUND_LIBRARY,
  FONT_OPTIONS,
  FILTERS,
  GRADIENT_PRESETS,
  SHAPE_OPTIONS,
  SIZE_PRESETS,
  SOLID_COLORS,
  STICKERS,
  TEXT_PRESETS,
  backgroundCategories,
  stickerCategories,
} from "../presets";
import { renderDocument } from "../render";
import type { useEditorWorkspace } from "../workspace";
import {
  ActionButton,
  ColorField,
  EmptyNote,
  NumberField,
  PanelSection,
  Segmented,
  Slider,
  Swatch,
  Toggle,
} from "./controls";

export type Workspace = ReturnType<typeof useEditorWorkspace>;

export type CropControls = {
  draft: CropRect | null;
  setDraft: (rect: CropRect | null) => void;
  aspect: number | null;
  setAspect: (value: number | null) => void;
  apply: () => void;
  reset: () => void;
};

type PanelProps = {
  ws: Workspace;
  selectedId: string | null;
  setSelectedId: (id: string | null) => void;
  crop: CropControls;
  onReplaceImage: () => void;
};

export function ToolPanel({ tool, ...props }: PanelProps & { tool: string }) {
  switch (tool) {
    case "background":
      return <BackgroundPanel {...props} />;
    case "resize":
      return <ResizePanel {...props} />;
    case "crop":
      return <CropPanel {...props} />;
    case "rotate":
      return <RotatePanel {...props} />;
    case "adjust":
      return <AdjustPanel {...props} />;
    case "filters":
      return <FiltersPanel {...props} />;
    case "text":
      return <TextPanel {...props} />;
    case "stickers":
      return <StickersPanel {...props} />;
    case "layers":
      return <LayersPanel {...props} />;
    case "shadow":
      return <ShadowPanel {...props} />;
    case "export":
      return <ExportPanel {...props} />;
    case "batch":
      return <BatchPanel />;
    default:
      return <BackgroundPanel {...props} />;
  }
}

/* ------------------------------------------------------------------ */
/* Background                                                          */
/* ------------------------------------------------------------------ */

function BackgroundPanel({ ws }: PanelProps) {
  const { state, update } = ws;
  const [tab, setTab] = useState<"transparent" | "color" | "gradient" | "image">(
    state.background.kind,
  );
  const [category, setCategory] = useState(backgroundCategories()[0]);
  const uploadRef = useRef<HTMLInputElement>(null);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [mode, setMode] = useState<"general" | "portrait">("general");

  useEffect(() => {
    setTab(state.background.kind);
  }, [state.background.kind]);

  const chooseKind = (kind: "transparent" | "color" | "gradient" | "image") => {
    setTab(kind);
    update((current) => ({ ...current, background: { ...current.background, kind } }));
  };

  return (
    <div className="space-y-5">
      <PanelSection
        title="AI cut-out"
        description="Runs the real U²-Net model right here in your browser."
        actions={
          ws.removal === "done" ? (
            <span className="inline-flex items-center gap-1 rounded-full bg-emerald-50 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wide text-emerald-700">
              <Icon name="check" size={11} /> Ready
            </span>
          ) : null
        }
      >
        <Segmented
          options={[
            { value: "general" as const, label: "General" },
            { value: "portrait" as const, label: "People" },
          ]}
          value={mode}
          onChange={setMode}
        />

        <ActionButton
          variant="primary"
          icon={ws.removal === "working" ? "loader" : "scissors"}
          className="w-full"
          disabled={ws.removal === "working"}
          onClick={() => void ws.runRemoval(mode)}
        >
          {ws.removal === "working"
            ? ws.removalProgress < 100
              ? `Uploading ${ws.removalProgress}%`
              : "Removing background…"
            : state.subject.useCutout
              ? "Run background removal again"
              : "Remove background"}
        </ActionButton>

        {ws.removal === "working" && ws.removalProgress >= 100 && (
          <p className="text-center text-[11px] text-ink-muted">
            The AI is working on the full-resolution image. This usually takes a few seconds.
          </p>
        )}

        {ws.removal === "error" && (
          <div className="space-y-2 rounded-lg border border-red-200 bg-red-50 p-3 text-xs text-red-700" role="alert">
            <p className="font-semibold">{ws.removalError}</p>
            <div className="flex gap-2">
              <ActionButton icon="refresh" onClick={() => void ws.runRemoval(mode)}>
                Retry
              </ActionButton>
              <ActionButton variant="ghost" onClick={() => void ws.runRemoval("general")}>
                Use general model
              </ActionButton>
            </div>
          </div>
        )}

        {state.subject.useCutout ? (
          <div className="flex gap-2">
            <ActionButton icon="image" className="flex-1" onClick={ws.restoreOriginal}>
              Original photo
            </ActionButton>
            <ActionButton icon="scissors" className="flex-1" onClick={() => void ws.runRemoval(mode)}>
              Re-cut
            </ActionButton>
          </div>
        ) : ws.removal === "done" ? (
          <ActionButton icon="scissors" className="w-full" onClick={ws.useCutoutAgain}>
            Use the cut-out again
          </ActionButton>
        ) : (
          <EmptyNote>
            Upload a photo, then remove the background to unlock solid colours, gradients and
            background images.
          </EmptyNote>
        )}
      </PanelSection>

      <PanelSection title="Background">
        <Segmented
          options={[
            { value: "transparent" as const, label: "None" },
            { value: "color" as const, label: "Colour" },
            { value: "gradient" as const, label: "Gradient" },
            { value: "image" as const, label: "Image" },
          ]}
          value={tab}
          onChange={chooseKind}
        />

        {tab === "transparent" && (
          <p className="rounded-lg bg-mist/70 px-3 py-2 text-xs leading-5 text-ink-muted">
            Transparency stays transparent. PNG and WEBP exports keep it; JPEG is flattened onto
            your chosen colour.
          </p>
        )}

        {tab === "color" && (
          <div className="space-y-3">
            <div className="flex flex-wrap gap-1.5">
              {SOLID_COLORS.map((color) => (
                <Swatch
                  key={color}
                  color={color}
                  label={color}
                  active={state.background.color === color}
                  onClick={() =>
                    update((current) => ({
                      ...current,
                      background: { ...current.background, kind: "color", color },
                    }))
                  }
                />
              ))}
            </div>
            <ColorField
              label="Custom colour"
              value={state.background.color}
              onChange={(color) =>
                update((current) => ({
                  ...current,
                  background: { ...current.background, kind: "color", color },
                }), "bg:color")
              }
            />
          </div>
        )}

        {tab === "gradient" && (
          <div className="space-y-3">
            <div className="grid grid-cols-2 gap-2">
              {GRADIENT_PRESETS.map((preset) => (
                <button
                  key={preset.id}
                  type="button"
                  onClick={() =>
                    update((current) => ({
                      ...current,
                      background: {
                        ...current.background,
                        kind: "gradient",
                        gradient: {
                          from: preset.from,
                          to: preset.to,
                          via: preset.via,
                          angle: preset.angle,
                        },
                      },
                    }))
                  }
                  className="overflow-hidden rounded-lg border border-ink/10 text-left transition hover:border-brand-400"
                >
                  <span
                    className="block h-9 w-full"
                    style={{
                      background: `linear-gradient(${preset.angle}deg, ${preset.from}, ${preset.via ?? preset.to}, ${preset.to})`,
                    }}
                  />
                  <span className="block px-2 py-1 text-[10px] font-semibold text-ink-soft">
                    {preset.name}
                  </span>
                </button>
              ))}
            </div>
            <div className="grid grid-cols-2 gap-2">
              <ColorField
                label="Start"
                value={state.background.gradient.from}
                onChange={(from) =>
                  update(
                    (current) => ({
                      ...current,
                      background: {
                        ...current.background,
                        kind: "gradient",
                        gradient: { ...current.background.gradient, from },
                      },
                    }),
                    "bg:grad-from",
                  )
                }
              />
              <ColorField
                label="End"
                value={state.background.gradient.to}
                onChange={(to) =>
                  update(
                    (current) => ({
                      ...current,
                      background: {
                        ...current.background,
                        kind: "gradient",
                        gradient: { ...current.background.gradient, to },
                      },
                    }),
                    "bg:grad-to",
                  )
                }
              />
            </div>
            <ColorField
              label="Middle colour (optional)"
              value={state.background.gradient.via ?? state.background.gradient.to}
              onChange={(via) =>
                update(
                  (current) => ({
                    ...current,
                    background: {
                      ...current.background,
                      kind: "gradient",
                      gradient: { ...current.background.gradient, via },
                    },
                  }),
                  "bg:grad-via",
                )
              }
            />
            <ActionButton
              icon="close"
              onClick={() =>
                update((current) => ({
                  ...current,
                  background: {
                    ...current.background,
                    gradient: { ...current.background.gradient, via: null },
                  },
                }))
              }
            >
              Remove middle colour
            </ActionButton>
            <Slider
              label="Direction"
              min={0}
              max={360}
              value={state.background.gradient.angle}
              suffix="°"
              onChange={(angle) =>
                update(
                  (current) => ({
                    ...current,
                    background: {
                      ...current.background,
                      kind: "gradient",
                      gradient: { ...current.background.gradient, angle },
                    },
                  }),
                  "bg:grad-angle",
                )
              }
            />
          </div>
        )}

        {tab === "image" && (
          <div className="space-y-3">
            <ActionButton icon="upload" className="w-full" onClick={() => uploadRef.current?.click()}>
              Upload background image
            </ActionButton>
            <input
              ref={uploadRef}
              type="file"
              accept="image/jpeg,image/png,image/webp"
              className="sr-only"
              onChange={(event) => {
                const file = event.target.files?.[0];
                if (!file) return;
                void ws.uploadBackgroundImage(file).then((result) => {
                  if (!result.ok) setUploadError(result.message ?? "That image could not be used.");
                  else setUploadError(null);
                });
                event.target.value = "";
              }}
            />
            {uploadError && <p className="text-xs font-medium text-red-600">{uploadError}</p>}
            {state.background.imageUrl && state.background.kind === "image" && (
              <div className="flex items-center gap-2">
                <ActionButton
                  icon="trash"
                  variant="danger"
                  onClick={() =>
                    update((current) => ({
                      ...current,
                      background: { ...current.background, kind: "transparent", imageUrl: null },
                    }))
                  }
                >
                  Remove image
                </ActionButton>
                <Segmented
                  options={[
                    { value: "cover" as const, label: "Fill" },
                    { value: "contain" as const, label: "Fit" },
                  ]}
                  value={state.background.imageFit}
                  onChange={(imageFit) =>
                    update((current) => ({
                      ...current,
                      background: { ...current.background, imageFit },
                    }))
                  }
                />
              </div>
            )}

            <div className="flex flex-wrap gap-1">
              {backgroundCategories().map((item) => (
                <button
                  key={item}
                  type="button"
                  onClick={() => setCategory(item)}
                  className={`rounded-full px-2.5 py-1 text-[10px] font-semibold transition ${
                    category === item ? "bg-brand-600 text-white" : "bg-mist text-ink-soft hover:bg-brand-50"
                  }`}
                >
                  {item}
                </button>
              ))}
            </div>
            <div className="grid max-h-64 grid-cols-3 gap-2 overflow-y-auto pr-1">
              {BACKGROUND_LIBRARY.filter((item) => item.category === category).map((item) => (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => void ws.chooseBackgroundImage(item.url)}
                  className="group overflow-hidden rounded-lg border border-ink/10 transition hover:border-brand-400"
                  title={item.name}
                >
                  <img src={item.url} alt={item.name} className="h-16 w-full object-cover" loading="lazy" />
                  <span className="block truncate px-1.5 py-1 text-[10px] font-semibold text-ink-soft">
                    {item.name}
                  </span>
                </button>
              ))}
            </div>

            {state.background.imageUrl && (
              <>
                <Slider
                  label="Zoom background"
                  min={50}
                  max={300}
                  value={state.background.imageScale}
                  suffix="%"
                  onChange={(imageScale) =>
                    update(
                      (current) => ({
                        ...current,
                        background: { ...current.background, kind: "image", imageScale },
                      }),
                      "bg:scale",
                    )
                  }
                />
                <div className="grid grid-cols-2 gap-2">
                  <Slider
                    label="Horizontal"
                    min={-1000}
                    max={1000}
                    value={state.background.imageX}
                    onChange={(imageX) =>
                      update(
                        (current) => ({
                          ...current,
                          background: { ...current.background, kind: "image", imageX },
                        }),
                        "bg:x",
                      )
                    }
                  />
                  <Slider
                    label="Vertical"
                    min={-1000}
                    max={1000}
                    value={state.background.imageY}
                    onChange={(imageY) =>
                      update(
                        (current) => ({
                          ...current,
                          background: { ...current.background, kind: "image", imageY },
                        }),
                        "bg:y",
                      )
                    }
                  />
                </div>
              </>
            )}
          </div>
        )}
      </PanelSection>

      {state.subject.useCutout && (
        <PanelSection title="Subject position" description="Drag the subject on the canvas too.">
          <Slider
            label="Size"
            min={20}
            max={220}
            value={state.subject.scale}
            suffix="%"
            onChange={(scale) =>
              update(
                (current) => ({ ...current, subject: { ...current.subject, scale } }),
                "subject:scale",
              )
            }
          />
          <div className="grid grid-cols-2 gap-2">
            <Slider
              label="Horizontal"
              min={-1200}
              max={1200}
              value={state.subject.x}
              onChange={(x) =>
                update((current) => ({ ...current, subject: { ...current.subject, x } }), "subject:x")
              }
            />
            <Slider
              label="Vertical"
              min={-1200}
              max={1200}
              value={state.subject.y}
              onChange={(y) =>
                update((current) => ({ ...current, subject: { ...current.subject, y } }), "subject:y")
              }
            />
          </div>
          <div className="space-y-1">
            <div className="grid grid-cols-3 gap-1">
              {([
                ["Left", -1],
                ["Center", 0],
                ["Right", 1],
              ] as const).map(([label, direction]) => (
                <button
                  key={label}
                  type="button"
                  onClick={() =>
                    update((current) => {
                      const step = Math.max(current.doc.width, current.doc.height) * 0.12;
                      return {
                        ...current,
                        subject: { ...current.subject, x: step * direction },
                      };
                    })
                  }
                  className="rounded-md border border-ink/10 px-1 py-1.5 text-[10px] font-semibold text-ink-soft transition hover:bg-brand-50"
                >
                  {label}
                </button>
              ))}
            </div>
            <div className="grid grid-cols-3 gap-1">
              {([
                ["Top", -1],
                ["Middle", 0],
                ["Bottom", 1],
              ] as const).map(([label, direction]) => (
                <button
                  key={label}
                  type="button"
                  onClick={() =>
                    update((current) => {
                      const step = Math.max(current.doc.width, current.doc.height) * 0.12;
                      return {
                        ...current,
                        subject: { ...current.subject, y: step * direction },
                      };
                    })
                  }
                  className="rounded-md border border-ink/10 px-1 py-1.5 text-[10px] font-semibold text-ink-soft transition hover:bg-brand-50"
                >
                  {label}
                </button>
              ))}
            </div>
          </div>
          <ActionButton
            icon="refresh"
            onClick={() =>
              update((current) => ({
                ...current,
                subject: { ...current.subject, x: 0, y: 0, scale: 100 },
              }))
            }
          >
            Reset subject
          </ActionButton>
        </PanelSection>
      )}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Resize                                                              */
/* ------------------------------------------------------------------ */

function ResizePanel({ ws }: PanelProps) {
  const { state, update } = ws;
  const [lock, setLock] = useState(true);
  const [percent, setPercent] = useState(100);
  const ratio = state.doc.width / state.doc.height;

  const setWidth = (width: number) => {
    const next = Math.round(Math.min(12000, Math.max(16, width)));
    update((current) => ({
      ...current,
      doc: {
        width: next,
        height: lock ? Math.max(16, Math.round(next / ratio)) : current.doc.height,
      },
    }), "resize:w");
  };

  const setHeight = (height: number) => {
    const next = Math.round(Math.min(12000, Math.max(16, height)));
    update((current) => ({
      ...current,
      doc: {
        width: lock ? Math.max(16, Math.round(next * ratio)) : current.doc.width,
        height: next,
      },
    }), "resize:h");
  };

  return (
    <div className="space-y-5">
      <PanelSection title="Dimensions" description="The export really is this many pixels.">
        <div className="grid grid-cols-2 gap-2">
          <NumberField label="Width" value={state.doc.width} onChange={setWidth} suffix="px" />
          <NumberField label="Height" value={state.doc.height} onChange={setHeight} suffix="px" />
        </div>
        <Toggle
          label="Lock proportions"
          checked={lock}
          onChange={setLock}
          hint="Keep the current aspect ratio while typing."
        />
        <Slider
          label="Scale"
          min={10}
          max={300}
          value={percent}
          suffix="%"
          onChange={(value) => {
            setPercent(value);
            update((current) => ({
              ...current,
              doc: {
                width: Math.round(state.doc.width * (value / 100)),
                height: Math.round(state.doc.height * (value / 100)),
              },
            }), "resize:percent");
          }}
        />
      </PanelSection>

      <PanelSection title="Presets">
        <div className="grid grid-cols-2 gap-1.5">
          {SIZE_PRESETS.map((preset) => (
            <button
              key={preset.id}
              type="button"
              onClick={() =>
                update((current) => ({
                  ...current,
                  doc: { width: preset.width, height: preset.height },
                }))
              }
              className="rounded-lg border border-ink/10 px-2 py-2 text-left transition hover:border-brand-300 hover:bg-brand-50"
            >
              <span className="block text-[11px] font-semibold text-ink">{preset.label}</span>
              <span className="block text-[10px] text-ink-muted">
                {preset.group} · {preset.width}×{preset.height}
              </span>
            </button>
          ))}
        </div>
      </PanelSection>

      <EmptyNote>
        Resizing stretches the canvas and re-renders the photo at the new size. Use Fit in the
        background panel for images that need to fill a new shape.
      </EmptyNote>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Crop                                                                */
/* ------------------------------------------------------------------ */

function CropPanel({ ws, crop }: PanelProps) {
  const { state } = ws;
  return (
    <div className="space-y-5">
      <PanelSection title="Aspect ratio">
        <div className="grid grid-cols-4 gap-1.5">
          {ASPECT_RATIOS.map((ratio) => (
            <button
              key={ratio.id}
              type="button"
              onClick={() => {
                crop.setAspect(ratio.value);
                if (ratio.value) {
                  const width = Math.min(state.doc.width, state.doc.height * ratio.value);
                  const height = width / ratio.value;
                  crop.setDraft({
                    x: (state.doc.width - width) / 2,
                    y: (state.doc.height - height) / 2,
                    w: width,
                    h: height,
                  });
                }
              }}
              aria-pressed={crop.aspect === ratio.value}
              className={`rounded-md border px-1 py-1.5 text-[11px] font-semibold transition ${
                crop.aspect === ratio.value
                  ? "border-brand-400 bg-brand-50 text-brand-700"
                  : "border-ink/10 text-ink-soft hover:bg-mist"
              }`}
            >
              {ratio.label}
            </button>
          ))}
        </div>
      </PanelSection>

      <PanelSection title="Selection">
        {crop.draft ? (
          <>
            <p className="rounded-lg bg-mist px-3 py-2 text-[11px] tabular-nums text-ink-soft">
              {Math.round(crop.draft.x)}, {Math.round(crop.draft.y)} · {Math.round(crop.draft.w)} ×{" "}
              {Math.round(crop.draft.h)} px
            </p>
            <div className="flex gap-2">
              <ActionButton variant="primary" icon="check" className="flex-1" onClick={crop.apply}>
                Apply crop
              </ActionButton>
              <ActionButton icon="close" onClick={crop.reset}>
                Cancel
              </ActionButton>
            </div>
          </>
        ) : (
          <ActionButton
            icon="grid"
            className="w-full"
            onClick={() =>
              crop.setDraft({
                x: state.doc.width * 0.1,
                y: state.doc.height * 0.1,
                w: state.doc.width * 0.8,
                h: state.doc.height * 0.8,
              })
            }
          >
            Start a crop selection
          </ActionButton>
        )}
        <EmptyNote>
          Drag the box to move it, or pull a corner to resize. The exported file is cropped for real.
        </EmptyNote>
      </PanelSection>

      <ActionButton
        icon="refresh"
        className="w-full"
        onClick={() =>
          crop.setDraft({ x: 0, y: 0, w: state.doc.width, h: state.doc.height })
        }
      >
        Select the whole image
      </ActionButton>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Rotate                                                              */
/* ------------------------------------------------------------------ */

function RotatePanel({ ws }: PanelProps) {
  const { state, update } = ws;

  const rotate = (direction: 1 | -1) => {
    update((current) => {
      const rotateValue = (((current.photo.rotate + direction * 90) % 360) + 360) % 360;
      const crop = current.photo.crop;
      const partial = crop.w < 0.999 || crop.h < 0.999;
      let nextCrop = crop;
      if (partial) {
        nextCrop =
          direction === 1
            ? { x: 1 - (crop.y + crop.h), y: crop.x, w: crop.h, h: crop.w }
            : { x: crop.y, y: 1 - (crop.x + crop.w), w: crop.h, h: crop.w };
      }
      return {
        ...current,
        doc: { width: current.doc.height, height: current.doc.width },
        photo: {
          ...current.photo,
          rotate: rotateValue as 0 | 90 | 180 | 270,
          crop: nextCrop,
        },
      };
    });
  };

  return (
    <div className="space-y-5">
      <PanelSection title="Rotate">
        <div className="grid grid-cols-3 gap-2">
          <ActionButton icon="refresh" onClick={() => rotate(-1)}>
            90° left
          </ActionButton>
          <ActionButton icon="refresh" onClick={() => rotate(1)}>
            90° right
          </ActionButton>
          <ActionButton
            icon="refresh"
            onClick={() => {
              rotate(1);
              rotate(1);
            }}
          >
            180°
          </ActionButton>
        </div>
        <Slider
          label="Straighten"
          min={-45}
          max={45}
          value={state.photo.straighten}
          suffix="°"
          onChange={(straighten) =>
            update(
              (current) => ({ ...current, photo: { ...current.photo, straighten } }),
              "rotate:straighten",
            )
          }
        />
      </PanelSection>

      <PanelSection title="Flip">
        <div className="grid grid-cols-2 gap-2">
          <ActionButton
            icon="refresh"
            onClick={() =>
              update((current) => ({
                ...current,
                photo: { ...current.photo, flipH: !current.photo.flipH },
              }))
            }
          >
            Flip horizontal
          </ActionButton>
          <ActionButton
            icon="refresh"
            onClick={() =>
              update((current) => ({
                ...current,
                photo: { ...current.photo, flipV: !current.photo.flipV },
              }))
            }
          >
            Flip vertical
          </ActionButton>
        </div>
      </PanelSection>

      <ActionButton
        icon="refresh"
        className="w-full"
        onClick={() =>
          update((current) => ({
            ...current,
            photo: { ...current.photo, rotate: 0, flipH: false, flipV: false, straighten: 0 },
          }))
        }
      >
        Reset rotation and flips
      </ActionButton>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Adjustments                                                         */
/* ------------------------------------------------------------------ */

const ADJUSTMENT_GROUPS: { title: string; items: { key: keyof typeof DEFAULT_ADJUSTMENTS; label: string; min: number; max: number; suffix?: string }[] }[] = [
  {
    title: "Light",
    items: [
      { key: "brightness", label: "Brightness", min: -100, max: 100 },
      { key: "exposure", label: "Exposure", min: -100, max: 100 },
      { key: "contrast", label: "Contrast", min: -100, max: 100 },
      { key: "highlights", label: "Highlights", min: -100, max: 100 },
      { key: "shadows", label: "Shadows", min: -100, max: 100 },
    ],
  },
  {
    title: "Colour",
    items: [
      { key: "saturation", label: "Saturation", min: -100, max: 100 },
      { key: "temperature", label: "Temperature", min: -100, max: 100 },
      { key: "tint", label: "Tint", min: -100, max: 100 },
    ],
  },
  {
    title: "Detail",
    items: [
      { key: "sharpness", label: "Sharpness", min: 0, max: 100 },
      { key: "blur", label: "Blur", min: 0, max: 20, suffix: "px" },
      { key: "opacity", label: "Opacity", min: 0, max: 100, suffix: "%" },
    ],
  },
];

const ADJUSTMENT_PRESETS: { label: string; values: Partial<typeof DEFAULT_ADJUSTMENTS> }[] = [
  { label: "Punchy", values: { contrast: 18, saturation: 16, sharpness: 12 } },
  { label: "Soft portrait", values: { brightness: 8, shadows: 14, saturation: 4, sharpness: 8 } },
  { label: "Bright product", values: { exposure: 10, brightness: 8, contrast: 6, sharpness: 10 } },
  { label: "Moody", values: { contrast: 22, exposure: -8, shadows: -14, saturation: -8 } },
];

function AdjustPanel({ ws }: PanelProps) {
  const { state, update } = ws;
  return (
    <div className="space-y-5">
      <PanelSection
        title="Adjustments"
        actions={
          <ActionButton
            icon="refresh"
            variant="ghost"
            onClick={() =>
              update((current) => ({ ...current, adjustments: { ...DEFAULT_ADJUSTMENTS } }))
            }
          >
            Reset all
          </ActionButton>
        }
      >
        {ADJUSTMENT_GROUPS.map((group) => (
          <div key={group.title} className="space-y-2.5">
            <p className="text-[10px] font-bold uppercase tracking-[0.14em] text-ink-muted">
              {group.title}
            </p>
            {group.items.map((item) => (
              <Slider
                key={item.key}
                label={item.label}
                min={item.min}
                max={item.max}
                suffix={item.suffix ?? ""}
                value={state.adjustments[item.key]}
                onChange={(value) =>
                  update(
                    (current) => ({
                      ...current,
                      adjustments: { ...current.adjustments, [item.key]: value },
                    }),
                    `adjust:${item.key}`,
                  )
                }
              />
            ))}
          </div>
        ))}
      </PanelSection>

      <PanelSection title="Presets">
        <div className="grid grid-cols-2 gap-1.5">
          {ADJUSTMENT_PRESETS.map((preset) => (
            <ActionButton
              key={preset.label}
              onClick={() =>
                update((current) => ({
                  ...current,
                  adjustments: { ...current.adjustments, ...preset.values },
                }))
              }
            >
              {preset.label}
            </ActionButton>
          ))}
        </div>
      </PanelSection>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Filters                                                             */
/* ------------------------------------------------------------------ */

function FiltersPanel({ ws }: PanelProps) {
  const { state, update } = ws;
  return (
    <div className="space-y-5">
      <PanelSection title="Filter" description="Previews use your current image.">
        <div className="grid grid-cols-3 gap-2">
          {FILTERS.map((filter) => (
            <FilterThumb
              key={filter.id}
              filterId={filter.id}
              label={filter.name}
              active={state.filter.id === filter.id}
              state={state}
              ws={ws}
              onClick={() =>
                update((current) => ({ ...current, filter: { ...current.filter, id: filter.id } }))
              }
            />
          ))}
        </div>
      </PanelSection>
      <PanelSection title="Intensity">
        <Slider
          label="Filter strength"
          min={0}
          max={100}
          value={state.filter.intensity}
          suffix="%"
          onChange={(intensity) =>
            update(
              (current) => ({ ...current, filter: { ...current.filter, intensity } }),
              "filter:intensity",
            )
          }
        />
        <ActionButton
          icon="refresh"
          className="w-full"
          onClick={() =>
            update((current) => ({ ...current, filter: { id: "original", intensity: 100 } }))
          }
        >
          Reset filter
        </ActionButton>
      </PanelSection>
    </div>
  );
}

function FilterThumb({
  filterId,
  label,
  active,
  state,
  ws,
  onClick,
}: {
  filterId: string;
  label: string;
  active: boolean;
  state: EditorState;
  ws: Workspace;
  onClick: () => void;
}) {
  const ref = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    let cancelled = false;
    const timer = window.setTimeout(() => {
      if (cancelled) return;
      const rendered = renderDocument(
        { ...state, filter: { id: filterId, intensity: 100 }, layers: [] },
        ws.assets,
        { maxSize: 140, previewBackground: "#ffffff" },
      );
      canvas.width = rendered.width;
      canvas.height = rendered.height;
      canvas.getContext("2d")?.drawImage(rendered, 0, 0);
    }, 60);
    return () => {
      cancelled = true;
      window.clearTimeout(timer);
    };
  }, [filterId, state, ws.assets]);

  return (
    <button
      type="button"
      onClick={onClick}
      aria-pressed={active}
      className={`overflow-hidden rounded-lg border text-left transition ${
        active ? "border-brand-500 ring-2 ring-brand-200" : "border-ink/10 hover:border-brand-300"
      }`}
    >
      <span className="checkerboard block h-14 w-full">
        <canvas ref={ref} className="h-full w-full object-cover" />
      </span>
      <span className="block truncate px-1.5 py-1 text-[10px] font-semibold text-ink-soft">
        {label}
      </span>
    </button>
  );
}

/* ------------------------------------------------------------------ */
/* Text                                                                */
/* ------------------------------------------------------------------ */

function patchLayer(state: EditorState, id: string, patch: Record<string, unknown>): EditorState {
  return {
    ...state,
    layers: state.layers.map((layer) =>
      layer.id === id ? ({ ...layer, ...patch } as Layer) : layer,
    ),
  };
}

function TextPanel({ ws, selectedId, setSelectedId }: PanelProps) {
  const { state, update } = ws;
  const selected = state.layers.find((layer) => layer.id === selectedId && layer.kind === "text") as
    | TextLayer
    | undefined;
  const textLayers = state.layers.filter((layer): layer is TextLayer => layer.kind === "text");

  const add = (preset?: Partial<TextLayer>) => {
    const layer = createTextLayer(state, preset);
    update((current) => ({ ...current, layers: [...current.layers, layer] }));
    setSelectedId(layer.id);
  };

  return (
    <div className="space-y-5">
      <PanelSection title="Add text">
        <ActionButton variant="primary" icon="plus" className="w-full" onClick={() => add()}>
          Add a text layer
        </ActionButton>
        <div className="grid grid-cols-2 gap-1.5">
          {TEXT_PRESETS.map((preset) => (
            <ActionButton
              key={preset.label}
              onClick={() =>
                add({
                  text: preset.text,
                  name: preset.label,
                  size: Math.max(16, Math.round(state.doc.width * preset.size)),
                  bold: preset.bold,
                  color: preset.color,
                  font: preset.font,
                })
              }
            >
              {preset.label}
            </ActionButton>
          ))}
        </div>
      </PanelSection>

      {textLayers.length > 0 && (
        <PanelSection title="Text layers">
          <div className="space-y-1">
            {textLayers.map((layer) => (
              <button
                key={layer.id}
                type="button"
                onClick={() => setSelectedId(layer.id)}
                className={`flex w-full items-center gap-2 rounded-lg border px-2 py-1.5 text-left text-xs transition ${
                  selected?.id === layer.id
                    ? "border-brand-300 bg-brand-50 text-brand-800"
                    : "border-ink/[0.07] text-ink-soft hover:bg-mist"
                }`}
              >
                <Icon name="file" size={12} />
                <span className="truncate">{layer.text || "Empty text"}</span>
              </button>
            ))}
          </div>
        </PanelSection>
      )}

      {selected ? (
        <PanelSection
          title="Edit text"
          actions={
            <button
              type="button"
              className="rounded-md p-1 text-ink-muted transition hover:bg-red-50 hover:text-red-600"
              aria-label="Delete this text layer"
              onClick={() =>
                update((current) => ({
                  ...current,
                  layers: current.layers.filter((layer) => layer.id !== selected.id),
                }))
              }
            >
              <Icon name="trash" size={14} />
            </button>
          }
        >
          <label className="block">
            <span className="text-xs font-semibold text-ink-soft">Content</span>
            <textarea
              value={selected.text}
              rows={3}
              onChange={(event) =>
                update(
                  (current) => patchLayer(current, selected.id, { text: event.target.value }),
                  `text:${selected.id}:content`,
                )
              }
              className="mt-1 w-full resize-y rounded-lg border border-ink/10 bg-white px-2.5 py-2 text-sm text-ink outline-none focus:border-brand-400"
            />
          </label>

          <label className="block">
            <span className="text-xs font-semibold text-ink-soft">Font</span>
            <select
              value={selected.font}
              onChange={(event) =>
                update((current) => patchLayer(current, selected.id, { font: event.target.value }))
              }
              className="mt-1 w-full rounded-lg border border-ink/10 bg-white px-2 py-2 text-xs font-medium text-ink outline-none focus:border-brand-400"
            >
              {FONT_OPTIONS.map((font) => (
                <option key={font.value} value={font.value}>
                  {font.label}
                </option>
              ))}
            </select>
          </label>

          <div className="grid grid-cols-2 gap-2">
            <NumberField
              label="Size"
              value={selected.size}
              min={4}
              max={2000}
              suffix="px"
              onChange={(size) =>
                update(
                  (current) => patchLayer(current, selected.id, { size }),
                  `text:${selected.id}:size`,
                )
              }
            />
            <NumberField
              label="Rotation"
              value={selected.rotation}
              min={-180}
              max={180}
              suffix="°"
              onChange={(rotation) =>
                update((current) => patchLayer(current, selected.id, { rotation }), `text:${selected.id}:rot`)
              }
            />
          </div>

          <div className="flex gap-1.5">
            {[
              { key: "bold", label: "B", active: selected.bold, className: "font-extrabold" },
              { key: "italic", label: "I", active: selected.italic, className: "italic font-serif" },
            ].map((style) => (
              <button
                key={style.key}
                type="button"
                aria-pressed={style.active}
                onClick={() =>
                  update((current) =>
                    patchLayer(current, selected.id, { [style.key]: !style.active }),
                  )
                }
                className={`h-8 w-9 rounded-md border text-sm transition ${
                  style.active
                    ? "border-brand-400 bg-brand-50 text-brand-700"
                    : "border-ink/10 text-ink-soft hover:bg-mist"
                } ${style.className}`}
              >
                {style.label}
              </button>
            ))}
            <Segmented
              options={[
                { value: "left" as const, label: "L" },
                { value: "center" as const, label: "C" },
                { value: "right" as const, label: "R" },
              ]}
              value={selected.align}
              onChange={(align) =>
                update((current) => patchLayer(current, selected.id, { align }))
              }
            />
          </div>

          <ColorField
            label="Text colour"
            value={selected.color}
            onChange={(color) =>
              update((current) => patchLayer(current, selected.id, { color }), `text:${selected.id}:color`)
            }
          />

          <div className="grid grid-cols-2 gap-2">
            <Slider
              label="Line spacing"
              min={0.6}
              max={2.5}
              step={0.05}
              value={selected.lineHeight}
              onChange={(lineHeight) =>
                update(
                  (current) => patchLayer(current, selected.id, { lineHeight }),
                  `text:${selected.id}:line`,
                )
              }
            />
            <Slider
              label="Letter spacing"
              min={-5}
              max={30}
              value={selected.letterSpacing}
              suffix="px"
              onChange={(letterSpacing) =>
                update(
                  (current) => patchLayer(current, selected.id, { letterSpacing }),
                  `text:${selected.id}:spacing`,
                )
              }
            />
          </div>

          <Slider
            label="Opacity"
            min={0}
            max={100}
            suffix="%"
            value={selected.opacity}
            onChange={(opacity) =>
              update((current) => patchLayer(current, selected.id, { opacity }), `text:${selected.id}:opacity`)
            }
          />

          <Toggle
            label="Shadow"
            checked={selected.shadow}
            onChange={(shadow) =>
              update((current) => patchLayer(current, selected.id, { shadow }))
            }
          />
          {selected.shadow && (
            <ColorField
              label="Shadow colour"
              value={selected.shadowColor}
              onChange={(shadowColor) =>
                update((current) => patchLayer(current, selected.id, { shadowColor }))
              }
            />
          )}
          <Toggle
            label="Outline"
            checked={selected.outline}
            onChange={(outline) =>
              update((current) => patchLayer(current, selected.id, { outline }))
            }
          />
          {selected.outline && (
            <ColorField
              label="Outline colour"
              value={selected.outlineColor}
              onChange={(outlineColor) =>
                update((current) => patchLayer(current, selected.id, { outlineColor }))
              }
            />
          )}
        </PanelSection>
      ) : (
        <EmptyNote>Select a text layer to edit its font, colour, spacing and effects.</EmptyNote>
      )}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Stickers and shapes                                                 */
/* ------------------------------------------------------------------ */

function StickersPanel({ ws, selectedId, setSelectedId }: PanelProps) {
  const { state, update } = ws;
  const [category, setCategory] = useState(stickerCategories()[0]);
  const selected = state.layers.find((layer) => layer.id === selectedId);

  const addShape = (shape: ShapeKind) => {
    const layer = createShapeLayer(state, shape);
    update((current) => ({ ...current, layers: [...current.layers, layer] }));
    setSelectedId(layer.id);
  };

  const addSticker = (id: string, name: string) => {
    const layer = createStickerLayer(state, id, name);
    update((current) => ({ ...current, layers: [...current.layers, layer] }));
    setSelectedId(layer.id);
  };

  return (
    <div className="space-y-5">
      <PanelSection title="Shapes">
        <div className="grid grid-cols-3 gap-1.5">
          {SHAPE_OPTIONS.map((option) => (
            <ActionButton key={option.shape} icon="plus" onClick={() => addShape(option.shape)}>
              {option.label}
            </ActionButton>
          ))}
        </div>
      </PanelSection>

      <PanelSection title="Stickers">
        <div className="flex flex-wrap gap-1">
          {stickerCategories().map((item) => (
            <button
              key={item}
              type="button"
              onClick={() => setCategory(item)}
              className={`rounded-full px-2.5 py-1 text-[10px] font-semibold transition ${
                category === item ? "bg-brand-600 text-white" : "bg-mist text-ink-soft hover:bg-brand-50"
              }`}
            >
              {item}
            </button>
          ))}
        </div>
        <div className="grid grid-cols-4 gap-2">
          {STICKERS.filter((sticker) => sticker.category === category).map((sticker) => (
            <button
              key={sticker.id}
              type="button"
              title={sticker.name}
              onClick={() => addSticker(sticker.id, sticker.name)}
              className="grid aspect-square place-items-center rounded-lg border border-ink/10 bg-white p-1.5 transition hover:border-brand-400 hover:bg-brand-50"
            >
              <img src={sticker.url} alt={sticker.name} className="h-full w-full object-contain" loading="lazy" />
            </button>
          ))}
        </div>
      </PanelSection>

      {selected && (selected.kind === "shape" || selected.kind === "sticker") ? (
        <PanelSection title={`Edit ${selected.kind}`}>
          <div className="grid grid-cols-2 gap-2">
            <NumberField
              label="X"
              value={selected.x}
              onChange={(x) => update((current) => patchLayer(current, selected.id, { x }), "layer:x")}
            />
            <NumberField
              label="Y"
              value={selected.y}
              onChange={(y) => update((current) => patchLayer(current, selected.id, { y }), "layer:y")}
            />
          </div>
          <Slider
            label="Rotation"
            min={-180}
            max={180}
            suffix="°"
            value={selected.rotation}
            onChange={(rotation) =>
              update((current) => patchLayer(current, selected.id, { rotation }), "layer:rot")
            }
          />
          <Slider
            label="Opacity"
            min={0}
            max={100}
            suffix="%"
            value={selected.opacity}
            onChange={(opacity) =>
              update((current) => patchLayer(current, selected.id, { opacity }), "layer:opacity")
            }
          />
          {selected.kind === "shape" ? (
            <ShapeEditor ws={ws} layer={selected} />
          ) : (
            <Slider
              label="Size"
              min={20}
              max={2000}
              value={selected.size}
              suffix="px"
              onChange={(size) =>
                update((current) => patchLayer(current, selected.id, { size }), "layer:size")
              }
            />
          )}
          <ActionButton
            variant="danger"
            icon="trash"
            className="w-full"
            onClick={() =>
              update((current) => ({
                ...current,
                layers: current.layers.filter((layer) => layer.id !== selected.id),
              }))
            }
          >
            Delete
          </ActionButton>
        </PanelSection>
      ) : (
        <EmptyNote>Select a shape or sticker on the canvas to fine-tune it.</EmptyNote>
      )}
    </div>
  );
}

function ShapeEditor({ ws, layer }: { ws: Workspace; layer: ShapeLayer }) {
  const { update } = ws;
  const set = (patch: Record<string, unknown>) =>
    update((current) => patchLayer(current, layer.id, patch), `shape:${layer.id}`);
  return (
    <div className="space-y-3">
      <div className="grid grid-cols-2 gap-2">
        <NumberField
          label="Width"
          value={layer.w}
          onChange={(w) => set({ w: Math.max(2, w) })}
          suffix="px"
        />
        <NumberField
          label="Height"
          value={layer.h}
          onChange={(h) => set({ h: Math.max(2, h) })}
          suffix="px"
        />
      </div>
      <ColorField label="Fill" value={layer.fill} onChange={(fill) => set({ fill })} />
      <ColorField label="Border" value={layer.border} onChange={(border) => set({ border })} />
      <Slider
        label="Border width"
        min={0}
        max={40}
        value={layer.borderWidth}
        suffix="px"
        onChange={(borderWidth) => set({ borderWidth })}
      />
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Layers                                                              */
/* ------------------------------------------------------------------ */

function LayersPanel({ ws, selectedId, setSelectedId }: PanelProps) {
  const { state, update } = ws;
  const layers = state.layers;
  return (
    <div className="space-y-4">
      <PanelSection title="Layers" description="Top of the list renders on top.">
        <div className="space-y-1.5">
          <div className="flex items-center gap-2 rounded-lg border border-ink/[0.07] bg-mist/60 px-2 py-1.5">
            <Icon name="image" size={13} className="text-ink-muted" />
            <span className="flex-1 text-xs font-semibold text-ink">
              {state.subject.useCutout ? "Cut-out subject" : "Photo"}
            </span>
            <span className="text-[10px] text-ink-muted">base</span>
          </div>
          <div className="flex items-center gap-2 rounded-lg border border-ink/[0.07] px-2 py-1.5">
            <Icon name="palette" size={13} className="text-ink-muted" />
            <span className="flex-1 text-xs font-semibold text-ink">Background</span>
            <span className="text-[10px] capitalize text-ink-muted">{state.background.kind}</span>
          </div>
        </div>
      </PanelSection>

      <PanelSection title="Text, shapes & stickers">
        {layers.length === 0 ? (
          <EmptyNote>No overlays yet. Add text or a sticker from the left toolbar.</EmptyNote>
        ) : (
          <ul className="space-y-1.5">
            {[...layers].reverse().map((layer) => (
              <li
                key={layer.id}
                className={`rounded-lg border transition ${
                  selectedId === layer.id ? "border-brand-400 bg-brand-50/60" : "border-ink/[0.07]"
                }`}
              >
                <div className="flex items-center gap-1.5 px-2 py-1.5">
                  <button
                    type="button"
                    onClick={() =>
                      update((current) => patchLayer(current, layer.id, { visible: !layer.visible }))
                    }
                    aria-label={layer.visible ? "Hide layer" : "Show layer"}
                    className={`rounded p-1 transition ${
                      layer.visible ? "text-brand-600 hover:bg-white" : "text-ink-muted hover:bg-white"
                    }`}
                  >
                    <Icon name="eye" size={13} />
                  </button>
                  <button
                    type="button"
                    onClick={() => setSelectedId(layer.id)}
                    className="min-w-0 flex-1 truncate text-left text-xs font-semibold text-ink"
                  >
                    {layer.name}
                  </button>
                  <button
                    type="button"
                    onClick={() =>
                      update((current) => patchLayer(current, layer.id, { locked: !layer.locked }))
                    }
                    aria-label={layer.locked ? "Unlock layer" : "Lock layer"}
                    className={`rounded p-1 transition hover:bg-white ${
                      layer.locked ? "text-amber-600" : "text-ink-muted"
                    }`}
                  >
                    <Icon name="lock" size={13} />
                  </button>
                  <button
                    type="button"
                    aria-label="Move layer up"
                    onClick={() =>
                      update((current) => {
                        const index = current.layers.findIndex((item) => item.id === layer.id);
                        if (index < 0 || index === current.layers.length - 1) return current;
                        const next = [...current.layers];
                        [next[index], next[index + 1]] = [next[index + 1], next[index]];
                        return { ...current, layers: next };
                      })
                    }
                    className="rounded p-1 text-ink-muted transition hover:bg-white hover:text-ink"
                  >
                    <Icon name="chevron-down" size={13} className="rotate-180" />
                  </button>
                  <button
                    type="button"
                    aria-label="Move layer down"
                    onClick={() =>
                      update((current) => {
                        const index = current.layers.findIndex((item) => item.id === layer.id);
                        if (index <= 0) return current;
                        const next = [...current.layers];
                        [next[index], next[index - 1]] = [next[index - 1], next[index]];
                        return { ...current, layers: next };
                      })
                    }
                    className="rounded p-1 text-ink-muted transition hover:bg-white hover:text-ink"
                  >
                    <Icon name="chevron-down" size={13} />
                  </button>
                  <button
                    type="button"
                    aria-label="Delete layer"
                    onClick={() =>
                      update((current) => ({
                        ...current,
                        layers: current.layers.filter((item) => item.id !== layer.id),
                      }))
                    }
                    className="rounded p-1 text-ink-muted transition hover:bg-red-50 hover:text-red-600"
                  >
                    <Icon name="trash" size={13} />
                  </button>
                </div>
                {selectedId === layer.id && (
                  <div className="border-t border-ink/[0.06] px-2 py-2">
                    <input
                      type="text"
                      value={layer.name}
                      aria-label="Layer name"
                      onChange={(event) =>
                        update(
                          (current) => patchLayer(current, layer.id, { name: event.target.value }),
                          `layer:${layer.id}:name`,
                        )
                      }
                      className="w-full rounded-md border border-ink/10 px-2 py-1 text-xs text-ink outline-none focus:border-brand-400"
                    />
                  </div>
                )}
              </li>
            ))}
          </ul>
        )}
      </PanelSection>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Subject effects                                                     */
/* ------------------------------------------------------------------ */

function ShadowPanel({ ws }: PanelProps) {
  const { state, update } = ws;
  return (
    <div className="space-y-5">
      <PanelSection title="Drop shadow" description="Applies to the cut-out subject only.">
        <Toggle
          label="Show drop shadow"
          checked={state.shadow.enabled}
          onChange={(enabled) =>
            update((current) => ({ ...current, shadow: { ...current.shadow, enabled } }))
          }
        />
        {state.shadow.enabled && (
          <>
            <Slider
              label="Blur"
              min={0}
              max={120}
              value={state.shadow.blur}
              suffix="px"
              onChange={(blur) =>
                update((current) => ({ ...current, shadow: { ...current.shadow, blur } }), "shadow:blur")
              }
            />
            <Slider
              label="Opacity"
              min={0}
              max={100}
              value={state.shadow.opacity}
              suffix="%"
              onChange={(opacity) =>
                update(
                  (current) => ({ ...current, shadow: { ...current.shadow, opacity } }),
                  "shadow:opacity",
                )
              }
            />
            <Slider
              label="Distance"
              min={0}
              max={200}
              value={state.shadow.distance}
              suffix="px"
              onChange={(distance) =>
                update(
                  (current) => ({ ...current, shadow: { ...current.shadow, distance } }),
                  "shadow:distance",
                )
              }
            />
            <Slider
              label="Angle"
              min={0}
              max={360}
              value={state.shadow.angle}
              suffix="°"
              onChange={(angle) =>
                update((current) => ({ ...current, shadow: { ...current.shadow, angle } }), "shadow:angle")
              }
            />
            <ColorField
              label="Shadow colour"
              value={state.shadow.color}
              onChange={(color) =>
                update((current) => ({ ...current, shadow: { ...current.shadow, color } }))
              }
            />
          </>
        )}
      </PanelSection>

      <PanelSection title="Outline">
        <Toggle
          label="Outline the subject"
          checked={state.outline.enabled}
          onChange={(enabled) =>
            update((current) => ({ ...current, outline: { ...current.outline, enabled } }))
          }
        />
        {state.outline.enabled && (
          <>
            <Slider
              label="Thickness"
              min={1}
              max={60}
              value={state.outline.width}
              suffix="px"
              onChange={(width) =>
                update((current) => ({ ...current, outline: { ...current.outline, width } }), "outline:width")
              }
            />
            <ColorField
              label="Outline colour"
              value={state.outline.color}
              onChange={(color) =>
                update((current) => ({ ...current, outline: { ...current.outline, color } }))
              }
            />
          </>
        )}
      </PanelSection>

      <PanelSection title="Presets">
        <div className="grid grid-cols-2 gap-1.5">
          <ActionButton
            onClick={() =>
              update((current) => ({
                ...current,
                shadow: { enabled: true, color: "#0f172a", blur: 34, opacity: 26, distance: 26, angle: 90 },
              }))
            }
          >
            Product shadow
          </ActionButton>
          <ActionButton
            onClick={() =>
              update((current) => ({
                ...current,
                outline: { enabled: true, color: "#ffffff", width: 10 },
              }))
            }
          >
            White outline
          </ActionButton>
          <ActionButton
            onClick={() =>
              update((current) => ({
                ...current,
                shadow: { ...current.shadow, enabled: false },
                outline: { ...current.outline, enabled: false },
              }))
            }
          >
            Clear effects
          </ActionButton>
        </div>
      </PanelSection>

      {!state.subject.useCutout && (
        <EmptyNote>
          These effects need a transparent cut-out. Remove the background first, then the shadow
          follows the subject outline.
        </EmptyNote>
      )}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Export                                                              */
/* ------------------------------------------------------------------ */

function ExportPanel({ ws }: PanelProps) {
  const { state } = ws;
  const [format, setFormat] = useState<"png" | "jpeg" | "webp">("png");
  const [quality, setQuality] = useState(92);
  const [custom, setCustom] = useState(false);
  const [width, setWidth] = useState(state.doc.width);
  const [height, setHeight] = useState(state.doc.height);
  const [filename, setFilename] = useState("clearpix-edited-image");
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState<string | null>(null);
  const [flattenColor, setFlattenColor] = useState("#ffffff");
  const openProjectRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (!custom) {
      setWidth(state.doc.width);
      setHeight(state.doc.height);
    }
  }, [state.doc.width, state.doc.height, custom]);

  const runExport = async () => {
    setBusy(true);
    setMessage(null);
    try {
      await ws.exportImage({
        format,
        quality,
        width: custom ? width : state.doc.width,
        height: custom ? height : state.doc.height,
        filename,
        flattenColor,
      });
      setMessage("Download started.");
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "The export failed. Please try again.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="space-y-5">
      <PanelSection title="Format">
        <Segmented
          options={[
            { value: "png" as const, label: "PNG" },
            { value: "jpeg" as const, label: "JPEG" },
            { value: "webp" as const, label: "WEBP" },
          ]}
          value={format}
          onChange={setFormat}
        />
        <p className="text-[11px] leading-5 text-ink-muted">
          {format === "png"
            ? "PNG keeps transparency, so a cut-out stays transparent."
            : format === "jpeg"
              ? "JPEG has no transparency. Transparent areas are flattened onto the colour below."
              : "WEBP supports transparency and smaller files. Quality is adjustable."}
        </p>
        {format !== "png" && (
          <Slider
            label="Quality"
            min={10}
            max={100}
            value={quality}
            suffix="%"
            onChange={setQuality}
          />
        )}
        {format === "jpeg" && state.background.kind === "transparent" && (
          <ColorField label="Flatten colour" value={flattenColor} onChange={setFlattenColor} />
        )}
      </PanelSection>

      <PanelSection title="Size">
        <Toggle label="Custom dimensions" checked={custom} onChange={setCustom} />
        {custom ? (
          <div className="grid grid-cols-2 gap-2">
            <NumberField label="Width" value={width} onChange={setWidth} suffix="px" />
            <NumberField label="Height" value={height} onChange={setHeight} suffix="px" />
          </div>
        ) : (
          <p className="rounded-lg bg-mist px-3 py-2 text-[11px] tabular-nums text-ink-soft">
            Exporting at {state.doc.width} × {state.doc.height} px
          </p>
        )}
        <label className="block">
          <span className="text-xs font-semibold text-ink-soft">Filename</span>
          <div className="mt-1 flex items-center rounded-lg border border-ink/10 bg-white px-2.5">
            <input
              type="text"
              value={filename}
              onChange={(event) => setFilename(event.target.value)}
              className="w-full bg-transparent py-2 text-sm text-ink outline-none"
            />
            <span className="text-[11px] font-medium text-ink-muted">
              .{format === "jpeg" ? "jpg" : format}
            </span>
          </div>
        </label>
        <ActionButton
          variant="primary"
          icon={busy ? "loader" : "download"}
          className="w-full py-2.5"
          disabled={busy}
          onClick={() => void runExport()}
        >
          {busy ? "Rendering…" : "Download image"}
        </ActionButton>
        {message && (
          <p className={`text-[11px] font-medium ${message === "Download started." ? "text-emerald-600" : "text-red-600"}`}>
            {message}
          </p>
        )}
      </PanelSection>

      <PanelSection title="Project file" description="Keeps every layer, adjustment and background.">
        <div className="grid grid-cols-2 gap-2">
          <ActionButton icon="file" onClick={() => void ws.saveProject()}>
            Save project
          </ActionButton>
          <ActionButton icon="upload" onClick={() => openProjectRef.current?.click()}>
            Open project
          </ActionButton>
        </div>
        <input
          ref={openProjectRef}
          type="file"
          accept=".json,.clearpix.json,application/json"
          className="sr-only"
          aria-label="Open a saved ClearPix project"
          tabIndex={-1}
          onChange={(event) => {
            const file = event.target.files?.[0];
            if (!file) return;
            void ws.openProject(file).then((result) => {
              setMessage(result.ok ? "Project loaded." : (result.message ?? "Could not open that project."));
            });
            event.target.value = "";
          }}
        />
        <p className="text-[11px] leading-5 text-ink-muted">
          Saved locally as a <code className="rounded bg-mist px-1">.clearpix.json</code> file. Nothing
          is uploaded to the server.
        </p>
      </PanelSection>
    </div>
  );
}

function BatchPanel() {
  return (
    <div className="space-y-3">
      <p className="rounded-lg bg-mist px-3 py-2 text-xs leading-5 text-ink-soft">
        Batch mode runs the same real AI model, two images at a time. Each result can be downloaded
        on its own, or all together as a ZIP.
      </p>
      <div className="-mx-2">
        <BackgroundRemover />
      </div>
    </div>
  );
}
