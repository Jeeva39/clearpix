import { Link } from "react-router-dom";
import { Icon, Logo } from "../../components/Icon";

type Props = {
  canUndo: boolean;
  canRedo: boolean;
  onUndo: () => void;
  onRedo: () => void;
  onReset: () => void;
  onSaveProject: () => void;
  onDownload: () => void;
  onExport: () => void;
  onReplace: () => void;
  zoom: number;
  setZoom: (value: number) => void;
  onFullscreen: () => void;
  isFullscreen: boolean;
  onShortcuts: () => void;
  exportBusy?: boolean;
};

function ToolButton({
  label,
  icon,
  onClick,
  disabled,
  hideLabel,
  active,
}: {
  label: string;
  icon: React.ComponentProps<typeof Icon>["name"];
  onClick: () => void;
  disabled?: boolean;
  hideLabel?: boolean;
  active?: boolean;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled}
      title={label}
      aria-label={label}
      aria-pressed={active}
      className={`inline-flex h-9 items-center gap-1.5 rounded-lg px-2 text-xs font-semibold transition disabled:cursor-not-allowed disabled:opacity-35 ${
        active ? "bg-brand-50 text-brand-700" : "text-ink-soft hover:bg-mist hover:text-ink"
      }`}
    >
      <Icon name={icon} size={16} />
      {!hideLabel && <span className="hidden md:inline">{label}</span>}
    </button>
  );
}

export function EditorToolbar({
  canUndo,
  canRedo,
  onUndo,
  onRedo,
  onReset,
  onSaveProject,
  onDownload,
  onExport,
  onReplace,
  zoom,
  setZoom,
  onFullscreen,
  isFullscreen,
  onShortcuts,
  exportBusy,
}: Props) {
  return (
    <header className="z-30 flex h-14 shrink-0 items-center gap-1 border-b border-ink/[0.08] bg-white px-2 sm:px-3">
      <Link to="/" className="mr-1 flex shrink-0 items-center gap-2 rounded-lg px-1 py-1" aria-label="Back to ClearPix home">
        <Logo />
      </Link>

      <span className="mx-1 hidden h-6 w-px bg-ink/10 sm:block" />

      <div className="flex items-center gap-0.5">
        <ToolButton label="Undo" icon="undo" onClick={onUndo} disabled={!canUndo} hideLabel />
        <ToolButton label="Redo" icon="redo" onClick={onRedo} disabled={!canRedo} hideLabel />
      </div>

      <span className="mx-1 hidden h-6 w-px bg-ink/10 sm:block" />

      <div className="hidden items-center gap-0.5 sm:flex">
        <ToolButton label="Reset" icon="refresh" onClick={onReset} />
        <ToolButton label="Replace" icon="upload" onClick={onReplace} />
        <ToolButton label="Save" icon="file" onClick={onSaveProject} />
      </div>

      <div className="ml-auto flex items-center gap-1">
        <div className="hidden items-center gap-1 rounded-lg bg-mist px-1 py-0.5 lg:flex">
          <button
            type="button"
            onClick={() => setZoom(Math.max(25, zoom - 25))}
            className="rounded-md px-1.5 py-1 text-ink-soft transition hover:bg-white"
            aria-label="Zoom out"
          >
            <Icon name="zoom-out" size={14} />
          </button>
          <button
            type="button"
            onClick={() => setZoom(100)}
            className="min-w-[3rem] text-[11px] font-semibold tabular-nums text-ink"
            title="Fit to screen"
          >
            {zoom}%
          </button>
          <button
            type="button"
            onClick={() => setZoom(Math.min(400, zoom + 25))}
            className="rounded-md px-1.5 py-1 text-ink-soft transition hover:bg-white"
            aria-label="Zoom in"
          >
            <Icon name="zoom-in" size={14} />
          </button>
        </div>

        <ToolButton label="Shortcuts" icon="info" onClick={onShortcuts} hideLabel />
        <ToolButton
          label={isFullscreen ? "Exit fullscreen" : "Fullscreen"}
          icon="maximize"
          onClick={onFullscreen}
          hideLabel
          active={isFullscreen}
        />
        <ToolButton label="Download PNG" icon="download" onClick={onDownload} hideLabel />
        <button
          type="button"
          onClick={onExport}
          disabled={exportBusy}
          aria-label="Export"
          className="inline-flex h-9 items-center gap-1.5 rounded-lg bg-brand-600 px-3 text-xs font-semibold text-white transition hover:bg-brand-700 disabled:opacity-60"
        >
          <Icon name={exportBusy ? "loader" : "download"} size={15} className={exportBusy ? "animate-spin" : ""} />
          <span className="hidden sm:inline">Export</span>
        </button>
        <Link
          to="/"
          className="ml-1 hidden h-9 items-center gap-1.5 rounded-lg border border-ink/10 px-2.5 text-xs font-semibold text-ink-soft transition hover:bg-mist xl:inline-flex"
        >
          <Icon name="chevron-right" size={14} className="rotate-180" />
          Home
        </Link>
      </div>
    </header>
  );
}
