import { useCallback, useEffect, useLayoutEffect, useRef, useState } from "react";
import type { CropRect, EditorState, Layer } from "../model";
import { layerAtPoint, measureLayer, renderDocument, type EditorAssets } from "../render";
import type { ToolId } from "../model";

type Props = {
  state: EditorState;
  assets: EditorAssets;
  assetsVersion: number;
  tool: ToolId;
  zoom: number;
  selectedId: string | null;
  onSelect: (id: string | null) => void;
  cropDraft: CropRect | null;
  onCropDraft: (rect: CropRect) => void;
  cropAspect: number | null;
  onMoveLayer: (id: string, x: number, y: number) => void;
  onMoveSubject: (x: number, y: number) => void;
  fullscreen: boolean;
};

type DragState =
  | { mode: "layer"; id: string; startX: number; startY: number; originX: number; originY: number }
  | { mode: "subject"; startX: number; startY: number; originX: number; originY: number }
  | { mode: "crop-move"; startX: number; startY: number; origin: CropRect }
  | { mode: "crop-resize"; handle: "nw" | "ne" | "sw" | "se"; startX: number; startY: number; origin: CropRect };

const MIN_CROP = 24;

export function CanvasStage({
  state,
  assets,
  assetsVersion,
  tool,
  zoom,
  selectedId,
  onSelect,
  cropDraft,
  onCropDraft,
  cropAspect,
  onMoveLayer,
  onMoveSubject,
  fullscreen,
}: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const wrapperRef = useRef<HTMLDivElement>(null);
  const dragRef = useRef<DragState | null>(null);
  const [box, setBox] = useState({ width: 800, height: 520 });

  useLayoutEffect(() => {
    const element = containerRef.current;
    if (!element) return;
    const observer = new ResizeObserver((entries) => {
      const entry = entries[0];
      if (!entry) return;
      setBox({
        width: Math.max(160, entry.contentRect.width),
        height: Math.max(220, entry.contentRect.height),
      });
    });
    observer.observe(element);
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rendered = renderDocument(state, assets, { maxSize: 1700 });
    canvas.width = rendered.width;
    canvas.height = rendered.height;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.drawImage(rendered, 0, 0);
  }, [state, assets, assetsVersion]);

  const docWidth = Math.max(1, state.doc.width);
  const docHeight = Math.max(1, state.doc.height);
  const fit = Math.min(box.width / docWidth, box.height / docHeight);
  const displayWidth = Math.max(80, docWidth * fit * (zoom / 100));
  const displayHeight = Math.max(80, docHeight * fit * (zoom / 100));

  const toDoc = useCallback(
    (clientX: number, clientY: number) => {
      const rect = wrapperRef.current?.getBoundingClientRect();
      if (!rect) return { x: 0, y: 0 };
      return {
        x: ((clientX - rect.left) / rect.width) * docWidth,
        y: ((clientY - rect.top) / rect.height) * docHeight,
      };
    },
    [docHeight, docWidth],
  );

  const handlePointerDown = (event: React.PointerEvent<HTMLCanvasElement>) => {
    const point = toDoc(event.clientX, event.clientY);
    (event.target as HTMLElement).setPointerCapture?.(event.pointerId);

    if (tool === "background" && state.subject.useCutout) {
      dragRef.current = {
        mode: "subject",
        startX: point.x,
        startY: point.y,
        originX: state.subject.x,
        originY: state.subject.y,
      };
      return;
    }

    const hit = layerAtPoint(state.layers, point.x, point.y);
    if (hit) {
      onSelect(hit.id);
      if (!hit.locked) {
        dragRef.current = {
          mode: "layer",
          id: hit.id,
          startX: point.x,
          startY: point.y,
          originX: hit.x,
          originY: hit.y,
        };
      }
      return;
    }
    onSelect(null);
  };

  const handlePointerMove = (event: React.PointerEvent<HTMLCanvasElement>) => {
    const drag = dragRef.current;
    if (!drag) return;
    const point = toDoc(event.clientX, event.clientY);
    if (drag.mode === "layer") {
      onMoveLayer(drag.id, drag.originX + (point.x - drag.startX), drag.originY + (point.y - drag.startY));
    } else if (drag.mode === "subject") {
      onMoveSubject(drag.originX + (point.x - drag.startX), drag.originY + (point.y - drag.startY));
    }
  };

  const endDrag = () => {
    dragRef.current = null;
  };

  /* Crop overlay interactions */
  const beginCrop = (
    event: React.PointerEvent<HTMLElement>,
    mode: "move" | "nw" | "ne" | "sw" | "se",
  ) => {
    if (!cropDraft) return;
    event.preventDefault();
    event.stopPropagation();
    (event.currentTarget as HTMLElement).setPointerCapture?.(event.pointerId);
    const point = toDoc(event.clientX, event.clientY);
    dragRef.current =
      mode === "move"
        ? { mode: "crop-move", startX: point.x, startY: point.y, origin: cropDraft }
        : { mode: "crop-resize", handle: mode, startX: point.x, startY: point.y, origin: cropDraft };
  };

  const moveCrop = (event: React.PointerEvent<HTMLElement>) => {
    const drag = dragRef.current;
    if (!drag || !cropDraft) return;
    if (drag.mode !== "crop-move" && drag.mode !== "crop-resize") return;
    const point = toDoc(event.clientX, event.clientY);

    if (drag.mode === "crop-move") {
      const dx = point.x - drag.startX;
      const dy = point.y - drag.startY;
      onCropDraft({
        x: clamp(drag.origin.x + dx, 0, docWidth - drag.origin.w),
        y: clamp(drag.origin.y + dy, 0, docHeight - drag.origin.h),
        w: drag.origin.w,
        h: drag.origin.h,
      });
      return;
    }

    const { origin, handle } = drag;
    let width = origin.w;
    let height = origin.h;
    if (handle === "ne" || handle === "se") width = clamp(point.x - origin.x, MIN_CROP, docWidth - origin.x);
    if (handle === "nw" || handle === "sw") {
      const right = origin.x + origin.w;
      width = clamp(right - point.x, MIN_CROP, right);
    }
    if (cropAspect) {
      height = width / cropAspect;
      if (height > docHeight) {
        height = docHeight;
        width = height * cropAspect;
      }
    } else if (handle === "ne" || handle === "se") {
      height = clamp(point.y - origin.y, MIN_CROP, docHeight - origin.y);
    } else {
      const bottom = origin.y + origin.h;
      height = clamp(bottom - point.y, MIN_CROP, bottom);
    }

    let x = origin.x;
    let y = origin.y;
    if (handle === "nw" || handle === "sw") x = origin.x + origin.w - width;
    if (handle === "nw" || handle === "ne") y = origin.y + origin.h - height;
    x = clamp(x, 0, docWidth - width);
    y = clamp(y, 0, docHeight - height);
    onCropDraft({ x, y, w: width, h: height });
  };

  const selectedLayer = state.layers.find((layer) => layer.id === selectedId) ?? null;
  const crop = cropDraft;
  const cursor =
    tool === "background" && state.subject.useCutout
      ? "grab"
      : tool === "text" || tool === "stickers" || tool === "layers"
        ? "default"
        : "default";

  return (
    <div
      ref={containerRef}
      className={`relative flex min-h-[280px] w-full flex-1 items-center justify-center overflow-auto p-3 sm:p-5 ${
        fullscreen ? "bg-ink/95" : ""
      }`}
    >
      <div
        ref={wrapperRef}
        className="checkerboard relative shrink-0 overflow-hidden rounded-lg shadow-card ring-1 ring-ink/10"
        style={{ width: displayWidth, height: displayHeight }}
      >
        <canvas
          ref={canvasRef}
          className="absolute inset-0 h-full w-full touch-none select-none"
          style={{ cursor: dragRef.current ? "grabbing" : cursor }}
          onPointerDown={handlePointerDown}
          onPointerMove={handlePointerMove}
          onPointerUp={endDrag}
          onPointerCancel={endDrag}
          aria-label="Image editing canvas"
          role="img"
        />

        {selectedLayer && tool !== "crop" && (
          <SelectionOutline
            layer={selectedLayer}
            docWidth={docWidth}
            docHeight={docHeight}
          />
        )}

        {tool === "crop" && crop && (
          <div
            className="absolute inset-0 touch-none"
            onPointerMove={moveCrop}
            onPointerUp={endDrag}
            onPointerCancel={endDrag}
          >
            <div
              className="absolute bg-ink/55"
              style={{ left: 0, top: 0, width: "100%", height: `${(crop.y / docHeight) * 100}%` }}
            />
            <div
              className="absolute bg-ink/55"
              style={{
                left: 0,
                top: `${((crop.y + crop.h) / docHeight) * 100}%`,
                width: "100%",
                bottom: 0,
              }}
            />
            <div
              className="absolute bg-ink/55"
              style={{
                left: 0,
                top: `${(crop.y / docHeight) * 100}%`,
                width: `${(crop.x / docWidth) * 100}%`,
                height: `${(crop.h / docHeight) * 100}%`,
              }}
            />
            <div
              className="absolute bg-ink/55"
              style={{
                left: `${((crop.x + crop.w) / docWidth) * 100}%`,
                right: 0,
                top: `${(crop.y / docHeight) * 100}%`,
                height: `${(crop.h / docHeight) * 100}%`,
              }}
            />
            <div
              className="absolute cursor-move border-2 border-white shadow-[0_0_0_1px_rgba(0,0,0,0.45)]"
              style={{
                left: `${(crop.x / docWidth) * 100}%`,
                top: `${(crop.y / docHeight) * 100}%`,
                width: `${(crop.w / docWidth) * 100}%`,
                height: `${(crop.h / docHeight) * 100}%`,
              }}
              onPointerDown={(event) => beginCrop(event, "move")}
            >
              <div className="pointer-events-none absolute inset-0 grid grid-cols-3 grid-rows-3">
                {Array.from({ length: 9 }).map((_, index) => (
                  <span key={index} className="border border-white/30" />
                ))}
              </div>
              {(["nw", "ne", "sw", "se"] as const).map((handle) => (
                <span
                  key={handle}
                  role="presentation"
                  onPointerDown={(event) => beginCrop(event, handle)}
                  className="absolute h-4 w-4 rounded-sm border-2 border-brand-600 bg-white shadow"
                  style={{
                    left: handle.includes("w") ? -8 : undefined,
                    right: handle.includes("e") ? -8 : undefined,
                    top: handle.includes("n") ? -8 : undefined,
                    bottom: handle.includes("s") ? -8 : undefined,
                    cursor: `${handle}-resize`,
                  }}
                />
              ))}
            </div>
          </div>
        )}
      </div>

      <span className="pointer-events-none absolute bottom-1.5 right-2 rounded bg-white/85 px-1.5 py-0.5 text-[10px] font-medium tabular-nums text-ink-muted shadow-sm">
        {state.doc.width} × {state.doc.height}
      </span>
    </div>
  );
}

function SelectionOutline({
  layer,
  docWidth,
  docHeight,
}: {
  layer: Layer;
  docWidth: number;
  docHeight: number;
}) {
  const bounds = measureLayer(layer);
  return (
    <div
      aria-hidden="true"
      className="pointer-events-none absolute border-2 border-brand-500"
      style={{
        left: `${((layer.x - bounds.width / 2) / docWidth) * 100}%`,
        top: `${((layer.y - bounds.height / 2) / docHeight) * 100}%`,
        width: `${(bounds.width / docWidth) * 100}%`,
        height: `${(bounds.height / docHeight) * 100}%`,
        transform: `rotate(${layer.rotation}deg)`,
      }}
    />
  );
}

function clamp(value: number, min: number, max: number) {
  return Math.min(max, Math.max(min, value));
}
