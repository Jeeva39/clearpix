import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  ApiError,
  removeBackground,
  validateImageFile,
  zipResults,
  formatBytes,
} from "../../lib/api";
import { baseName, saveBlob } from "../../lib/download";
import { track } from "../../lib/analytics";
import { MAX_BATCH_FILES } from "../../lib/site";

export type JobStatus = "queued" | "uploading" | "processing" | "done" | "error";

export type Job = {
  id: string;
  file: File;
  previewUrl: string;
  name: string;
  sizeLabel: string;
  width: number;
  height: number;
  status: JobStatus;
  uploadProgress: number;
  resultUrl?: string;
  resultBlob?: Blob;
  error?: string;
  errorCode?: string;
  retryable?: boolean;
  startedAt?: number;
  processingMs?: number;
};

export type UploadIssue = { id: string; name: string; message: string };

const CONCURRENCY = 2;

function createId(): string {
  return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
}

export function useBackgroundRemover() {
  const [jobs, setJobs] = useState<Job[]>([]);
  const [issues, setIssues] = useState<UploadIssue[]>([]);
  const [mode, setMode] = useState<"general" | "portrait">("general");
  const [activeId, setActiveId] = useState<string | null>(null);
  const [isZipping, setIsZipping] = useState(false);
  const [zipError, setZipError] = useState<string | null>(null);

  const running = useRef<Set<string>>(new Set());
  const controllers = useRef<Map<string, AbortController>>(new Map());
  const urls = useRef<Set<string>>(new Set());
  const jobsRef = useRef<Job[]>([]);
  jobsRef.current = jobs;

  const trackUrl = useCallback((url: string) => {
    urls.current.add(url);
    return url;
  }, []);

  useEffect(() => {
    const saved = urls.current;
    return () => {
      saved.forEach((url) => URL.revokeObjectURL(url));
      controllers.current.forEach((controller) => controller.abort());
    };
  }, []);

  const updateJob = useCallback((id: string, patch: Partial<Job>) => {
    setJobs((current) => current.map((job) => (job.id === id ? { ...job, ...patch } : job)));
  }, []);

  const startJob = useCallback(
    async (job: Job) => {
      if (running.current.has(job.id)) return;
      running.current.add(job.id);

      const controller = new AbortController();
      controllers.current.set(job.id, controller);
      const startedAt = Date.now();

      updateJob(job.id, {
        status: "uploading",
        uploadProgress: 0,
        error: undefined,
        errorCode: undefined,
        startedAt,
      });

      const startedHint = setTimeout(() => {
        setJobs((current) =>
          current.map((item) =>
            item.id === job.id && item.status === "uploading"
              ? { ...item, status: "processing", uploadProgress: 100 }
              : item,
          ),
        );
      }, 400);

      try {
        const blob = await removeBackground(job.file, {
          mode,
          signal: controller.signal,
          onUploadProgress: (percent) => {
            setJobs((current) =>
              current.map((item) =>
                item.id === job.id && (item.status === "uploading" || item.status === "processing")
                  ? {
                      ...item,
                      status: percent >= 100 ? "processing" : "uploading",
                      uploadProgress: percent,
                    }
                  : item,
              ),
            );
          },
        });

        clearTimeout(startedHint);
        const resultUrl = trackUrl(URL.createObjectURL(blob));
        updateJob(job.id, {
          status: "done",
          resultBlob: blob,
          resultUrl,
          uploadProgress: 100,
          processingMs: Date.now() - startedAt,
        });
        setActiveId((current) => current ?? job.id);
        track("background_removal_completed", {
          mode,
          size_kb: Math.round(job.file.size / 1024),
        });
      } catch (error) {
        clearTimeout(startedHint);
        const apiError =
          error instanceof ApiError
            ? error
            : new ApiError("Something went wrong while processing your image. Please try again.");
        updateJob(job.id, {
          status: "error",
          error: apiError.message,
          errorCode: apiError.code,
          retryable: apiError.retryable,
        });
        track("error_occurred", { code: apiError.code });
      } finally {
        running.current.delete(job.id);
        controllers.current.delete(job.id);
      }
    },
    [mode, trackUrl, updateJob],
  );

  useEffect(() => {
    const busy = jobs.filter((job) => job.status === "uploading" || job.status === "processing").length;
    if (busy >= CONCURRENCY) return;
    const next = jobs.find((job) => job.status === "queued" && !running.current.has(job.id));
    if (!next) return;
    void startJob(next);
  }, [jobs, startJob]);

  const addFiles = useCallback(
    async (files: File[]) => {
      setZipError(null);
      setIssues([]);

      const accepted: Job[] = [];
      const rejected: UploadIssue[] = [];
      const remaining = MAX_BATCH_FILES - jobsRef.current.length;

      for (const file of files) {
        if (accepted.length >= remaining) {
          rejected.push({
            id: createId(),
            name: file.name,
            message: `You can process up to ${MAX_BATCH_FILES} images at a time. Remove one to add another.`,
          });
          continue;
        }
        try {
          const info = await validateImageFile(file);
          accepted.push({
            id: createId(),
            file,
            previewUrl: trackUrl(URL.createObjectURL(file)),
            name: info.name,
            sizeLabel: formatBytes(info.size),
            width: info.width,
            height: info.height,
            status: "queued",
            uploadProgress: 0,
          });
        } catch (error) {
          rejected.push({
            id: createId(),
            name: file.name,
            message:
              error instanceof ApiError
                ? error.message
                : "That file could not be read. Please try another image.",
          });
        }
      }

      if (accepted.length > 0) {
        setJobs((current) => [...current, ...accepted]);
        setActiveId((current) => current ?? accepted[0].id);
        track("upload_started", { count: accepted.length });
        if (accepted.length > 1 || jobsRef.current.length > 0) {
          track("batch_processing_started", { count: accepted.length });
        }
      }

      if (rejected.length > 0) {
        setIssues(rejected);
        rejected.forEach(() => track("error_occurred", { code: "upload_rejected" }));
      }

      return { accepted: accepted.length, rejected: rejected.length };
    },
    [trackUrl],
  );

  const removeJob = useCallback((id: string) => {
    controllers.current.get(id)?.abort();
    controllers.current.delete(id);
    setJobs((current) => {
      const job = current.find((item) => item.id === id);
      if (job) {
        URL.revokeObjectURL(job.previewUrl);
        urls.current.delete(job.previewUrl);
        if (job.resultUrl) {
          URL.revokeObjectURL(job.resultUrl);
          urls.current.delete(job.resultUrl);
        }
      }
      return current.filter((item) => item.id !== id);
    });
    setActiveId((current) => (current === id ? null : current));
  }, []);

  const retryJob = useCallback((id: string) => {
    updateJob(id, {
      status: "queued",
      error: undefined,
      errorCode: undefined,
      uploadProgress: 0,
    });
  }, [updateJob]);

  const processAll = useCallback(() => {
    setJobs((current) =>
      current.map((job) =>
        job.status === "error" || job.status === "queued" ? { ...job, status: "queued", error: undefined } : job,
      ),
    );
  }, []);

  const retryFailed = useCallback(() => {
    setJobs((current) =>
      current.map((job) => (job.status === "error" ? { ...job, status: "queued", error: undefined } : job)),
    );
  }, []);

  const clearAll = useCallback(() => {
    controllers.current.forEach((controller) => controller.abort());
    controllers.current.clear();
    jobsRef.current.forEach((job) => {
      URL.revokeObjectURL(job.previewUrl);
      if (job.resultUrl) URL.revokeObjectURL(job.resultUrl);
    });
    urls.current.clear();
    setJobs([]);
    setActiveId(null);
    setIssues([]);
    setZipError(null);
  }, []);

  const dismissIssue = useCallback((id: string) => {
    setIssues((current) => current.filter((issue) => issue.id !== id));
  }, []);

  const downloadJob = useCallback((job: Job) => {
    if (!job.resultBlob) return;
    saveBlob(job.resultBlob, "clearpix-background-removed.png");
    track("download_completed", { format: "png", type: "single" });
  }, []);

  const downloadAll = useCallback(async () => {
    const done = jobsRef.current.filter((job) => job.status === "done" && job.resultBlob);
    if (done.length === 0) return;
    if (done.length === 1) {
      saveBlob(done[0].resultBlob as Blob, "clearpix-background-removed.png");
      track("download_completed", { format: "png", type: "single" });
      return;
    }

    setIsZipping(true);
    setZipError(null);
    try {
      const archive = await zipResults(
        done.map((job) => ({ blob: job.resultBlob as Blob, name: baseName(job.name) })),
      );
      saveBlob(archive, "clearpix-results.zip");
      track("download_completed", { format: "zip", type: "batch", count: done.length });
    } catch (error) {
      setZipError(
        error instanceof ApiError
          ? error.message
          : "We could not create the ZIP download. Please try again.",
      );
      track("error_occurred", { code: "zip_failed" });
    } finally {
      setIsZipping(false);
    }
  }, []);

  const doneCount = useMemo(() => jobs.filter((job) => job.status === "done").length, [jobs]);
  const failedCount = useMemo(() => jobs.filter((job) => job.status === "error").length, [jobs]);
  const isBusy = useMemo(
    () => jobs.some((job) => ["queued", "uploading", "processing"].includes(job.status)),
    [jobs],
  );
  const activeJob = useMemo(() => {
    if (jobs.length === 0) return null;
    const explicit = jobs.find((job) => job.id === activeId);
    if (explicit && explicit.status !== "error") return explicit;
    return jobs.find((job) => job.status === "done") ?? jobs[0];
  }, [activeId, jobs]);

  return {
    jobs,
    issues,
    mode,
    setMode,
    activeJob,
    activeId: activeJob?.id ?? null,
    setActiveId,
    addFiles,
    removeJob,
    retryJob,
    retryFailed,
    processAll,
    clearAll,
    dismissIssue,
    downloadJob,
    downloadAll,
    doneCount,
    failedCount,
    isBusy,
    isZipping,
    zipError,
  };
}
