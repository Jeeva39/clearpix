import { useEffect, useMemo, useRef, useState } from "react";
import { Icon } from "../../components/Icon";
import { CompareSlider } from "../../components/CompareSlider";
import { formatBytes } from "../../lib/api";
import { saveBlob } from "../../lib/download";
import { track } from "../../lib/analytics";
import type { Job } from "./useBackgroundRemover";

const BACKGROUNDS = [
  { id: "checker", label: "Transparent", swatch: "checkerboard", color: null },
  { id: "white", label: "White", swatch: "bg-white", color: "#ffffff" },
  { id: "black", label: "Black", swatch: "bg-ink", color: "#1c1c28" },
  { id: "gray", label: "Light gray", swatch: "bg-[#f1f1f5]", color: "#f1f1f5" },
  { id: "lilac", label: "Lilac", swatch: "bg-[#e8e6ff]", color: "#e8e6ff" },
  { id: "mint", label: "Mint", swatch: "bg-[#d9f3e8]", color: "#d9f3e8" },
  { id: "sand", label: "Sand", swatch: "bg-[#f7e6cf]", color: "#f7e6cf" },
] as const;

type BackgroundId = (typeof BACKGROUNDS)[number]["id"];

async function composeJpeg(blob: Blob, color: string): Promise<Blob> {
  const url = URL.createObjectURL(blob);
  try {
    const image = await new Promise<HTMLImageElement>((resolve, reject) => {
      const element = new Image();
      element.onload = () => resolve(element);
      element.onerror = () => reject(new Error("Could not read the processed image"));
      element.src = url;
    });

    const canvas = document.createElement("canvas");
    canvas.width = image.naturalWidth;
    canvas.height = image.naturalHeight;
    const context = canvas.getContext("2d");
    if (!context) throw new Error("Canvas is not available in this browser");
    context.fillStyle = color;
    context.fillRect(0, 0, canvas.width, canvas.height);
    context.drawImage(image, 0, 0);

    const output = await new Promise<Blob | null>((resolve) =>
      canvas.toBlob((result) => resolve(result), "image/jpeg", 0.92),
    );
    if (!output) throw new Error("Export failed");
    return output;
  } finally {
    URL.revokeObjectURL(url);
  }
}

type ResultEditorProps = {
  job: Job;
  onDownload: () => void;
  onRemove: () => void;
  onProcessAnother: () => void;
  onReplace: (file: File) => void;
};

export function ResultEditor({ job, onDownload, onRemove, onProcessAnother, onReplace }: ResultEditorProps) {
  const replaceRef = useRef<HTMLInputElement>(null);
  const [view, setView] = useState<"compare" | "preview">("compare");
  const [background, setBackground] = useState<BackgroundId>("checker");
  const [zoom, setZoom] = useState(1);
  const [exporting, setExporting] = useState(false);
  const [exportError, setExportError] = useState<string | null>(null);

  useEffect(() => {
    setZoom(1);
    setView("compare");
  }, [job.id]);

  const activeBackground = useMemo(
    () => BACKGROUNDS.find((item) => item.id === background) ?? BACKGROUNDS[0],
    [background],
  );

  const resultSize = job.resultBlob ? formatBytes(job.resultBlob.size) : "";

  const downloadJpeg = async () => {
    if (!job.resultBlob) return;
    setExporting(true);
    setExportError(null);
    try {
      const jpeg = await composeJpeg(job.resultBlob, activeBackground.color ?? "#ffffff");
      saveBlob(jpeg, "clearpix-background-removed.jpg");
      track("download_completed", { format: "jpg", type: "single" });
    } catch {
      setExportError("We could not create the JPG. Please try again.");
    } finally {
      setExporting(false);
    }
  };

  return (
    <div className="grid gap-5 lg:grid-cols-[minmax(0,1fr)_320px]">
      <div className="overflow-hidden rounded-xl2 border border-ink/[0.08] bg-white shadow-soft">
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-ink/[0.07] px-4 py-3">
          <div className="inline-flex rounded-full bg-mist p-1" role="tablist" aria-label="Result view">
            <button
              type="button"
              role="tab"
              aria-selected={view === "compare"}
              onClick={() => setView("compare")}
              className={`rounded-full px-3.5 py-1.5 text-xs font-semibold transition ${
                view === "compare" ? "bg-white text-ink shadow-soft" : "text-ink-muted hover:text-ink"
              }`}
            >
              Compare
            </button>
            <button
              type="button"
              role="tab"
              aria-selected={view === "preview"}
              onClick={() => setView("preview")}
              className={`rounded-full px-3.5 py-1.5 text-xs font-semibold transition ${
                view === "preview" ? "bg-white text-ink shadow-soft" : "text-ink-muted hover:text-ink"
              }`}
            >
              Preview background
            </button>
          </div>
          <span className="text-xs text-ink-muted">
            {job.width} × {job.height} px {resultSize ? `· PNG ${resultSize}` : ""}
          </span>
        </div>

        {view === "compare" ? (
          <div className="p-3 sm:p-4">
            <CompareSlider
              beforeSrc={job.previewUrl}
              afterSrc={job.resultUrl ?? job.previewUrl}
              beforeAlt={`Original uploaded image: ${job.name}`}
              afterAlt={`Background-removed transparent PNG of ${job.name}`}
              afterLabel="Transparent"
            />
            <p className="px-1 pt-2 text-center text-xs text-ink-muted">
              Drag the slider to compare the original photo with the transparent result.
            </p>
          </div>
        ) : (
          <div className="p-3 sm:p-4">
            <div
              className={`relative flex h-[300px] items-center justify-center overflow-hidden rounded-xl sm:h-[400px] ${
                activeBackground.id === "checker" ? "checkerboard" : ""
              }`}
              style={
                activeBackground.color ? { backgroundColor: activeBackground.color } : undefined
              }
            >
              <img
                src={job.resultUrl}
                alt={`Background-removed image preview of ${job.name} on a ${activeBackground.label.toLowerCase()} background`}
                className="max-h-full max-w-full origin-center object-contain transition-transform duration-200"
                style={{ transform: `scale(${zoom})` }}
                draggable={false}
              />
            </div>
          </div>
        )}

        <div className="flex flex-wrap items-center justify-between gap-3 border-t border-ink/[0.07] px-4 py-3">
          <div className="flex items-center gap-1" role="group" aria-label="Zoom controls">
            <button
              type="button"
              onClick={() => setZoom((value) => Math.min(3, Number((value + 0.25).toFixed(2))))}
              className="grid h-9 w-9 place-items-center rounded-lg border border-ink/10 text-ink-soft transition hover:bg-mist hover:text-ink disabled:opacity-40"
              aria-label="Zoom in"
              disabled={zoom >= 3}
            >
              <Icon name="zoom-in" size={18} />
            </button>
            <button
              type="button"
              onClick={() => setZoom((value) => Math.max(0.5, Number((value - 0.25).toFixed(2))))}
              className="grid h-9 w-9 place-items-center rounded-lg border border-ink/10 text-ink-soft transition hover:bg-mist hover:text-ink disabled:opacity-40"
              aria-label="Zoom out"
              disabled={zoom <= 0.5}
            >
              <Icon name="zoom-out" size={18} />
            </button>
            <button
              type="button"
              onClick={() => setZoom(1)}
              className="ml-1 inline-flex h-9 items-center gap-1.5 rounded-lg border border-ink/10 px-3 text-xs font-semibold text-ink-soft transition hover:bg-mist hover:text-ink"
            >
              <Icon name="maximize" size={15} />
              Fit / reset
            </button>
            <span className="ml-2 w-10 text-xs tabular-nums text-ink-muted">{Math.round(zoom * 100)}%</span>
          </div>
          <div className="flex items-center gap-1">
            <input
              ref={replaceRef}
              type="file"
              accept="image/jpeg,image/png,image/webp,.jpg,.jpeg,.png,.webp"
              className="sr-only"
              tabIndex={-1}
              aria-hidden="true"
              onChange={(event) => {
                const file = event.target.files?.[0];
                if (file) onReplace(file);
                event.target.value = "";
              }}
            />
            <button
              type="button"
              onClick={() => replaceRef.current?.click()}
              className="inline-flex items-center gap-1.5 rounded-lg px-2.5 py-2 text-xs font-semibold text-ink-muted transition hover:bg-mist hover:text-ink"
            >
              <Icon name="refresh" size={15} />
              Replace
            </button>
            <button
              type="button"
              onClick={onRemove}
              className="inline-flex items-center gap-1.5 rounded-lg px-2.5 py-2 text-xs font-semibold text-ink-muted transition hover:bg-red-50 hover:text-red-600"
            >
              <Icon name="trash" size={15} />
              Remove image
            </button>
          </div>
        </div>
      </div>

      <div className="flex flex-col gap-4">
        <div className="card p-4">
          <h3 className="text-sm font-bold text-ink">Download</h3>
          <p className="mt-1 text-xs leading-5 text-ink-muted">
            Your transparent PNG keeps the cut-out subject with a fully transparent background.
          </p>
          <button type="button" onClick={onDownload} className="btn-primary mt-3 w-full">
            <Icon name="download" size={17} />
            Download Transparent PNG
          </button>
          <button
            type="button"
            onClick={() => void downloadJpeg()}
            disabled={exporting}
            className="btn-secondary mt-2 w-full"
          >
            <Icon name={exporting ? "loader" : "image"} size={17} className={exporting ? "animate-spin" : ""} />
            {exporting ? "Preparing JPG…" : "Download JPG with background"}
          </button>
          {exportError && (
            <p role="alert" className="mt-2 text-xs font-medium text-red-600">
              {exportError}
            </p>
          )}
          <p className="mt-2 text-[11px] leading-4 text-ink-muted">
            JPG exports use the preview colour you selected ({activeBackground.label}).
          </p>
        </div>

        <div className="card p-4">
          <h3 className="text-sm font-bold text-ink">Preview background</h3>
          <p className="mt-1 text-xs leading-5 text-ink-muted">
            Preview only — the downloaded PNG stays transparent.
          </p>
          <div className="mt-3 grid grid-cols-4 gap-2" role="group" aria-label="Preview background colour">
            {BACKGROUNDS.map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() => {
                  setBackground(item.id);
                  setView("preview");
                }}
                aria-pressed={background === item.id}
                aria-label={`Preview on ${item.label}`}
                title={item.label}
                className={`relative h-11 rounded-lg border-2 transition ${
                  item.swatch
                } ${
                  background === item.id
                    ? "border-brand-600 ring-2 ring-brand-200"
                    : "border-ink/10 hover:border-brand-300"
                }`}
              >
                {background === item.id && (
                  <Icon
                    name="check"
                    size={14}
                    className={`absolute bottom-1 right-1 ${
                      item.id === "black" || item.id === "white" ? "text-ink" : "text-brand-800"
                    }`}
                  />
                )}
              </button>
            ))}
            <span className="flex items-center text-[10px] font-medium leading-tight text-ink-muted">
              {activeBackground.label}
            </span>
          </div>
        </div>

        <div className="card p-4">
          <h3 className="text-sm font-bold text-ink">Next step</h3>
          <p className="mt-1 text-xs leading-5 text-ink-muted">
            Need another cut-out? Drop in a new image — up to five at a time.
          </p>
          <button type="button" onClick={onProcessAnother} className="btn-secondary mt-3 w-full">
            <Icon name="plus" size={16} />
            Process another image
          </button>
        </div>
      </div>
    </div>
  );
}
