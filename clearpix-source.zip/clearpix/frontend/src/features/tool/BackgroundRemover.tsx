import { useRef } from "react";
import { Icon } from "../../components/Icon";
import { ACCEPT_ATTRIBUTE, MAX_BATCH_FILES } from "../../lib/site";
import { UploadZone } from "./UploadZone";
import { JobStatusCard } from "./JobStatusCard";
import { ResultEditor } from "./ResultEditor";
import { useBackgroundRemover } from "./useBackgroundRemover";

const STATUS_LABEL: Record<string, string> = {
  queued: "Queued",
  uploading: "Uploading",
  processing: "Processing",
  done: "Ready",
  error: "Failed",
};

export function BackgroundRemover() {
  const addRef = useRef<HTMLInputElement>(null);
  const tool = useBackgroundRemover();
  const { activeJob } = tool;

  const openPicker = () => {
    if (tool.jobs.length >= MAX_BATCH_FILES) return;
    addRef.current?.click();
  };

  return (
    <section id="tool" aria-labelledby="tool-heading" className="scroll-mt-24">
      <div className="card overflow-hidden shadow-card">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-ink/[0.07] bg-white px-4 py-3.5 sm:px-6">
          <div className="flex items-center gap-2">
            <span className="grid h-8 w-8 place-items-center rounded-lg bg-brand-50 text-brand-600">
              <Icon name="scissors" size={16} />
            </span>
            <h2 id="tool-heading" className="text-sm font-bold text-ink">
              Background remover
            </h2>
            <span className="hidden rounded-full bg-emerald-50 px-2 py-0.5 text-[11px] font-semibold text-emerald-700 sm:inline">
              Free
            </span>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {tool.jobs.length > 0 && (
              <>
                <div
                  className="inline-flex rounded-full bg-mist p-1 text-[11px] font-semibold"
                  role="group"
                  aria-label="Segmentation model"
                >
                  <button
                    type="button"
                    onClick={() => tool.setMode("general")}
                    aria-pressed={tool.mode === "general"}
                    className={`rounded-full px-2.5 py-1 transition ${
                      tool.mode === "general" ? "bg-white text-ink shadow-soft" : "text-ink-muted"
                    }`}
                    title="Best for products, objects and general photos"
                  >
                    General
                  </button>
                  <button
                    type="button"
                    onClick={() => tool.setMode("portrait")}
                    aria-pressed={tool.mode === "portrait"}
                    className={`rounded-full px-2.5 py-1 transition ${
                      tool.mode === "portrait" ? "bg-white text-ink shadow-soft" : "text-ink-muted"
                    }`}
                    title="Optimised for people and portraits"
                  >
                    People
                  </button>
                </div>
                <button
                  type="button"
                  onClick={openPicker}
                  disabled={tool.jobs.length >= MAX_BATCH_FILES}
                  className="inline-flex items-center gap-1.5 rounded-full border border-ink/10 px-3 py-1.5 text-xs font-semibold text-ink-soft transition hover:bg-mist hover:text-ink disabled:opacity-50"
                >
                  <Icon name="plus" size={14} />
                  Add image
                </button>
                <button
                  type="button"
                  onClick={tool.clearAll}
                  className="inline-flex items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-semibold text-ink-muted transition hover:bg-red-50 hover:text-red-600"
                >
                  <Icon name="close" size={14} />
                  Clear
                </button>
              </>
            )}
          </div>
        </div>

        <div className="bg-mist/60 p-3 sm:p-5">
          <input
            ref={addRef}
            type="file"
            accept={ACCEPT_ATTRIBUTE}
            multiple
            className="sr-only"
            tabIndex={-1}
            onChange={(event) => {
              const files = Array.from(event.target.files ?? []);
              if (files.length > 0) void tool.addFiles(files);
              event.target.value = "";
            }}
            aria-hidden="true"
          />

          {tool.issues.length > 0 && (
            <div className="mb-3 space-y-2" aria-live="assertive">
              {tool.issues.map((issue) => (
                <div
                  key={issue.id}
                  role="alert"
                  className="flex items-start gap-3 rounded-xl border border-red-200 bg-red-50 px-3.5 py-3 text-sm text-red-700"
                >
                  <Icon name="alert" size={17} className="mt-0.5 shrink-0" />
                  <div className="min-w-0 flex-1">
                    <p className="font-semibold">{issue.message}</p>
                    <p className="truncate text-xs text-red-600/80">{issue.name}</p>
                  </div>
                  <button
                    type="button"
                    onClick={() => tool.dismissIssue(issue.id)}
                    className="rounded-md p-1 transition hover:bg-red-100"
                    aria-label="Dismiss this message"
                  >
                    <Icon name="close" size={15} />
                  </button>
                </div>
              ))}
            </div>
          )}

          {tool.jobs.length === 0 ? (
            <>
              <UploadZone onFiles={(files) => void tool.addFiles(files)} />
              <p className="mt-3 flex items-center justify-center gap-1.5 text-center text-xs text-ink-muted">
                <Icon name="lock" size={13} className="text-brand-600" />
                Your images are processed securely and are not stored permanently.
              </p>
            </>
          ) : (
            <div className="space-y-4">
              {activeJob && (
                <>
                  {activeJob.status === "done" ? (
                    <ResultEditor
                      job={activeJob}
                      onDownload={() => tool.downloadJob(activeJob)}
                      onRemove={() => tool.removeJob(activeJob.id)}
                      onProcessAnother={openPicker}
                      onReplace={(file) => {
                        tool.removeJob(activeJob.id);
                        void tool.addFiles([file]);
                      }}
                    />
                  ) : (
                    <JobStatusCard
                      job={activeJob}
                      onRetry={() => tool.retryJob(activeJob.id)}
                      onRemove={() => tool.removeJob(activeJob.id)}
                    />
                  )}
                </>
              )}

              <div className="rounded-xl2 border border-ink/[0.08] bg-white p-3 shadow-soft sm:p-4">
                <div className="flex flex-wrap items-center justify-between gap-2 px-1 pb-2">
                  <h3 className="text-xs font-bold uppercase tracking-[0.12em] text-ink-muted">
                    Your images ({tool.jobs.length}/{MAX_BATCH_FILES})
                  </h3>
                  <div className="flex flex-wrap items-center gap-2">
                    {(tool.failedCount > 0 || tool.jobs.some((job) => job.status === "queued")) && (
                      <button
                        type="button"
                        onClick={tool.failedCount > 0 ? tool.retryFailed : tool.processAll}
                        className="inline-flex items-center gap-1.5 rounded-full border border-ink/10 px-3 py-1.5 text-xs font-semibold text-ink-soft transition hover:bg-mist"
                      >
                        <Icon name="refresh" size={13} />
                        {tool.failedCount > 0 ? "Retry failed" : "Process all"}
                      </button>
                    )}
                    {tool.doneCount > 1 && (
                      <button
                        type="button"
                        onClick={() => void tool.downloadAll()}
                        disabled={tool.isZipping}
                        className="inline-flex items-center gap-1.5 rounded-full bg-brand-600 px-3 py-1.5 text-xs font-semibold text-white transition hover:bg-brand-700 disabled:opacity-60"
                      >
                        <Icon name={tool.isZipping ? "loader" : "package"} size={13} className={tool.isZipping ? "animate-spin" : ""} />
                        {tool.isZipping ? "Zipping…" : "Download all (ZIP)"}
                      </button>
                    )}
                  </div>
                </div>

                {tool.zipError && (
                  <p role="alert" className="mx-1 mb-2 rounded-lg bg-red-50 px-3 py-2 text-xs font-medium text-red-700">
                    {tool.zipError}
                  </p>
                )}

                <ul className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
                  {tool.jobs.map((job) => {
                    const isActive = activeJob?.id === job.id;
                    return (
                      <li key={job.id}>
                        <div
                          className={`flex gap-3 rounded-xl border p-2.5 transition ${
                            isActive ? "border-brand-300 bg-brand-50/50" : "border-ink/[0.07] bg-white hover:border-brand-200"
                          }`}
                        >
                          <button
                            type="button"
                            onClick={() => tool.setActiveId(job.id)}
                            className="checkerboard relative h-16 w-16 shrink-0 overflow-hidden rounded-lg border border-ink/[0.06]"
                            aria-label={`View ${job.name}`}
                          >
                            <img
                              src={job.resultUrl ?? job.previewUrl}
                              alt=""
                              className="h-full w-full object-contain"
                              loading="lazy"
                            />
                            {job.status === "processing" || job.status === "uploading" ? (
                              <span className="absolute inset-0 grid place-items-center bg-white/70">
                                <Icon name="loader" size={18} className="animate-spin text-brand-600" />
                              </span>
                            ) : null}
                          </button>

                          <div className="min-w-0 flex-1">
                            <p className="truncate text-xs font-semibold text-ink" title={job.name}>
                              {job.name}
                            </p>
                            <p className="mt-0.5 flex items-center gap-1.5 text-[11px] text-ink-muted">
                              <span>{job.sizeLabel}</span>
                              <span aria-hidden="true">·</span>
                              <span
                                className={
                                  job.status === "done"
                                    ? "font-semibold text-emerald-600"
                                    : job.status === "error"
                                      ? "font-semibold text-red-600"
                                      : "font-semibold text-brand-700"
                                }
                              >
                                {STATUS_LABEL[job.status]}
                              </span>
                            </p>

                            <div className="mt-1.5 flex items-center gap-1">
                              {job.status === "done" && (
                                <button
                                  type="button"
                                  onClick={() => tool.downloadJob(job)}
                                  className="inline-flex items-center gap-1 rounded-md px-1.5 py-1 text-[11px] font-semibold text-brand-700 transition hover:bg-brand-100"
                                >
                                  <Icon name="download" size={12} />
                                  Download
                                </button>
                              )}
                              {job.status === "error" && (
                                <button
                                  type="button"
                                  onClick={() => tool.retryJob(job.id)}
                                  className="inline-flex items-center gap-1 rounded-md px-1.5 py-1 text-[11px] font-semibold text-brand-700 transition hover:bg-brand-100"
                                >
                                  <Icon name="refresh" size={12} />
                                  Retry
                                </button>
                              )}
                              <button
                                type="button"
                                onClick={() => tool.removeJob(job.id)}
                                className="ml-auto rounded-md p-1 text-ink-muted transition hover:bg-red-50 hover:text-red-600"
                                aria-label={`Remove ${job.name}`}
                              >
                                <Icon name="trash" size={13} />
                              </button>
                            </div>
                          </div>
                        </div>
                      </li>
                    );
                  })}
                </ul>
                <p className="mt-3 flex items-center gap-1.5 px-1 text-[11px] text-ink-muted">
                  <Icon name="shield" size={12} />
                  Your image never leaves this device — the AI model runs in your browser.
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}
