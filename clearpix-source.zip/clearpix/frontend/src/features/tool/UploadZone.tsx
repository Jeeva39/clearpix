import { useRef, useState } from "react";
import { Icon } from "../../components/Icon";
import { ACCEPT_ATTRIBUTE, MAX_BATCH_FILES, MAX_FILE_SIZE_LABEL } from "../../lib/site";
import { usePasteImages } from "../../lib/hooks";

type UploadZoneProps = {
  onFiles: (files: File[]) => void;
  disabled?: boolean;
  compact?: boolean;
};

export function UploadZone({ onFiles, disabled = false, compact = false }: UploadZoneProps) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [dragging, setDragging] = useState(false);
  const dragDepth = useRef(0);

  const openPicker = () => {
    if (!disabled) inputRef.current?.click();
  };

  usePasteImages(onFiles, !disabled);

  return (
    <div
      onDragEnter={(event) => {
        event.preventDefault();
        dragDepth.current += 1;
        if (!disabled) setDragging(true);
      }}
      onDragOver={(event) => {
        event.preventDefault();
        event.dataTransfer.dropEffect = "copy";
      }}
      onDragLeave={(event) => {
        event.preventDefault();
        dragDepth.current = Math.max(0, dragDepth.current - 1);
        if (dragDepth.current === 0) setDragging(false);
      }}
      onDrop={(event) => {
        event.preventDefault();
        dragDepth.current = 0;
        setDragging(false);
        if (disabled) return;
        const files = Array.from(event.dataTransfer.files ?? []);
        if (files.length > 0) onFiles(files);
      }}
      onClick={openPicker}
      onKeyDown={(event) => {
        if (event.key === "Enter" || event.key === " ") {
          event.preventDefault();
          openPicker();
        }
      }}
      role="button"
      tabIndex={disabled ? -1 : 0}
      aria-disabled={disabled}
      aria-label="Upload an image: drag and drop a file here, or press Enter to browse files"
      className={[
        "group relative flex w-full cursor-pointer flex-col items-center justify-center rounded-xl2 border-2 border-dashed px-5 text-center transition duration-200",
        compact ? "py-8" : "py-12 sm:py-14",
        dragging
          ? "border-brand-500 bg-brand-50/80 shadow-lift"
          : "border-ink/15 bg-white hover:border-brand-400 hover:bg-brand-50/40",
        disabled ? "cursor-not-allowed opacity-70" : "",
      ].join(" ")}
    >
      <input
        ref={inputRef}
        type="file"
        accept={ACCEPT_ATTRIBUTE}
        multiple
        capture={undefined}
        className="sr-only"
        tabIndex={-1}
        onChange={(event) => {
          const files = Array.from(event.target.files ?? []);
          if (files.length > 0) onFiles(files);
          event.target.value = "";
        }}
        aria-hidden="true"
      />

      <span
        className={[
          "grid h-14 w-14 place-items-center rounded-2xl transition duration-200",
          dragging
            ? "scale-105 bg-brand-600 text-white"
            : "bg-brand-50 text-brand-600 group-hover:bg-brand-100",
        ].join(" ")}
      >
        <Icon name={dragging ? "download" : "upload"} size={26} />
      </span>

      <span className="mt-5 text-lg font-bold text-ink sm:text-xl">
        {dragging ? "Drop your image here" : "Drag your image here"}
      </span>
      <span className="mt-1.5 text-sm text-ink-muted">
        or click to browse files — you can also paste an image with Ctrl / ⌘ + V
      </span>

      <span aria-hidden="true" className="btn-primary mt-5 px-6">
        <Icon name="upload" size={18} />
        Upload Image
      </span>

      <span className="mt-4 text-xs text-ink-muted">
        Supported formats: JPG, JPEG, PNG and WEBP · Maximum file size: {MAX_FILE_SIZE_LABEL}
      </span>
      <span className="mt-1 text-xs text-ink-muted">
        Up to {MAX_BATCH_FILES} images can be processed at once
      </span>
    </div>
  );
}
