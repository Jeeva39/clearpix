import { useEffect, useState } from "react";
import { Icon } from "../../components/Icon";
import { REMOVAL_ENGINE } from "../../lib/api";
import type { Job } from "./useBackgroundRemover";

const STEPS = [
  "Preparing your image...",
  "AI is detecting the subject...",
  "Removing the background...",
  "Preparing your transparent image...",
];

export function JobStatusCard({ job, onRetry, onRemove }: { job: Job; onRetry: () => void; onRemove: () => void }) {
  const [step, setStep] = useState(0);

  useEffect(() => {
    if (job.status !== "processing" && job.status !== "uploading") return;
    setStep(0);
    const timer = window.setInterval(() => {
      setStep((current) => Math.min(current + 1, STEPS.length - 1));
    }, 2600);
    return () => window.clearInterval(timer);
  }, [job.status, job.id]);

  if (job.status === "error") {
    return (
      <div className="rounded-xl2 border border-red-200 bg-red-50/70 p-5 sm:p-6">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-start">
          <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-red-100 text-red-600">
            <Icon name="alert" size={22} />
          </span>
          <div className="min-w-0 flex-1">
            <h3 className="text-base font-bold text-ink">We couldn't process this image</h3>
            <p role="alert" className="mt-1 text-sm leading-6 text-ink-soft">
              {job.error ?? "Something went wrong while removing the background."}
            </p>
            <p className="mt-1 truncate text-xs text-ink-muted">{job.name}</p>
            <div className="mt-4 flex flex-wrap gap-2">
              {job.retryable !== false && (
                <button type="button" onClick={onRetry} className="btn-primary px-4 py-2.5">
                  <Icon name="refresh" size={16} />
                  Try again
                </button>
              )}
              <button type="button" onClick={onRemove} className="btn-secondary px-4 py-2.5">
                <Icon name="trash" size={16} />
                Remove image
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  const isUploading = job.status === "uploading";
  const percent = job.uploadProgress;

  return (
    <div className="rounded-xl2 border border-ink/[0.08] bg-white p-4 shadow-soft sm:p-6">
      <div className="grid gap-5 sm:grid-cols-[180px_minmax(0,1fr)] sm:items-center">
        <div className="checkerboard relative overflow-hidden rounded-xl border border-ink/[0.06]">
          <img
            src={job.previewUrl}
            alt={`Preview of ${job.name} while it is being processed`}
            className="h-[150px] w-full object-contain"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-white/85 via-white/30 to-transparent" />
          <span className="absolute bottom-2 left-2 inline-flex items-center gap-1.5 rounded-full bg-white/90 px-2 py-1 text-[10px] font-semibold text-brand-700 shadow-soft">
            <Icon name="sparkles" size={12} className="animate-pulse" />
            AI working
          </span>
        </div>

        <div aria-live="polite">
          <p className="text-xs font-semibold uppercase tracking-[0.14em] text-brand-700">Processing</p>
          <h3 className="mt-1.5 text-lg font-bold text-ink sm:text-xl">{STEPS[step]}</h3>
          <p className="mt-1 truncate text-sm text-ink-muted">{job.name} · {job.sizeLabel}</p>

          <div className="mt-4 h-2 w-full overflow-hidden rounded-full bg-mist">
            {isUploading ? (
              <div
                className="h-full rounded-full bg-brand-600 transition-all duration-300"
                style={{ width: `${Math.max(6, percent)}%` }}
                role="progressbar"
                aria-valuenow={percent}
                aria-valuemin={0}
                aria-valuemax={100}
                aria-label="Progress"
              />
            ) : (
              <div className="relative h-full w-full overflow-hidden rounded-full bg-brand-100">
                <div className="absolute inset-y-0 -left-1/3 w-1/3 animate-shimmer rounded-full bg-gradient-to-r from-transparent via-brand-500 to-transparent" />
              </div>
            )}
          </div>

          <p className="mt-2 text-xs text-ink-muted">
            {isUploading
              ? REMOVAL_ENGINE === "browser"
                ? `Preparing the AI model… ${percent}%`
                : `Uploading your image… ${percent}%`
              : "Large images can take a little longer. Keep this tab open."}
          </p>
        </div>
      </div>
    </div>
  );
}
