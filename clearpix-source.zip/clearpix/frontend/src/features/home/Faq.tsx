import { Icon } from "../../components/Icon";
import { SectionHeading } from "../../components/SectionHeading";
import { FAQ_ITEMS } from "../../lib/faq";

export function Faq() {
  return (
    <section
      id="faq"
      aria-labelledby="faq-heading"
      className="scroll-mt-20 border-y border-ink/[0.06] bg-mist py-16 sm:py-20"
    >
      <div className="container-page">
        <SectionHeading
          eyebrow="FAQ"
          title="Frequently asked questions"
          description="Short answers to the things people ask before their first upload."
          id="faq-heading"
        />

        <div className="mx-auto mt-10 max-w-3xl divide-y divide-ink/[0.07] overflow-hidden rounded-xl2 border border-ink/[0.07] bg-white shadow-soft">
          {FAQ_ITEMS.map((item, index) => (
            <details key={item.question} className="group" open={index === 0}>
              <summary className="flex cursor-pointer list-none items-center justify-between gap-4 px-5 py-4 text-left text-sm font-semibold text-ink transition hover:bg-mist/70 sm:text-base [&::-webkit-details-marker]:hidden">
                <h3 className="text-sm font-semibold sm:text-base">{item.question}</h3>
                <span className="grid h-7 w-7 shrink-0 place-items-center rounded-full border border-ink/10 text-ink-muted transition group-open:rotate-180 group-open:border-brand-200 group-open:text-brand-700">
                  <Icon name="chevron-down" size={15} />
                </span>
              </summary>
              <div className="px-5 pb-5 text-sm leading-6 text-ink-soft">
                <p>{item.answer}</p>
              </div>
            </details>
          ))}
        </div>

        <p className="mx-auto mt-6 max-w-3xl text-center text-xs text-ink-muted">
          Still have a question?{" "}
          <a href="/contact" className="font-semibold text-brand-700 underline decoration-brand-300 underline-offset-2">
            Contact ClearPix
          </a>
          .
        </p>
      </div>
    </section>
  );
}
