import { Icon, type IconName } from "../../components/Icon";
import { SectionHeading } from "../../components/SectionHeading";

const STEPS: { icon: IconName; title: string; body: string; detail: string }[] = [
  {
    icon: "upload",
    title: "Upload Your Image",
    body: "Upload any photo from your device. ClearPix supports common image formats.",
    detail: "JPG, JPEG, PNG or WEBP · up to 10 MB",
  },
  {
    icon: "wand",
    title: "AI Removes the Background",
    body: "Our AI automatically detects the subject and separates it from the background.",
    detail: "Real segmentation — not a simple colour key",
  },
  {
    icon: "download",
    title: "Download Your Image",
    body: "Download your transparent PNG and use it anywhere.",
    detail: "Transparency preserved, no watermark",
  },
];

export function HowItWorks() {
  return (
    <section
      id="how-it-works"
      aria-labelledby="how-it-works-heading"
      className="scroll-mt-20 border-y border-ink/[0.06] bg-mist py-16 sm:py-20"
    >
      <div className="container-page">
        <SectionHeading
          eyebrow="How it works"
          title="Remove a background in three simple steps"
          description="No editing skills, no software to install, no account to create. ClearPix works right in your browser on any device."
          id="how-it-works-heading"
        />

        <ol className="mt-12 grid gap-4 sm:grid-cols-3">
          {STEPS.map((step, index) => (
            <li key={step.title} className="relative flex">
              <div className="card flex w-full flex-col p-6 transition duration-300 hover:-translate-y-1 hover:shadow-card">
                <div className="flex items-center justify-between">
                  <span className="grid h-12 w-12 place-items-center rounded-xl bg-gradient-to-br from-brand-500 to-indigo-700 text-white shadow-soft">
                    <Icon name={step.icon} size={22} />
                  </span>
                  <span className="text-3xl font-extrabold tabular-nums text-brand-100">
                    0{index + 1}
                  </span>
                </div>
                <h3 className="mt-5 text-lg font-bold text-ink">{step.title}</h3>
                <p className="mt-2 flex-1 text-sm leading-6 text-ink-soft">{step.body}</p>
                <p className="mt-4 inline-flex items-center gap-1.5 text-[11px] font-semibold text-brand-700">
                  <Icon name="check" size={13} />
                  {step.detail}
                </p>
              </div>
            </li>
          ))}
        </ol>
      </div>
    </section>
  );
}
