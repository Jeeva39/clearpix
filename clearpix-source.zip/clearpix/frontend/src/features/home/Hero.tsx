import { Link } from "react-router-dom";
import { Icon } from "../../components/Icon";
import { CompareSlider } from "../../components/CompareSlider";
import { BackgroundRemover } from "../tool/BackgroundRemover";

const TRUST_POINTS = [
  { icon: "check", title: "100% Free", detail: "No payment, no credits" },
  { icon: "user-off", title: "No Signup Required", detail: "Start in one click" },
  { icon: "layers", title: "Transparent PNG", detail: "Clean cut-out download" },
  { icon: "zap", title: "Fast AI Processing", detail: "Results in seconds" },
] as const;

export function Hero() {
  return (
    <section className="relative overflow-hidden" aria-labelledby="hero-heading">
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-x-0 top-0 -z-10 h-[520px] bg-[radial-gradient(60%_60%_at_50%_0%,rgba(122,99,246,0.14),rgba(255,255,255,0))]"
      />
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -left-24 top-40 -z-10 h-72 w-72 rounded-full bg-brand-100/60 blur-3xl"
      />

      <div className="container-page pb-16 pt-12 sm:pt-16 lg:pb-24">
        <div className="mx-auto max-w-3xl text-center">
          <span className="eyebrow">
            <Icon name="sparkles" size={13} />
            Free all-in-one image editor
          </span>
          <h1
            id="hero-heading"
            className="mt-5 text-[2rem] font-extrabold leading-[1.1] tracking-tight text-ink sm:text-5xl lg:text-[3.4rem]"
          >
            Edit Photos. Remove Backgrounds. Create Anything.
          </h1>
          <p className="mx-auto mt-5 max-w-2xl text-base leading-7 text-ink-soft sm:text-lg sm:leading-8">
            Your free all-in-one image editor. Remove backgrounds, change colors, resize images, add
            effects, and create stunning visuals online.
          </p>
          <div className="mt-7 flex flex-wrap items-center justify-center gap-2.5">
            <Link to="/editor" className="btn-primary px-6">
              <Icon name="sparkles" size={17} />
              Start Editing
            </Link>
            <a href="#tool" className="btn-secondary px-6">
              <Icon name="scissors" size={17} />
              Remove Background
            </a>
          </div>
        </div>

        <div className="mx-auto mt-9 max-w-3xl">
          <BackgroundRemover />
        </div>

        <ul className="mx-auto mt-8 grid max-w-3xl grid-cols-2 gap-3 sm:grid-cols-4">
          {TRUST_POINTS.map((point) => (
            <li
              key={point.title}
              className="flex flex-col items-center gap-1 rounded-xl border border-ink/[0.06] bg-white/70 px-3 py-3 text-center shadow-soft backdrop-blur"
            >
              <span className="grid h-8 w-8 place-items-center rounded-lg bg-brand-50 text-brand-600">
                <Icon name={point.icon} size={16} />
              </span>
              <span className="text-xs font-bold text-ink sm:text-sm">{point.title}</span>
              <span className="text-[11px] text-ink-muted">{point.detail}</span>
            </li>
          ))}
        </ul>

        <figure className="mx-auto mt-14 max-w-4xl">
          <div className="grid items-center gap-6 lg:grid-cols-[minmax(0,1fr)_320px]">
            <div className="card overflow-hidden p-3 shadow-card sm:p-4">
              <CompareSlider
                beforeSrc="/demo-before.svg"
                afterSrc="/demo-after.svg"
                beforeAlt="Illustration example of an original portrait photo with a coloured background"
                afterAlt="Illustration example of the same portrait with a transparent background"
                beforeLabel="Original"
                afterLabel="Background removed"
                className="aspect-[8/9] max-h-[430px]"
              />
            </div>
            <figcaption className="max-w-md">
              <span className="eyebrow">
                <Icon name="eye" size={13} />
                Before &amp; after
              </span>
              <h2 className="mt-3 text-xl font-bold text-ink sm:text-2xl">
                One upload, a perfectly clean cut-out
              </h2>
              <p className="mt-2 text-sm leading-6 text-ink-soft">
                The AI finds the subject — a person, a product, a pet — and separates it from the
                background while keeping fine edges like hair and fabric intact.
              </p>
              <ul className="mt-4 space-y-2 text-sm text-ink-soft">
                {[
                  "Drag the slider to compare both versions",
                  "Swap in a colour, gradient or background photo",
                  "Resize, crop, add text, then export a real PNG",
                ].map((line) => (
                  <li key={line} className="flex items-start gap-2">
                    <Icon name="check" size={16} className="mt-0.5 shrink-0 text-emerald-600" />
                    {line}
                  </li>
                ))}
              </ul>
              <p className="mt-4 text-[11px] leading-5 text-ink-muted">
                Illustration example. Your own uploads are processed by the AI model in the same way.
              </p>
            </figcaption>
          </div>
        </figure>
      </div>
    </section>
  );
}
