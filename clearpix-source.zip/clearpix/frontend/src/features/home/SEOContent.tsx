import { Link } from "react-router-dom";
import { Icon } from "../../components/Icon";

export function SEOContent() {
  return (
    <section aria-labelledby="seo-content-heading" className="py-16 sm:py-20">
      <div className="container-page">
        <div className="mx-auto max-w-3xl">
          <span className="eyebrow">
            <Icon name="file" size={13} />
            Background removal guide
          </span>
          <h2
            id="seo-content-heading"
            className="mt-4 text-2xl font-extrabold tracking-tight text-ink sm:text-3xl"
          >
            Remove Image Backgrounds Online for Free
          </h2>

          <div className="prose-cp">
            <p>
              A background is often the thing standing between a good photo and a usable graphic.
              Product shots taken on a kitchen table, selfies with a cluttered room behind them, or
              team photos that need to sit on a branded slide all have the same problem: the subject
              is fine, the surroundings are in the way. Removing that background used to mean hours
              with a pen tool in professional editing software. Today an AI background remover can do
              it in seconds, and ClearPix lets you do it online for free.
            </p>

            <h3>What background removal actually means</h3>
            <p>
              Background removal is the process of separating the main subject of an image from
              everything else. The result is a cut-out: the subject stays exactly as it looked, while
              the rest of the frame becomes transparent. Because the transparency lives in the alpha
              channel of the file, the cut-out can be placed on any colour, gradient, photo or video
              without leaving a pale halo around the edges. That is why a transparent PNG is the
              standard format for logos, product images and layered design work.
            </p>

            <h3>How AI background removal works</h3>
            <p>
              Older tools looked for a single background colour and deleted pixels that matched it.
              That approach breaks down the moment a subject wears white on a white wall, or when the
              background is a busy street. ClearPix uses a segmentation model trained on a very large
              set of images to predict which pixels belong to the subject and which do not. The model
              produces a soft mask rather than a hard outline, which is what preserves details like
              hair, fur, thin straps and the slightly blurred edge of a moving hand.
            </p>
            <p>
              In practice you open an image, the AI model runs in your browser, and the mask is
              applied to your original pixels. Nothing is regenerated or painted in: the
              subject you see in the result is exactly the subject you photographed, only isolated.
            </p>

            <h3>How to remove a background from an image</h3>
            <ul>
              <li>Open the <a href="#tool">ClearPix background remover</a> at the top of this page.</li>
              <li>Drag your photo into the upload area, or click to browse your files.</li>
              <li>Wait a few seconds while the AI detects the subject and removes the background.</li>
              <li>Compare the original and the result, and preview it on different background colours.</li>
              <li>Download the transparent PNG and place it wherever you need it.</li>
            </ul>
            <p>
              There is no account to create, no watermark on the download and no limit hidden behind a
              paywall. If something goes wrong — a corrupted file, an unusually large photo, a dropped
              connection — ClearPix shows a clear message and lets you retry without starting over.
            </p>

            <h3>How to download transparent PNG images</h3>
            <p>
              When the processing finishes, the main download button saves a PNG with an alpha
              channel. Keep the file as a PNG: saving a transparent image as JPG flattens it onto a
              solid colour and the transparency is lost. If you do need a JPG for a marketplace that
              rejects transparent files, choose a background colour in the preview panel first and use
              the optional JPG export, which bakes that colour in deliberately.
            </p>

            <h3>Why e-commerce sellers rely on cut-outs</h3>
            <p>
              Marketplaces have strict image rules: pure white backgrounds, consistent framing, no
              distracting props. Reshooting every product is expensive, and editing each photo by hand
              does not scale. A product photo background remover lets a small seller turn a batch of
              ordinary photos into listings that look like they came from a studio. The same cut-outs
              can be reused for ads, category banners, email campaigns and printed flyers, so one
              upload pays for itself many times over.
            </p>

            <h3>How creators use transparent images</h3>
            <p>
              Creators layer cut-outs over thumbnails, carousels, stickers and video overlays. A
              transparent subject can be dropped onto a bright gradient for a YouTube thumbnail,
              repeated across an Instagram story, or turned into a sticker pack. Designers keep a
              small library of transparent subjects and recolour the background instead of re-editing
              the photo each time. Students and teachers use the same trick for presentations,
              posters and reports.
            </p>

            <h3>How to use ClearPix</h3>
            <p>
              ClearPix works in the browser on phones, tablets and computers, so there is nothing to
              install. For a single image, upload it and download the result. For a small batch,
              upload up to five images at once, watch their status in one list, retry any that fail,
              and download everything as a ZIP. Images are processed in temporary storage and removed
              as soon as processing finishes — you can read the details in our{" "}
              <Link to="/privacy-policy">privacy policy</Link>.
            </p>
            <p>
              If you would like a step-by-step walkthrough, see{" "}
              <Link to="/how-to-remove-background">how to remove a background from a photo</Link>. For
              specific workflows, read about{" "}
              <Link to="/product-photo-background-remover">removing backgrounds from product photos</Link>{" "}
              or try the <Link to="/transparent-png">transparent PNG maker</Link>.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
