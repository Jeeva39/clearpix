import { Link } from "react-router-dom";
import { Icon, type IconName } from "../../components/Icon";
import { SectionHeading } from "../../components/SectionHeading";
import { TOOL_CARDS } from "../../lib/site";

export function EditingTools() {
  return (
    <section id="tools" aria-labelledby="tools-heading" className="scroll-mt-20 bg-mist py-16 sm:py-20">
      <div className="container-page">
        <SectionHeading
          eyebrow="Editing tools"
          title="One editor, every tool you need"
          description="Each card opens the real workspace with that tool ready. No empty pages, no sign-up wall — upload once and keep editing."
          id="tools-heading"
        />

        <ul className="mt-12 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {TOOL_CARDS.map((tool) => (
            <li key={tool.slug}>
              <Link
                to={tool.href}
                className="group flex h-full flex-col rounded-xl2 border border-ink/[0.07] bg-white p-5 shadow-soft transition duration-200 hover:-translate-y-1 hover:border-brand-200 hover:shadow-card"
              >
                <div className="flex items-center justify-between">
                  <span className="grid h-10 w-10 place-items-center rounded-xl bg-brand-50 text-brand-600 transition group-hover:bg-brand-600 group-hover:text-white">
                    <Icon name={tool.icon as IconName} size={19} />
                  </span>
                  <span className="rounded-full bg-mist px-2 py-0.5 text-[10px] font-bold uppercase tracking-wide text-ink-muted">
                    {tool.badge}
                  </span>
                </div>
                <h3 className="mt-4 text-base font-bold text-ink">{tool.title}</h3>
                <p className="mt-1.5 flex-1 text-sm leading-6 text-ink-soft">{tool.description}</p>
                <span className="mt-4 inline-flex items-center gap-1.5 text-xs font-semibold text-brand-700">
                  Open tool
                  <Icon
                    name="arrow-right"
                    size={13}
                    className="transition group-hover:translate-x-0.5"
                  />
                </span>
              </Link>
            </li>
          ))}
        </ul>

        <p className="mt-8 text-center text-xs text-ink-muted">
          All tools are free and work without registration. Your images are never stored permanently.
        </p>
      </div>
    </section>
  );
}
