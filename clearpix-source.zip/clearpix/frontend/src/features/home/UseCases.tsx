import { Icon, type IconName } from "../../components/Icon";
import { SectionHeading } from "../../components/SectionHeading";

const USE_CASES: { icon: IconName; title: string; body: string }[] = [
  { icon: "camera", title: "E-commerce product photos", body: "Turn home-shot products into catalogue-ready images." },
  { icon: "store", title: "Amazon & marketplace listings", body: "Clean cut-outs that sit well on white listing backgrounds." },
  { icon: "instagram", title: "Instagram content", body: "Layer subjects over bold graphics, gradients or brand colours." },
  { icon: "youtube", title: "YouTube thumbnails", body: "Cut yourself out and place the subject next to the headline." },
  { icon: "user", title: "Profile pictures", body: "Create avatars that work on any platform or background." },
  { icon: "id-card", title: "Passport-style photos", body: "Prepare a subject on a plain background for print workflows." },
  { icon: "megaphone", title: "Marketing materials", body: "Reuse one cut-out across ads, flyers and social posts." },
  { icon: "presentation", title: "Presentations", body: "Drop transparent subjects straight into slides." },
  { icon: "store", title: "Online stores", body: "Keep every product shot consistent across your shop." },
  { icon: "heart", title: "Personal projects", body: "Posters, invitations, collages and whatever you dream up." },
];

export function UseCases() {
  return (
    <section aria-labelledby="use-cases-heading" className="border-y border-ink/[0.06] bg-mist py-16 sm:py-20">
      <div className="container-page">
        <SectionHeading
          eyebrow="Use cases"
          title="Built for sellers, creators and everyday projects"
          description="A transparent background is the starting point for almost any image work. Here is what people use ClearPix for most."
          id="use-cases-heading"
        />

        <ul className="mt-12 grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
          {USE_CASES.map((useCase, index) => (
            <li
              key={`${useCase.title}-${index}`}
              className="flex gap-3 rounded-xl2 border border-ink/[0.06] bg-white p-4 transition duration-300 hover:-translate-y-1 hover:border-brand-200 hover:shadow-soft"
            >
              <span className="grid h-9 w-9 shrink-0 place-items-center rounded-lg bg-brand-50 text-brand-600">
                <Icon name={useCase.icon} size={17} />
              </span>
              <div>
                <h3 className="text-sm font-bold leading-5 text-ink">{useCase.title}</h3>
                <p className="mt-1 text-xs leading-5 text-ink-muted">{useCase.body}</p>
              </div>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}
