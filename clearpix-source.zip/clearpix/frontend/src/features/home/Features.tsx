import { Icon, type IconName } from "../../components/Icon";
import { SectionHeading } from "../../components/SectionHeading";

const FEATURES: { icon: IconName; title: string; body: string }[] = [
  {
    icon: "wand",
    title: "AI Background Removal",
    body: "Remove image backgrounds automatically using AI-powered image segmentation.",
  },
  {
    icon: "layers",
    title: "Transparent PNG",
    body: "Download images with a transparent background that drops cleanly into any design.",
  },
  {
    icon: "check",
    title: "Free to Use",
    body: "Use the background remover without paying, without credits and without a trial.",
  },
  {
    icon: "user-off",
    title: "No Account Required",
    body: "Start removing backgrounds immediately — there is nothing to sign up for.",
  },
  {
    icon: "grid",
    title: "Batch Image Processing",
    body: "Remove backgrounds from up to five images in one go and download them together as a ZIP.",
  },
  {
    icon: "zap",
    title: "Fast Processing",
    body: "Process images quickly using an optimized image-processing workflow.",
  },
  {
    icon: "shield",
    title: "Privacy Friendly",
    body: "Images are processed securely and temporary files are deleted after processing.",
  },
  {
    icon: "palette",
    title: "Easy to Use",
    body: "No advanced photo-editing skills required — upload, preview and download.",
  },
];

export function Features() {
  return (
    <section id="features" aria-labelledby="features-heading" className="scroll-mt-20 py-16 sm:py-20">
      <div className="container-page">
        <SectionHeading
          eyebrow="Features"
          title="Everything you need from a background remover"
          description="ClearPix focuses on one job and does it well: clean, transparent cut-outs with a workflow that stays out of your way."
          id="features-heading"
        />

        <ul className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {FEATURES.map((feature) => (
            <li
              key={feature.title}
              className="group rounded-xl2 border border-ink/[0.07] bg-white p-5 shadow-soft transition duration-300 hover:-translate-y-1 hover:border-brand-200 hover:shadow-card"
            >
              <span className="grid h-10 w-10 place-items-center rounded-xl bg-brand-50 text-brand-600 transition group-hover:bg-brand-600 group-hover:text-white">
                <Icon name={feature.icon} size={19} />
              </span>
              <h3 className="mt-4 text-base font-bold text-ink">{feature.title}</h3>
              <p className="mt-1.5 text-sm leading-6 text-ink-soft">{feature.body}</p>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}
