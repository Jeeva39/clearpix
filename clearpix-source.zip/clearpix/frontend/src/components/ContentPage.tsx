import type { ReactNode } from "react";
import { Link } from "react-router-dom";
import { Breadcrumbs } from "./Breadcrumbs";
import { Icon } from "./Icon";
import { ToolCta } from "./ToolCta";

type ContentPageProps = {
  breadcrumbs: { name: string; path: string }[];
  title: string;
  intro: ReactNode;
  children: ReactNode;
  related?: { label: string; href: string }[];
  showCta?: boolean;
};

export function ContentPage({
  breadcrumbs,
  title,
  intro,
  children,
  related,
  showCta = true,
}: ContentPageProps) {
  return (
    <>
      <section className="border-b border-ink/[0.06] bg-mist">
        <div className="container-page py-10 sm:py-14">
          <Breadcrumbs items={breadcrumbs} />
          <h1 className="mt-4 max-w-3xl text-3xl font-extrabold leading-tight tracking-tight text-ink sm:text-4xl">
            {title}
          </h1>
          <div className="mt-4 max-w-2xl text-base leading-7 text-ink-soft">{intro}</div>
        </div>
      </section>

      <section className="py-12 sm:py-16">
        <div className="container-page">
          <div className="mx-auto max-w-3xl">
            <div className="prose-cp [&>h2:first-child]:mt-0">{children}</div>
            {showCta && <ToolCta />}

            {related && related.length > 0 && (
              <nav aria-label="Related pages" className="mt-10 border-t border-ink/[0.07] pt-6">
                <h2 className="text-sm font-bold uppercase tracking-[0.12em] text-ink-muted">
                  Related reading
                </h2>
                <ul className="mt-3 grid gap-2 sm:grid-cols-2">
                  {related.map((link) => (
                    <li key={link.href}>
                      <Link
                        to={link.href}
                        className="flex items-center justify-between gap-2 rounded-lg border border-ink/[0.07] px-3.5 py-2.5 text-sm font-medium text-ink-soft transition hover:border-brand-300 hover:bg-brand-50/60 hover:text-brand-700"
                      >
                        {link.label}
                        <Icon name="arrow-right" size={14} />
                      </Link>
                    </li>
                  ))}
                </ul>
              </nav>
            )}
          </div>
        </div>
      </section>
    </>
  );
}
