import { Link } from "react-router-dom";
import { Icon } from "./Icon";

export function Breadcrumbs({ items }: { items: { name: string; path: string }[] }) {
  return (
    <nav aria-label="Breadcrumb" className="text-xs text-ink-muted">
      <ol className="flex flex-wrap items-center gap-1.5">
        {items.map((item, index) => {
          const isLast = index === items.length - 1;
          return (
            <li key={item.path} className="flex items-center gap-1.5">
              {isLast ? (
                <span aria-current="page" className="font-semibold text-ink-soft">
                  {item.name}
                </span>
              ) : (
                <>
                  <Link to={item.path} className="transition hover:text-brand-700">
                    {item.name}
                  </Link>
                  <Icon name="chevron-right" size={12} aria-hidden="true" />
                </>
              )}
            </li>
          );
        })}
      </ol>
    </nav>
  );
}
