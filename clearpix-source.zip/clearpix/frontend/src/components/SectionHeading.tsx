import type { ReactNode } from "react";

type SectionHeadingProps = {
  eyebrow?: string;
  title: string;
  description?: ReactNode;
  align?: "center" | "left";
  as?: "h2" | "h3";
  id?: string;
};

export function SectionHeading({
  eyebrow,
  title,
  description,
  align = "center",
  as: Tag = "h2",
  id,
}: SectionHeadingProps) {
  return (
    <div className={align === "center" ? "mx-auto max-w-2xl text-center" : "max-w-2xl"}>
      {eyebrow && (
        <p className="text-xs font-bold uppercase tracking-[0.16em] text-brand-700">{eyebrow}</p>
      )}
      <Tag id={id} className="mt-3 text-2xl font-extrabold tracking-tight text-ink sm:text-3xl">
        {title}
      </Tag>
      {description && (
        <p className="mt-3 text-base leading-7 text-ink-soft">{description}</p>
      )}
    </div>
  );
}
