import { useId, useState } from "react";

type CompareSliderProps = {
  beforeSrc: string;
  afterSrc: string;
  beforeAlt: string;
  afterAlt: string;
  beforeLabel?: string;
  afterLabel?: string;
  className?: string;
};

export function CompareSlider({
  beforeSrc,
  afterSrc,
  beforeAlt,
  afterAlt,
  beforeLabel = "Original",
  afterLabel = "Background removed",
  className = "",
}: CompareSliderProps) {
  const [position, setPosition] = useState(55);
  const id = useId();

  return (
    <div className={`relative overflow-hidden rounded-xl2 bg-mist ${className}`}>
      <div className="relative select-none" style={{ touchAction: "pan-y" }}>
        <img
          src={beforeSrc}
          alt={beforeAlt}
          className="block h-full w-full object-contain"
          draggable={false}
        />
        <div className="absolute inset-0" style={{ clipPath: `inset(0 0 0 ${position}%)` }}>
          <div className="checkerboard h-full w-full">
            <img
              src={afterSrc}
              alt={afterAlt}
              className="h-full w-full object-contain"
              draggable={false}
            />
          </div>
        </div>

        <div
          className="pointer-events-none absolute inset-y-0 w-0.5 bg-white shadow-[0_0_0_1px_rgba(28,28,40,0.15)]"
          style={{ left: `${position}%` }}
          aria-hidden="true"
        >
          <span className="absolute left-1/2 top-1/2 grid h-10 w-10 -translate-x-1/2 -translate-y-1/2 place-items-center rounded-full border border-white/70 bg-white text-ink shadow-card">
            <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="m9 7-5 5 5 5" />
              <path d="m15 7 5 5-5 5" />
            </svg>
          </span>
        </div>

        <span className="pointer-events-none absolute left-3 top-3 rounded-full bg-ink/75 px-2.5 py-1 text-[11px] font-semibold text-white backdrop-blur">
          {beforeLabel}
        </span>
        <span className="pointer-events-none absolute right-3 top-3 rounded-full bg-brand-600/90 px-2.5 py-1 text-[11px] font-semibold text-white backdrop-blur">
          {afterLabel}
        </span>

        <label htmlFor={id} className="sr-only">
          Comparison slider: drag to reveal the original image or the background-removed result
        </label>
        <input
          id={id}
          type="range"
          min={0}
          max={100}
          value={position}
          onChange={(event) => setPosition(Number(event.target.value))}
          aria-valuetext={`${Math.round(position)}% of the original image visible`}
          className="absolute inset-0 h-full w-full cursor-ew-resize opacity-0"
        />
      </div>

    </div>
  );
}
