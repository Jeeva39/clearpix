import { useEffect, useRef } from "react";
import { SITE } from "../lib/site";

declare global {
  interface Window {
    adsbygoogle?: unknown[];
  }
}

/**
 * Reserved advertising area. Nothing renders unless VITE_ADSENSE_CLIENT is set,
 * so the site never shows placeholder or fake ads. Placements are chosen so that
 * ads never sit inside the upload, processing or download flow.
 */
export function AdSlot({ className = "", label = "Advertisement" }: { className?: string; label?: string }) {
  const ref = useRef<HTMLModElement>(null);
  const client = SITE.adsenseClient;

  useEffect(() => {
    if (!client || !ref.current) return;
    try {
      window.adsbygoogle = window.adsbygoogle ?? [];
      window.adsbygoogle.push({});
    } catch {
      /* AdSense can only initialise once per slot */
    }
  }, [client]);

  if (!client) return null;

  return (
    <aside aria-label={label} className={`container-page py-6 ${className}`}>
      <ins
        ref={ref}
        className="adsbygoogle block"
        style={{ display: "block" }}
        data-ad-client={client}
        data-ad-format="auto"
        data-full-width-responsive="true"
      />
    </aside>
  );
}
