import { Link } from "react-router-dom";
import { Icon } from "./Icon";

export function ToolCta({
  title = "Open the ClearPix editor",
  description = "Remove the background, swap it for a colour or scene, then resize, crop and export — free, without an account.",
  buttonLabel = "Start editing",
  href = "/editor",
}: {
  title?: string;
  description?: string;
  buttonLabel?: string;
  href?: string;
}) {
  return (
    <div className="not-prose mt-10 overflow-hidden rounded-xl2 border border-brand-100 bg-gradient-to-br from-brand-50 via-white to-white p-6 shadow-soft sm:p-8">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-lg font-bold text-ink sm:text-xl">{title}</h2>
          <p className="mt-1 text-sm leading-6 text-ink-soft">{description}</p>
        </div>
        <Link to={href} className="btn-primary shrink-0">
          <Icon name="sparkles" size={17} />
          {buttonLabel}
        </Link>
      </div>
    </div>
  );
}
