import { Link } from "react-router-dom";
import { Icon, Logo } from "./Icon";
import { FOOTER_COMPANY_LINKS, FOOTER_TOOL_LINKS } from "../lib/site";

export function Footer() {
  return (
    <footer className="border-t border-ink/[0.07] bg-mist">
      <div className="container-page py-14">
        <div className="grid gap-10 md:grid-cols-2 lg:grid-cols-4">
          <div className="lg:col-span-2 lg:max-w-sm">
            <Link to="/" aria-label="ClearPix home" className="inline-block rounded-lg">
              <Logo />
            </Link>
            <p className="mt-4 text-sm leading-6 text-ink-muted">
              ClearPix is a free AI background remover. Upload a photo, let AI separate the subject,
              and download a clean transparent PNG in seconds — no account needed.
            </p>
            <p className="mt-5 inline-flex items-center gap-2 rounded-full border border-ink/[0.07] bg-white px-3 py-1.5 text-xs font-medium text-ink-soft">
              <Icon name="shield" size={14} className="text-brand-600" />
              Images are processed temporarily and deleted
            </p>
          </div>

          <nav aria-label="Footer tools">
            <h2 className="text-xs font-bold uppercase tracking-[0.14em] text-ink-muted">Tools</h2>
            <ul className="mt-4 space-y-2.5">
              {FOOTER_TOOL_LINKS.map((link) => (
                <li key={link.href}>
                  <Link to={link.href} className="text-sm text-ink-soft transition hover:text-brand-700">
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </nav>

          <nav aria-label="Footer company">
            <h2 className="text-xs font-bold uppercase tracking-[0.14em] text-ink-muted">Company</h2>
            <ul className="mt-4 space-y-2.5">
              {FOOTER_COMPANY_LINKS.map((link) => (
                <li key={link.href}>
                  <Link to={link.href} className="text-sm text-ink-soft transition hover:text-brand-700">
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </nav>
        </div>

        <div className="mt-12 flex flex-col gap-3 border-t border-ink/[0.07] pt-6 text-xs text-ink-muted sm:flex-row sm:items-center sm:justify-between">
          <p>© 2026 ClearPix. All rights reserved.</p>
          <p className="inline-flex items-center gap-1.5">
            <Icon name="globe" size={14} />
            Free background remover · Transparent PNG maker
          </p>
        </div>
      </div>
    </footer>
  );
}
