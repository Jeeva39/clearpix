import { useEffect, useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { Icon, Logo } from "./Icon";
import { NAV_LINKS } from "../lib/site";

export function Header() {
  const [open, setOpen] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();

  useEffect(() => {
    setOpen(false);
  }, [location.pathname, location.hash]);

  useEffect(() => {
    if (!open) return;
    const previous = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") setOpen(false);
    };
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = previous;
      window.removeEventListener("keydown", onKey);
    };
  }, [open]);

  const goToTool = () => {
    setOpen(false);
    if (location.pathname === "/") {
      document.getElementById("tool")?.scrollIntoView({ behavior: "smooth", block: "start" });
    } else {
      navigate("/#tool");
    }
  };

  return (
    <header className="sticky top-0 z-50 border-b border-ink/[0.06] bg-white/85 backdrop-blur-md">
      <div className="container-page flex h-16 items-center justify-between gap-4">
        <Link to="/" aria-label="ClearPix home" className="rounded-lg">
          <Logo />
        </Link>

        <nav aria-label="Main navigation" className="hidden items-center gap-1 lg:flex">
          {NAV_LINKS.map((link) => (
            <Link
              key={link.href}
              to={link.href}
              className="rounded-full px-3.5 py-2 text-sm font-medium text-ink-soft transition hover:bg-mist hover:text-ink"
            >
              {link.label}
            </Link>
          ))}
          <Link
            to="/how-to-remove-background"
            className="rounded-full px-3.5 py-2 text-sm font-medium text-ink-soft transition hover:bg-mist hover:text-ink"
          >
            Guide
          </Link>
        </nav>

        <div className="flex items-center gap-2">
          <button type="button" onClick={goToTool} className="btn-primary hidden px-4 py-2.5 sm:inline-flex">
            <Icon name="upload" size={16} />
            Upload Image
          </button>
          <button
            type="button"
            className="grid h-10 w-10 place-items-center rounded-xl border border-ink/10 text-ink transition hover:bg-mist lg:hidden"
            aria-expanded={open}
            aria-controls="mobile-menu"
            aria-label={open ? "Close menu" : "Open menu"}
            onClick={() => setOpen((value) => !value)}
          >
            <Icon name={open ? "close" : "menu"} size={20} />
          </button>
        </div>
      </div>

      {open && (
        <div className="lg:hidden">
          <div
            id="mobile-menu"
            className="border-t border-ink/[0.06] bg-white px-5 pb-5 pt-2 shadow-soft"
          >
            <nav aria-label="Mobile navigation" className="flex flex-col">
              {[...NAV_LINKS, { label: "Guide", href: "/how-to-remove-background" }].map((link) => (
                <Link
                  key={link.href}
                  to={link.href}
                  className="rounded-lg px-2 py-3 text-base font-medium text-ink-soft transition hover:bg-mist hover:text-ink"
                >
                  {link.label}
                </Link>
              ))}
              <button type="button" onClick={goToTool} className="btn-primary mt-3 w-full">
                <Icon name="upload" size={16} />
                Upload Image
              </button>
            </nav>
          </div>
        </div>
      )}
    </header>
  );
}
