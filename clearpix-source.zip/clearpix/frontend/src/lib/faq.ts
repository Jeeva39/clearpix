export type FaqItem = { question: string; answer: string };

export const FAQ_ITEMS: FaqItem[] = [
  {
    question: "Is ClearPix free to use?",
    answer:
      "Yes. ClearPix allows users to remove image backgrounds for free without creating an account.",
  },
  {
    question: "How do I remove a background from an image?",
    answer:
      "Upload your image, allow AI to process it, and download the transparent PNG. The whole process usually takes a few seconds.",
  },
  {
    question: "Does ClearPix support transparent PNG images?",
    answer:
      "Yes. Download your processed image as a PNG with a transparent background. PNG is the format that keeps transparency intact.",
  },
  {
    question: "Which image formats are supported?",
    answer:
      "JPG, JPEG, PNG, and WEBP are supported for uploading, with a maximum file size of 10 MB per image.",
  },
  {
    question: "Do I need to create an account?",
    answer: "No. You can use the background remover without registration.",
  },
  {
    question: "Is my uploaded image stored?",
    answer:
      "Uploaded images are processed temporarily. Temporary files are deleted immediately after processing, and images are not retained.",
  },
  {
    question: "Can I remove the background from product photos?",
    answer:
      "Yes. ClearPix can help remove backgrounds from product images for online stores, catalogs, and marketing.",
  },
  {
    question: "Can I use ClearPix on mobile?",
    answer:
      "Yes. The website is responsive and works on smartphones, tablets, and computers.",
  },
  {
    question: "Can I process multiple images?",
    answer:
      "Yes. Batch processing supports multiple uploads within the supported limit of five images at a time.",
  },
  {
    question: "Can I download my image in JPG?",
    answer:
      "Transparent backgrounds require PNG. If you choose a background colour in the editor, you can also export a flattened JPG.",
  },
];
