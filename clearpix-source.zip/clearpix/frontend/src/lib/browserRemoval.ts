/**
 * In-browser background removal.
 *
 * The AI model runs on the visitor's own machine, so the site needs no API
 * server, no CORS configuration and has no cold starts. The heavy work happens
 * in `browserRemoval.worker.ts`; this module handles decoding, the tensor the
 * model expects, and compositing the returned alpha mask back onto the image.
 */

const MODEL_URL = "/models/u2netp.onnx";
const MODEL_SIZE = 320;
const MEAN = [0.485, 0.456, 0.406];
const STD = [0.229, 0.224, 0.225];

export const BROWSER_MODEL_LABEL = "U²-Net (in your browser)";

export type BrowserRemoveOptions = {
  mode?: "general" | "portrait";
  alphaMatting?: boolean;
  onUploadProgress?: (percent: number) => void;
  signal?: AbortSignal;
};

type WorkerReply =
  | { type: "model-progress"; loaded: number; total: number }
  | { type: "ready" }
  | { type: "error"; message: string }
  | { type: "result"; id: number; mask: Float32Array }
  | { type: "run-error"; id: number; message: string };

let worker: Worker | null = null;
let readyPromise: Promise<void> | null = null;
let progressSink: ((percent: number) => void) | null = null;
let requestId = 0;
const pending = new Map<
  number,
  { resolve: (mask: Float32Array) => void; reject: (error: Error) => void }
>();
let rejectReady: ((error: Error) => void) | null = null;

function handleMessage(event: MessageEvent<WorkerReply>) {
  const message = event.data;

  if (message.type === "model-progress") {
    if (progressSink && message.total > 0) {
      progressSink(Math.min(85, Math.round((message.loaded / message.total) * 85)));
    }
    return;
  }

  if (message.type === "error") {
    rejectReady?.(new Error(message.message));
    rejectReady = null;
    readyPromise = null;
    return;
  }

  if (message.type === "result") {
    pending.get(message.id)?.resolve(message.mask);
    pending.delete(message.id);
    return;
  }

  if (message.type === "run-error") {
    pending.get(message.id)?.reject(new Error(message.message));
    pending.delete(message.id);
  }
}

function ensureWorker(): Promise<void> {
  if (readyPromise) return readyPromise;

  if (!worker) {
    worker = new Worker(new URL("./browserRemoval.worker.ts", import.meta.url), {
      type: "module",
      name: "clearpix-removal",
    });
    worker.onmessage = handleMessage;
    worker.onerror = (event) => {
      const error = new Error(
        event.message || "The AI model could not start in this browser. Please try again.",
      );
      rejectReady?.(error);
      rejectReady = null;
      readyPromise = null;
      pending.forEach(({ reject }) => reject(error));
      pending.clear();
    };
  }

  readyPromise = new Promise<void>((resolve, reject) => {
    rejectReady = reject;
    const settle = (event: MessageEvent<WorkerReply>) => {
      if (event.data.type === "ready") {
        worker?.removeEventListener("message", settle);
        rejectReady = null;
        resolve();
      }
    };
    worker?.addEventListener("message", settle);
  });

  worker.postMessage({ type: "init", modelUrl: MODEL_URL });
  return readyPromise;
}

function throwIfAborted(signal?: AbortSignal) {
  if (signal?.aborted) {
    throw new DOMException("Processing was cancelled.", "AbortError");
  }
}

async function decodeImage(file: Blob): Promise<ImageBitmap | HTMLImageElement> {
  if (typeof createImageBitmap === "function") {
    try {
      return await createImageBitmap(file, { imageOrientation: "from-image" });
    } catch {
      /* fall through to the <img> decoder */
    }
  }

  const url = URL.createObjectURL(file);
  try {
    return await new Promise<HTMLImageElement>((resolve, reject) => {
      const image = new Image();
      image.onload = () => resolve(image);
      image.onerror = () => reject(new Error("That image could not be read. Please try another file."));
      image.src = url;
    });
  } finally {
    window.setTimeout(() => URL.revokeObjectURL(url), 30_000);
  }
}

function buildTensor(context: CanvasRenderingContext2D): Float32Array {
  const { data } = context.getImageData(0, 0, MODEL_SIZE, MODEL_SIZE);
  let max = 1;
  for (let i = 0; i < data.length; i += 4) {
    if (data[i] > max) max = data[i];
    if (data[i + 1] > max) max = data[i + 1];
    if (data[i + 2] > max) max = data[i + 2];
  }

  const plane = MODEL_SIZE * MODEL_SIZE;
  const tensor = new Float32Array(plane * 3);
  for (let i = 0, p = 0; i < data.length; i += 4, p += 1) {
    tensor[p] = (data[i] / max - MEAN[0]) / STD[0];
    tensor[plane + p] = (data[i + 1] / max - MEAN[1]) / STD[1];
    tensor[plane * 2 + p] = (data[i + 2] / max - MEAN[2]) / STD[2];
  }
  return tensor;
}

function maskCanvas(mask: Float32Array): HTMLCanvasElement {
  const canvas = document.createElement("canvas");
  canvas.width = MODEL_SIZE;
  canvas.height = MODEL_SIZE;
  const context = canvas.getContext("2d");
  if (!context) throw new Error("This browser could not prepare the cut-out. Please try again.");

  const image = context.createImageData(MODEL_SIZE, MODEL_SIZE);
  for (let i = 0; i < mask.length; i += 1) {
    const alpha = Math.max(0, Math.min(255, Math.round(mask[i] * 255)));
    image.data[i * 4 + 3] = alpha;
  }
  context.putImageData(image, 0, 0);
  return canvas;
}

async function toPng(bitmap: CanvasImageSource, mask: Float32Array, width: number, height: number) {
  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = height;
  const context = canvas.getContext("2d");
  if (!context) throw new Error("This browser could not prepare the cut-out. Please try again.");

  context.imageSmoothingEnabled = true;
  context.imageSmoothingQuality = "high";
  context.drawImage(bitmap, 0, 0, width, height);
  context.globalCompositeOperation = "destination-in";
  context.drawImage(maskCanvas(mask), 0, 0, width, height);
  context.globalCompositeOperation = "source-over";

  const blob = await new Promise<Blob | null>((resolve) => canvas.toBlob(resolve, "image/png"));
  if (!blob) throw new Error("The cut-out could not be saved. Please try another image.");
  return blob;
}

export async function removeBackgroundInBrowser(
  file: File,
  options: BrowserRemoveOptions = {},
): Promise<Blob> {
  const { signal, onUploadProgress } = options;
  throwIfAborted(signal);

  if (!("WebAssembly" in window)) {
    throw new Error(
      "This browser cannot run the AI model. Please use a recent version of Chrome, Edge, Firefox or Safari.",
    );
  }

  progressSink = onUploadProgress ?? null;
  onUploadProgress?.(0);

  try {
    await ensureWorker();
    throwIfAborted(signal);
    onUploadProgress?.(88);

    const bitmap = await decodeImage(file);
    const width = "naturalWidth" in bitmap ? bitmap.naturalWidth : bitmap.width;
    const height = "naturalHeight" in bitmap ? bitmap.naturalHeight : bitmap.height;
    if (!width || !height) throw new Error("That image could not be read. Please try another file.");

    const input = document.createElement("canvas");
    input.width = MODEL_SIZE;
    input.height = MODEL_SIZE;
    const inputContext = input.getContext("2d", { willReadFrequently: true });
    if (!inputContext) throw new Error("This browser could not prepare the image for the AI model.");
    inputContext.imageSmoothingEnabled = true;
    inputContext.imageSmoothingQuality = "high";
    inputContext.drawImage(bitmap, 0, 0, MODEL_SIZE, MODEL_SIZE);

    const tensor = buildTensor(inputContext);
    throwIfAborted(signal);
    onUploadProgress?.(94);

    requestId += 1;
    const id = requestId;
    const mask = await new Promise<Float32Array>((resolve, reject) => {
      pending.set(id, { resolve, reject });
      worker?.postMessage({ type: "run", id, tensor }, [tensor.buffer]);
      signal?.addEventListener(
        "abort",
        () => {
          pending.delete(id);
          reject(new DOMException("Processing was cancelled.", "AbortError"));
        },
        { once: true },
      );
    });

    throwIfAborted(signal);
    const png = await toPng(bitmap, mask, width, height);
    onUploadProgress?.(100);
    if ("close" in bitmap) bitmap.close();
    return png;
  } finally {
    progressSink = null;
  }
}
