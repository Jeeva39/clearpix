/**
 * Background-removal worker.
 *
 * Runs the U²-Net (lightweight `u2netp`) ONNX model with onnxruntime-web's WASM
 * backend, entirely inside the visitor's browser. Keeping it in a worker means
 * the page stays responsive while the model loads and the network runs.
 */
import * as ort from "onnxruntime-web/wasm";

const INPUT_SIZE = 320;

type Incoming =
  | { type: "init"; modelUrl: string }
  | { type: "run"; id: number; tensor: Float32Array };

const ctx = self as unknown as {
  postMessage: (message: unknown, transfer?: Transferable[]) => void;
  onmessage: ((event: MessageEvent<Incoming>) => void) | null;
};

let sessionPromise: Promise<ort.InferenceSession> | null = null;

// Leave `wasmPaths` unset: the bundler rewrites the runtime URL, so the WASM
// binary is served from our own origin in both development and production.
// Single-threaded: no SharedArrayBuffer, so no cross-origin isolation headers
// are needed and the site works on any static host.
ort.env.wasm.numThreads = 1;

async function fetchModel(url: string): Promise<Uint8Array> {
  const response = await fetch(url, { cache: "force-cache" });
  if (!response.ok) {
    throw new Error("The AI model could not be downloaded. Check your connection and try again.");
  }

  const total = Number(response.headers.get("content-length") ?? 0);
  if (!response.body) {
    return new Uint8Array(await response.arrayBuffer());
  }

  const reader = response.body.getReader();
  const chunks: Uint8Array[] = [];
  let loaded = 0;
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    if (value) {
      chunks.push(value);
      loaded += value.byteLength;
      ctx.postMessage({ type: "model-progress", loaded, total });
    }
  }

  const bytes = new Uint8Array(loaded);
  let offset = 0;
  for (const chunk of chunks) {
    bytes.set(chunk, offset);
    offset += chunk.byteLength;
  }
  return bytes;
}

function loadSession(modelUrl: string): Promise<ort.InferenceSession> {
  if (!sessionPromise) {
    sessionPromise = (async () => {
      const model = await fetchModel(modelUrl);
      return ort.InferenceSession.create(model, {
        executionProviders: ["wasm"],
        graphOptimizationLevel: "all",
      });
    })().catch((error) => {
      sessionPromise = null;
      throw error;
    });
  }
  return sessionPromise;
}

/** Min/max normalise the raw logits into a 0..1 alpha mask. */
function normaliseMask(raw: Float32Array): Float32Array {
  let min = Infinity;
  let max = -Infinity;
  for (let i = 0; i < raw.length; i += 1) {
    const value = raw[i];
    if (value < min) min = value;
    if (value > max) max = value;
  }
  const range = max - min || 1;
  const mask = new Float32Array(raw.length);
  for (let i = 0; i < raw.length; i += 1) {
    mask[i] = (raw[i] - min) / range;
  }
  return mask;
}

ctx.onmessage = async (event: MessageEvent<Incoming>) => {
  const message = event.data;

  if (message.type === "init") {
    try {
      await loadSession(message.modelUrl);
      ctx.postMessage({ type: "ready" });
    } catch (error) {
      ctx.postMessage({
        type: "error",
        message:
          error instanceof Error
            ? error.message
            : "The AI model could not be loaded in this browser.",
      });
    }
    return;
  }

  if (message.type === "run") {
    try {
      const session = await loadSession("/models/u2netp.onnx");
      const inputName = session.inputNames[0];
      const outputName = session.outputNames[0];
      const tensor = new ort.Tensor("float32", message.tensor, [1, 3, INPUT_SIZE, INPUT_SIZE]);
      const outputs = await session.run({ [inputName]: tensor });
      const raw = outputs[outputName].data as Float32Array;
      const mask = normaliseMask(raw);
      ctx.postMessage({ type: "result", id: message.id, mask }, [mask.buffer]);
    } catch (error) {
      ctx.postMessage({
        type: "run-error",
        id: message.id,
        message:
          error instanceof Error ? error.message : "The AI model failed to process this image.",
      });
    }
  }
};
