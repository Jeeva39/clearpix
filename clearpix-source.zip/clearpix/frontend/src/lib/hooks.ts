import { useCallback, useEffect, useRef, useState } from "react";
import { checkHealth, type HealthInfo } from "./api";

export type BackendStatus = "checking" | "online" | "offline";

export function useBackendStatus(autoCheck = true) {
  const [status, setStatus] = useState<BackendStatus>(autoCheck ? "checking" : "offline");
  const [info, setInfo] = useState<HealthInfo | null>(null);
  const mounted = useRef(true);

  const refresh = useCallback(async () => {
    setStatus("checking");
    const result = await checkHealth();
    if (!mounted.current) return;
    setInfo(result);
    setStatus(result ? "online" : "offline");
  }, []);

  useEffect(() => {
    mounted.current = true;
    if (autoCheck) void refresh();
    return () => {
      mounted.current = false;
    };
  }, [autoCheck, refresh]);

  return { status, info, refresh };
}

const IMAGE_PASTE_TYPES = ["image/png", "image/jpeg", "image/webp"];

/**
 * Paste-to-upload: listens for clipboard images on the whole document so a
 * screenshot can go straight into the tool with Ctrl/Cmd+V.
 */
export function usePasteImages(onFiles: (files: File[]) => void, enabled = true) {
  const handler = useRef(onFiles);
  handler.current = onFiles;

  useEffect(() => {
    if (!enabled) return;
    const onPaste = (event: ClipboardEvent) => {
      const items = event.clipboardData?.items;
      if (!items) return;
      const files: File[] = [];
      for (const item of Array.from(items)) {
        if (item.kind !== "file") continue;
        if (!IMAGE_PASTE_TYPES.includes(item.type)) continue;
        const file = item.getAsFile();
        if (file) {
          const extension = file.type.split("/")[1] ?? "png";
          files.push(
            new File([file], file.name && file.name !== "image.png" ? file.name : `pasted-image.${extension}`, {
              type: file.type,
            }),
          );
        }
      }
      if (files.length > 0) {
        event.preventDefault();
        handler.current(files);
      }
    };
    document.addEventListener("paste", onPaste);
    return () => document.removeEventListener("paste", onPaste);
  }, [enabled]);
}

export function useFullscreen(target: React.RefObject<HTMLElement>) {
  const [isFullscreen, setIsFullscreen] = useState(false);

  useEffect(() => {
    const onChange = () => setIsFullscreen(document.fullscreenElement === target.current);
    document.addEventListener("fullscreenchange", onChange);
    return () => document.removeEventListener("fullscreenchange", onChange);
  }, [target]);

  const toggle = useCallback(async () => {
    try {
      if (document.fullscreenElement) {
        await document.exitFullscreen();
      } else if (target.current?.requestFullscreen) {
        await target.current.requestFullscreen();
      }
    } catch {
      /* browsers can refuse fullscreen without a gesture; ignore */
    }
  }, [target]);

  return { isFullscreen, toggle };
}
