import {
  ACCEPTED_EXTENSIONS,
  ACCEPTED_MIME,
  BLOCKED_EXTENSIONS,
  BLOCKED_MIME,
  MAX_FILE_SIZE,
  MAX_FILE_SIZE_LABEL,
  MAX_IMAGE_DIMENSION,
  MAX_IMAGE_PIXELS,
  SITE,
} from "./site";
import { BROWSER_MODEL_LABEL, removeBackgroundInBrowser } from "./browserRemoval";
import { createZipBlob } from "./zip";

/**
 * Background removal runs in the visitor's browser unless a separate API host
 * is configured with `VITE_API_BASE_URL`. Same-origin `/api` routes only exist
 * in local development (the Vite proxy), so a static build defaults to the
 * in-browser model rather than calling an endpoint that is not there.
 */
export const REMOVAL_ENGINE: "browser" | "server" = SITE.apiBase ? "server" : "browser";

export type RemoveOptions = {
  mode?: "general" | "portrait";
  alphaMatting?: boolean;
  onUploadProgress?: (percent: number) => void;
  signal?: AbortSignal;
};

export class ApiError extends Error {
  code: string;
  status: number;
  retryable: boolean;

  constructor(message: string, code = "unknown", status = 0, retryable = true) {
    super(message);
    this.name = "ApiError";
    this.code = code;
    this.status = status;
    this.retryable = retryable;
  }
}

export type ImageFileInfo = {
  width: number;
  height: number;
  size: number;
  name: string;
  type: string;
};

export function apiOriginLabel(): string {
  if (!SITE.apiBase) return "this site's /api route";
  try {
    return new URL(SITE.apiBase).host;
  } catch {
    return SITE.apiBase;
  }
}

function endpoint(path: string): string {
  return `${SITE.apiBase}${path}`;
}

export function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(0)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

export function loadImageDimensions(file: Blob): Promise<{ width: number; height: number }> {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const image = new Image();
    image.onload = () => {
      resolve({ width: image.naturalWidth, height: image.naturalHeight });
      URL.revokeObjectURL(url);
    };
    image.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new Error("Unable to read image dimensions"));
    };
    image.src = url;
  });
}

export function loadImageElement(source: Blob | string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const url = typeof source === "string" ? source : URL.createObjectURL(source);
    const image = new Image();
    image.decoding = "async";
    image.onload = () => {
      if (typeof source !== "string") {
        window.setTimeout(() => URL.revokeObjectURL(url), 0);
      }
      resolve(image);
    };
    image.onerror = () => {
      if (typeof source !== "string") URL.revokeObjectURL(url);
      reject(new Error("Unable to decode this image"));
    };
    image.src = url;
  });
}

/**
 * Validate a candidate upload by actually decoding it. The browser's reported
 * MIME type and the file extension are hints only: some systems hand over valid
 * JPEGs with an empty type or a wrong extension, and rejecting those was one of
 * the reasons uploads failed before processing even started.
 */
export async function validateImageFile(file: File): Promise<ImageFileInfo> {
  const name = file.name || "image";
  const extensionIndex = name.lastIndexOf(".");
  const extension = extensionIndex >= 0 ? name.slice(extensionIndex).toLowerCase() : "";
  const mime = (file.type || "").toLowerCase();

  if (!file.size) {
    throw new ApiError("That file looks empty. Please choose another image.", "empty_file", 400);
  }

  if (file.size > MAX_FILE_SIZE) {
    throw new ApiError(
      `Your image is too large (${formatBytes(file.size)}). Please upload an image smaller than ${MAX_FILE_SIZE_LABEL}.`,
      "file_too_large",
      413,
      false,
    );
  }

  if (BLOCKED_MIME.includes(mime) || BLOCKED_EXTENSIONS.includes(extension)) {
    throw new ApiError(
      "That format is not supported. Please upload a JPG, JPEG, PNG, or WEBP image.",
      "unsupported_type",
      415,
      false,
    );
  }

  if (mime && !mime.startsWith("image/") && mime !== "application/octet-stream") {
    throw new ApiError(
      "That file is not an image. Please upload a JPG, JPEG, PNG, or WEBP image.",
      "unsupported_type",
      415,
      false,
    );
  }

  let dimensions: { width: number; height: number };
  try {
    dimensions = await loadImageDimensions(file);
  } catch {
    throw new ApiError(
      "That image could not be read. It may be corrupted or use an unsupported format. Please try another file.",
      "invalid_image",
      415,
      false,
    );
  }

  if (dimensions.width < 16 || dimensions.height < 16) {
    throw new ApiError(
      "That image is too small. Please use an image at least 16x16 pixels.",
      "image_too_small",
      422,
      false,
    );
  }

  if (
    dimensions.width > MAX_IMAGE_DIMENSION ||
    dimensions.height > MAX_IMAGE_DIMENSION ||
    dimensions.width * dimensions.height > MAX_IMAGE_PIXELS
  ) {
    throw new ApiError(
      `That image is too large to edit (${dimensions.width}x${dimensions.height}). Maximum dimensions are ${MAX_IMAGE_DIMENSION}x${MAX_IMAGE_DIMENSION} pixels.`,
      "image_dimensions_too_large",
      422,
      false,
    );
  }

  const resolvedType = ACCEPTED_MIME.includes(mime)
    ? mime
    : ACCEPTED_EXTENSIONS.includes(extension)
      ? extension === ".png"
        ? "image/png"
        : extension === ".webp"
          ? "image/webp"
          : "image/jpeg"
      : mime || "image/png";

  return { ...dimensions, size: file.size, name, type: resolvedType };
}

async function blobText(blob: Blob | null): Promise<string> {
  if (!blob) return "";
  try {
    return await blob.text();
  } catch {
    return "";
  }
}

async function parseError(xhr: XMLHttpRequest): Promise<ApiError> {
  if (xhr.status === 0) {
    return new ApiError(
      `We could not reach the ClearPix API at ${apiOriginLabel()}. The server may be offline, or your browser blocked the request. Check the connection and try again.`,
      "network_error",
      0,
    );
  }

  let message = "Something went wrong while processing your image. Please try again.";
  let code = "processing_failed";

  const contentType = xhr.getResponseHeader("content-type") ?? "";
  const raw = xhr.response instanceof Blob ? await blobText(xhr.response) : "";
  if (contentType.includes("application/json") && raw) {
    try {
      const parsed = JSON.parse(raw) as {
        error?: { code?: string; message?: string };
        detail?: string | { message?: string } | { msg?: string }[];
      };
      if (parsed.error?.message) {
        message = parsed.error.message;
        code = parsed.error.code ?? code;
      } else if (typeof parsed.detail === "string") {
        message = parsed.detail;
      } else if (Array.isArray(parsed.detail) && parsed.detail[0]?.msg) {
        message = parsed.detail[0].msg;
        code = "invalid_request";
      }
    } catch {
      /* keep default message */
    }
  } else if (xhr.status === 413) {
    message = `Your image is too large. Please upload an image smaller than ${MAX_FILE_SIZE_LABEL}.`;
    code = "file_too_large";
  } else if (xhr.status === 415) {
    message = "That image could not be read. Please upload a JPG, PNG or WEBP file.";
    code = "unsupported_type";
  } else if (xhr.status === 429) {
    message = "You have reached the request limit. Please wait a moment and try again.";
    code = "rate_limited";
  } else if (xhr.status === 503) {
    message = "Our servers are busy right now. Please try again in a few moments.";
    code = "server_busy";
  } else if (xhr.status === 504) {
    message = "That image took too long to process. Please try a smaller image.";
    code = "processing_timeout";
  } else if (xhr.status >= 500) {
    message = "The server hit an unexpected error. Please try again in a moment.";
    code = "server_error";
  }

  return new ApiError(message, code, xhr.status);
}

export async function removeBackground(file: File, options: RemoveOptions = {}): Promise<Blob> {
  if (REMOVAL_ENGINE === "browser") {
    try {
      return await removeBackgroundInBrowser(file, options);
    } catch (error) {
      if (options.signal?.aborted || (error instanceof DOMException && error.name === "AbortError")) {
        throw new ApiError("Processing was cancelled.", "aborted", 0, false);
      }
      throw new ApiError(
        error instanceof Error && error.message
          ? error.message
          : "The AI model could not run in this browser. Please try another browser or a smaller image.",
        "browser_engine_failed",
        0,
        true,
      );
    }
  }

  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    const form = new FormData();
    form.append("image", file, file.name || "image.png");
    form.append("mode", options.mode ?? "general");
    if (options.alphaMatting) form.append("alpha_matting", "true");

    // Never set Content-Type manually: the browser adds the multipart boundary.
    xhr.open("POST", endpoint("/api/remove-background"));
    xhr.responseType = "blob";
    xhr.timeout = 190_000;

    xhr.upload.onprogress = (event) => {
      if (event.lengthComputable && options.onUploadProgress) {
        options.onUploadProgress(Math.min(100, Math.round((event.loaded / event.total) * 100)));
      }
    };

    xhr.onload = () => {
      if (xhr.status >= 200 && xhr.status < 300) {
        const blob = xhr.response as Blob;
        if (blob.type && !blob.type.includes("image/png")) {
          reject(new ApiError("The server returned an unexpected file. Please try again."));
          return;
        }
        resolve(blob);
        return;
      }
      void parseError(xhr)
        .then(reject)
        .catch(() =>
          reject(new ApiError("The server rejected this upload. Please try again.", "server_error", xhr.status)),
        );
    };

    xhr.onerror = () =>
      reject(
        new ApiError(
          `We could not reach the ClearPix API at ${apiOriginLabel()}. Check your connection and try again.`,
          "network_error",
          0,
        ),
      );
    xhr.ontimeout = () =>
      reject(
        new ApiError(
          "The request timed out. Please try again with a smaller image.",
          "processing_timeout",
          504,
        ),
      );
    xhr.onabort = () => reject(new ApiError("Processing was cancelled.", "aborted", 0, false));

    if (options.signal) {
      if (options.signal.aborted) {
        reject(new ApiError("Processing was cancelled.", "aborted", 0, false));
        return;
      }
      options.signal.addEventListener("abort", () => xhr.abort(), { once: true });
    }

    xhr.send(form);
  });
}

export async function zipResults(items: { blob: Blob; name: string }[]): Promise<Blob> {
  if (REMOVAL_ENGINE === "browser") {
    const entries = await Promise.all(
      items.map(async (item, index) => ({
        name: `clearpix-${String(index + 1).padStart(2, "0")}-${(
          item.name.replace(/\.[^./\\]+$/, "") || "image"
        ).slice(0, 60)}.png`,
        data: new Uint8Array(await item.blob.arrayBuffer()),
      })),
    );
    return createZipBlob(entries);
  }

  const form = new FormData();
  items.forEach((item, index) => {
    form.append("images", item.blob, `result-${index + 1}.png`);
  });
  form.append("filenames", items.map((item) => item.name).join(","));

  let response: Response;
  try {
    response = await fetch(endpoint("/api/zip"), { method: "POST", body: form });
  } catch {
    throw new ApiError(
      `We could not reach the ClearPix API at ${apiOriginLabel()} to build your ZIP file. Please try again.`,
      "network_error",
      0,
    );
  }

  if (!response.ok) {
    let message = "We could not create the ZIP download. Please try again.";
    try {
      const parsed = (await response.json()) as { error?: { message?: string } };
      if (parsed.error?.message) message = parsed.error.message;
    } catch {
      /* ignore */
    }
    throw new ApiError(message, "zip_failed", response.status);
  }

  return response.blob();
}

export type HealthInfo = {
  status: string;
  model?: string;
  model_loaded?: boolean;
  max_upload_mb?: number;
  max_batch_images?: number;
};

export async function checkHealth(): Promise<HealthInfo | null> {
  if (REMOVAL_ENGINE === "browser") {
    // The model ships with the site, so there is no service to poll.
    return {
      status: "ok",
      model: BROWSER_MODEL_LABEL,
      model_loaded: true,
      max_upload_mb: 10,
      max_batch_images: 5,
    };
  }

  const controller = new AbortController();
  const timer = window.setTimeout(() => controller.abort(), 6000);
  try {
    const response = await fetch(endpoint("/api/health"), {
      cache: "no-store",
      signal: controller.signal,
    });
    if (!response.ok) return null;
    return (await response.json()) as HealthInfo;
  } catch {
    return null;
  } finally {
    window.clearTimeout(timer);
  }
}
