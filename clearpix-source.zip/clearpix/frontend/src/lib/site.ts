const rawSiteUrl = (import.meta.env.VITE_SITE_URL as string | undefined) ?? "";
const fallbackOrigin = typeof window !== "undefined" ? window.location.origin : "";

/**
 * The API can be configured three ways, in priority order:
 *  1. `VITE_API_BASE_URL` at build time (a separate API host).
 *  2. `window.__CLEARPIX_CONFIG__.apiBaseUrl` at runtime (set in public/config.js),
 *     so a static build can be pointed at a backend without rebuilding.
 *  3. An empty value: same-origin requests to `/api/...`, proxied in development
 *     by Vite and by the host's reverse proxy in production.
 */
function resolveApiBase(): string {
  const envBase = ((import.meta.env.VITE_API_BASE_URL as string | undefined) ?? "").trim();
  const runtimeBase =
    typeof window !== "undefined"
      ? ((window as unknown as { __CLEARPIX_CONFIG__?: { apiBaseUrl?: string } }).__CLEARPIX_CONFIG__
          ?.apiBaseUrl ?? "")
      : "";
  return (envBase || runtimeBase).replace(/\/$/, "");
}

export const SITE = {
  name: "ClearPix",
  tagline: "Remove backgrounds instantly. Create something amazing.",
  description:
    "Edit photos online for free with ClearPix. Remove backgrounds with AI, change backgrounds, resize, crop, add text and export transparent PNGs — no signup required.",
  url: (rawSiteUrl || fallbackOrigin).replace(/\/$/, ""),
  apiBase: resolveApiBase(),
  contactEmail: ((import.meta.env.VITE_CONTACT_EMAIL as string | undefined) ?? "").trim(),
  gaMeasurementId: ((import.meta.env.VITE_GA_MEASUREMENT_ID as string | undefined) ?? "").trim(),
  adsenseClient: ((import.meta.env.VITE_ADSENSE_CLIENT as string | undefined) ?? "").trim(),
} as const;

export const MAX_FILE_SIZE = 10 * 1024 * 1024;
export const MAX_FILE_SIZE_LABEL = "10 MB";
export const MAX_BATCH_FILES = 5;
export const MAX_IMAGE_DIMENSION = 12000;
export const MAX_IMAGE_PIXELS = 40_000_000;
export const ACCEPTED_EXTENSIONS = [".jpg", ".jpeg", ".png", ".webp"];
export const ACCEPTED_MIME = ["image/jpeg", "image/png", "image/webp"];
export const BLOCKED_EXTENSIONS = [".gif", ".svg", ".heic", ".heif", ".tif", ".tiff", ".bmp", ".avif"];
export const BLOCKED_MIME = [
  "image/gif",
  "image/svg+xml",
  "image/heic",
  "image/heif",
  "image/tiff",
  "image/bmp",
  "image/avif",
];
export const ACCEPT_ATTRIBUTE = "image/jpeg,image/png,image/webp,.jpg,.jpeg,.png,.webp";

export const NAV_LINKS = [
  { label: "Editor", href: "/editor" },
  { label: "Background Remover", href: "/remove-background" },
  { label: "Tools", href: "/#tools" },
  { label: "How It Works", href: "/#how-it-works" },
  { label: "FAQ", href: "/#faq" },
] as const;

export const FOOTER_TOOL_LINKS = [
  { label: "Photo Editor", href: "/editor" },
  { label: "Background Remover", href: "/remove-background" },
  { label: "Background Changer", href: "/background-changer" },
  { label: "Image Resizer", href: "/image-resizer" },
  { label: "Image Cropper", href: "/image-cropper" },
  { label: "Rotate Image", href: "/rotate-image" },
  { label: "Transparent PNG Maker", href: "/transparent-png" },
] as const;

export const FOOTER_COMPANY_LINKS = [
  { label: "How It Works", href: "/#how-it-works" },
  { label: "Features", href: "/#features" },
  { label: "How to Remove a Background", href: "/how-to-remove-background" },
  { label: "Free Background Remover", href: "/free-background-remover" },
  { label: "Product Photo Editor", href: "/product-photo-background-remover" },
  { label: "FAQ", href: "/#faq" },
  { label: "Privacy Policy", href: "/privacy-policy" },
  { label: "Terms of Use", href: "/terms-of-use" },
  { label: "Contact", href: "/contact" },
] as const;

export type EditorToolLink = {
  slug: string;
  title: string;
  badge: string;
  description: string;
  tool: string;
  href: string;
  icon: string;
};

export const TOOL_CARDS: EditorToolLink[] = [
  {
    slug: "background-remover",
    title: "Background Remover",
    badge: "AI",
    description: "Cut the subject out of any photo with the U²-Net model and keep a transparent PNG.",
    tool: "background",
    href: "/editor?tool=background",
    icon: "scissors",
  },
  {
    slug: "background-changer",
    title: "Background Changer",
    badge: "AI",
    description: "Swap the cut-out onto a colour, gradient, studio scene or your own background photo.",
    tool: "background",
    href: "/editor?tool=background&panel=replace",
    icon: "image",
  },
  {
    slug: "image-resizer",
    title: "Image Resizer",
    badge: "Size",
    description: "Resize by pixels or percentage with social and marketplace presets that really resize.",
    tool: "resize",
    href: "/editor?tool=resize",
    icon: "compress",
  },
  {
    slug: "image-cropper",
    title: "Image Cropper",
    badge: "Crop",
    description: "Drag a crop box with locked ratios for posts, stories, profiles and banners.",
    tool: "crop",
    href: "/editor?tool=crop",
    icon: "grid",
  },
  {
    slug: "rotate-image",
    title: "Rotate & Flip",
    badge: "Transform",
    description: "Rotate in 90° steps or by a custom angle, and flip horizontally or vertically.",
    tool: "rotate",
    href: "/editor?tool=rotate",
    icon: "refresh",
  },
  {
    slug: "image-filters",
    title: "Image Filters",
    badge: "Looks",
    description: "Ten real filter looks with an intensity slider, applied to your exported file.",
    tool: "filters",
    href: "/editor?tool=filters",
    icon: "palette",
  },
  {
    slug: "photo-adjustments",
    title: "Photo Adjustments",
    badge: "Tune",
    description: "Brightness, contrast, saturation, exposure, temperature, shadows and sharpness.",
    tool: "adjust",
    href: "/editor?tool=adjust",
    icon: "wand",
  },
  {
    slug: "text-editor",
    title: "Text Editor",
    badge: "Type",
    description: "Add headings, captions and sale badges with fonts, outlines, shadows and spacing.",
    tool: "text",
    href: "/editor?tool=text",
    icon: "file",
  },
  {
    slug: "sticker-editor",
    title: "Shapes & Stickers",
    badge: "Decor",
    description: "Drop in shapes, arrows, stars and badges, then move, scale and rotate them.",
    tool: "stickers",
    href: "/editor?tool=stickers",
    icon: "heart",
  },
  {
    slug: "png-maker",
    title: "PNG Maker",
    badge: "Export",
    description: "Export a real transparent PNG, JPEG or WEBP with the transparency preserved.",
    tool: "export",
    href: "/editor?tool=export",
    icon: "download",
  },
  {
    slug: "product-photo-editor",
    title: "Product Photo Editor",
    badge: "Shop",
    description: "Clean white or studio backgrounds, drop shadows and square marketplace crops.",
    tool: "shadow",
    href: "/editor?tool=shadow",
    icon: "store",
  },
  {
    slug: "batch",
    title: "Batch Remover",
    badge: "5 at once",
    description: "Process several images in a controlled queue, then download them together as a ZIP.",
    tool: "batch",
    href: "/editor?tool=batch",
    icon: "layers",
  },
];
