import { SITE } from "./site";

declare global {
  interface Window {
    dataLayer?: unknown[];
    gtag?: (...args: unknown[]) => void;
  }
}

let initialised = false;

export function analyticsEnabled(): boolean {
  return /^G-[A-Z0-9]{4,}$/i.test(SITE.gaMeasurementId);
}

export function initAnalytics(): void {
  if (initialised || !analyticsEnabled() || typeof document === "undefined") return;
  initialised = true;

  const script = document.createElement("script");
  script.async = true;
  script.src = `https://www.googletagmanager.com/gtag/js?id=${SITE.gaMeasurementId}`;
  document.head.appendChild(script);

  window.dataLayer = window.dataLayer ?? [];
  window.gtag = function gtag() {
    // eslint-disable-next-line prefer-rest-params
    window.dataLayer?.push(arguments);
  };
  window.gtag("js", new Date());
  window.gtag("config", SITE.gaMeasurementId, { anonymize_ip: true });
}

type EventName =
  | "image_loaded"
  | "upload_started"
  | "background_removal_completed"
  | "download_completed"
  | "batch_processing_started"
  | "error_occurred";

export function track(event: EventName, params: Record<string, string | number | boolean> = {}): void {
  if (!analyticsEnabled() || typeof window === "undefined" || !window.gtag) return;
  // Never send image contents, filenames or personally identifying data.
  window.gtag("event", event, params);
}
