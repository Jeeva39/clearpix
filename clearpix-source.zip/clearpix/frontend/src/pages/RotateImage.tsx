import { Link } from "react-router-dom";
import { ContentPage } from "../components/ContentPage";
import { Seo, breadcrumbSchema, webAppSchema } from "../components/Seo";

const BREADCRUMBS = [
  { name: "Home", path: "/" },
  { name: "Rotate Image", path: "/rotate-image" },
];

export function RotateImage() {
  return (
    <>
      <Seo
        title="Rotate Image Online Free — Rotate & Flip Photos | ClearPix"
        description="Rotate an image 90 degrees left or right, turn it 180 degrees, straighten a crooked photo, or flip it horizontally and vertically. Free, in your browser, no signup."
        path="/rotate-image"
        jsonLd={[breadcrumbSchema(BREADCRUMBS), webAppSchema()]}
      />
      <ContentPage
        breadcrumbs={BREADCRUMBS}
        title="Rotate an Image Online — 90°, 180° or a Custom Angle"
        intro={
          <>
            Turn a sideways phone photo upright, flip a mirrored selfie, or straighten a horizon that
            was a degree or two off. The canvas and the exported file both follow the rotation, so the
            dimensions stay correct.
          </>
        }
        related={[
          { label: "Open the rotate tool", href: "/editor?tool=rotate" },
          { label: "Crop an image", href: "/image-cropper" },
          { label: "Resize an image", href: "/image-resizer" },
          { label: "Photo editor", href: "/photo-editor-online" },
        ]}
      >
        <h2>Quarter turns and fine straightening</h2>
        <p>
          A 90° turn swaps the width and height. ClearPix updates the document and the export to match
          instead of leaving a landscape canvas around a portrait photo. The straighten slider covers
          small corrections between -45° and 45°, and the editor scales the result just enough to avoid
          empty corners.
        </p>

        <h2>Flip instead of rotate</h2>
        <p>
          A horizontal flip mirrors the image left to right, which is what you want for a selfie that
          reads backwards or a composition that feels heavy on one side. A vertical flip mirrors top to
          bottom. Unlike rotation, flips never change the image dimensions, so a layout built around the
          original shape keeps working.
        </p>

        <h2>Why a photo arrives sideways</h2>
        <p>
          Phone cameras often store the picture in landscape and add an EXIF orientation tag telling
          software to display it upright. Most modern browsers respect that tag, but some upload paths
          and older tools ignore it. ClearPix applies the orientation before anything else, so the
          editor and the AI model both see the photo the right way up. If it still looks wrong, a single
          90° turn fixes it and is stored in the edit itself.
        </p>

        <h2>Rotation, crop and resize together</h2>
        <p>
          These are steps in one editor, and every step is recorded in the undo history. Rotate a photo,
          crop the new shape, then resize for a platform — press Ctrl/Cmd+Z at any point to step back.
          <Link to="/editor?tool=rotate"> Open the rotate tool</Link> to straighten a photo now.
        </p>
      </ContentPage>
    </>
  );
}
