import { Link } from "react-router-dom";
import { ContentPage } from "../components/ContentPage";
import { Seo, breadcrumbSchema, webAppSchema } from "../components/Seo";

const BREADCRUMBS = [
  { name: "Home", path: "/" },
  { name: "Image Cropper", path: "/image-cropper" },
];

export function ImageCropper() {
  return (
    <>
      <Seo
        title="Free Image Cropper — Crop Photos to Any Ratio Online | ClearPix"
        description="Crop images online for free with a draggable crop box. Lock 1:1, 4:5, 16:9, 9:16 and other ratios, apply the crop and download the real cropped file."
        path="/image-cropper"
        jsonLd={[breadcrumbSchema(BREADCRUMBS), webAppSchema()]}
      />
      <ContentPage
        breadcrumbs={BREADCRUMBS}
        title="Free Image Cropper — Drag, Lock a Ratio, Download"
        intro={
          <>
            Draw a crop box over your photo, drag it into place, pull the corners to the size you want,
            and apply. The exported image contains only that region, at its true pixel size.
          </>
        }
        related={[
          { label: "Open the image cropper", href: "/editor?tool=crop" },
          { label: "Resize an image", href: "/image-resizer" },
          { label: "Rotate or flip a photo", href: "/rotate-image" },
          { label: "Photo editor", href: "/photo-editor-online" },
        ]}
      >
        <h2>Crop to a ratio, or freehand</h2>
        <p>
          Free crop is the right choice when you are removing a distraction at the edge of a photo. The
          ratio locks are for publishing: 1:1 for a profile or a square post, 4:5 for a portrait feed
          image, 3:4 and 2:3 for print-style framing, 16:9 for a video thumbnail or presentation, 9:16
          for a story or reel cover, and 3:2 for a classic camera crop.
        </p>

        <h2>How the crop box behaves</h2>
        <ul>
          <li>Drag inside the box to move it without changing its size.</li>
          <li>Drag any corner handle to resize it.</li>
          <li>Choose a ratio first and the box stays inside that shape as you resize.</li>
          <li>The area outside the box is dimmed so you can see exactly what will be kept.</li>
        </ul>

        <h2>Crop is not the same as zoom</h2>
        <p>
          Cropping discards pixels outside the selection and the exported dimensions become the crop
          size. Resizing keeps the whole photo and changes how many pixels it contains. If you crop a
          4000-pixel photo down to a face and need a larger file, crop first and then resize — but
          remember that upscaling cannot recreate detail that was never captured.
        </p>

        <h2>Cropping after background removal</h2>
        <p>
          Crop works on the composed image, so a cut-out subject with a new background crops as one
          picture. Text and sticker layers move with the crop so they stay where you placed them. If you
          crop first and remove the background afterwards, the AI only sees the cropped photo, which is
          usually faster and just as accurate.
        </p>

        <h2>What leaves the editor</h2>
        <p>
          The download is the cropped image at full resolution in PNG, JPEG or WEBP — not a screenshot
          of the preview. JPEG has no transparency, so transparent areas are flattened onto a colour you
          choose. <Link to="/editor?tool=crop">Open the image cropper</Link> and try a ratio on your
          photo.
        </p>
      </ContentPage>
    </>
  );
}
