import { Link } from "react-router-dom";
import { ContentPage } from "../components/ContentPage";
import { Seo, breadcrumbSchema } from "../components/Seo";

const BREADCRUMBS = [
  { name: "Home", path: "/" },
  { name: "Transparent PNG", path: "/transparent-png" },
];

export function TransparentPng() {
  return (
    <>
      <Seo
        title="Transparent PNG Maker – Free Online Tool | ClearPix"
        description="Make a transparent PNG online for free. ClearPix removes the background from your image and gives you a real PNG with an alpha channel, ready to download."
        path="/transparent-png"
        jsonLd={[breadcrumbSchema(BREADCRUMBS)]}
      />
      <ContentPage
        breadcrumbs={BREADCRUMBS}
        title="Transparent PNG Maker: Create Images With No Background"
        intro={
          <>
            A transparent PNG is an image with no background at all. ClearPix creates one from any
            photo in seconds: the subject stays, the background disappears, and the file keeps a true
            alpha channel so it layers cleanly over anything.
          </>
        }
        related={[
          { label: "Remove background from a photo", href: "/remove-background" },
          { label: "Remove background from an image", href: "/remove-background-from-image" },
          { label: "Product photo cut-outs", href: "/product-photo-background-remover" },
          { label: "Free background remover", href: "/free-background-remover" },
        ]}
      >
        <h2>Why PNG and not JPG</h2>
        <p>
          JPG has no alpha channel. It can only store solid colours, so any transparent area has to
          be filled with something — usually white. That is why exporting a cut-out as JPG always
          produces a white box around your subject. PNG stores per-pixel opacity, which is exactly
          what a cut-out needs.
        </p>
        <p>
          WEBP can store transparency too and is smaller for photographs, but PNG remains the safest
          choice for compatibility with design tools, marketplaces, office documents and print
          workflows. ClearPix downloads PNG by default for that reason.
        </p>

        <h2>How to check that the transparency is real</h2>
        <p>
          In the ClearPix preview, the “Transparent” swatch shows the cut-out over a checkerboard
          pattern. That pattern is not part of the image — it is the standard way to display empty
          pixels. If you see the checkerboard through the background of your subject, the PNG is
          genuinely transparent.
        </p>
        <p>
          A quick independent check: open the downloaded file in any image editor and look at the
          layer or channel panel. A transparent PNG will have an alpha channel and empty pixels where
          the background used to be. You can also drop the file onto a coloured slide — if the
          background of the slide shows through, you are done.
        </p>

        <h2>Where transparent PNGs are used</h2>
        <ul>
          <li>Product images placed on white, grey or branded catalogue backgrounds.</li>
          <li>Logos and signatures that must sit on any colour.</li>
          <li>Thumbnails and social posts with layered text and graphics.</li>
          <li>Presentation slides where the subject overlaps a chart or photo.</li>
          <li>Stickers, overlays and video lower-thirds.</li>
        </ul>

        <h2>Choosing a preview background before you export</h2>
        <p>
          The editor can show your cut-out on white, black, light grey, lilac, mint or sand. These
          are previews only: switching them does not modify the PNG you download. If you deliberately
          want a flattened image with a colour behind the subject, use the JPG export button, which
          bakes in the selected preview colour. You always keep the transparent original separately.
        </p>

        <h2>Resolution and quality</h2>
        <p>
          The transparent PNG keeps the resolution of your upload, up to the supported limit of
          12,000 pixels per side. There is no forced downscaling and no watermark, so the exported
          file is suitable for print as well as web. Very large source images simply take a little
          longer to process.
        </p>
        <p>
          <Link to="/#tool">Create your transparent PNG</Link> now — upload, preview and download in
          one flow.
        </p>
      </ContentPage>
    </>
  );
}
