import { Link } from "react-router-dom";
import { ContentPage } from "../components/ContentPage";
import { Seo, breadcrumbSchema, webAppSchema } from "../components/Seo";

const BREADCRUMBS = [
  { name: "Home", path: "/" },
  { name: "Remove Background", path: "/remove-background" },
];

export function RemoveBackground() {
  return (
    <>
      <Seo
        title="Remove Background From Photo Online Free | ClearPix"
        description="Remove the background from any photo online for free with ClearPix AI. Upload an image and download a transparent PNG in seconds — no signup, no watermark."
        path="/remove-background"
        jsonLd={[breadcrumbSchema(BREADCRUMBS), webAppSchema()]}
      />
      <ContentPage
        breadcrumbs={BREADCRUMBS}
        title="Remove Background From Photo Online — Free and Instant"
        intro={
          <>
            ClearPix removes the background from your photos automatically. Upload a portrait, a
            product shot or a screenshot, let the AI isolate the subject, and download a clean
            transparent PNG. No signup, no watermark, no editing software.
          </>
        }
        related={[
          { label: "Remove background from an image", href: "/remove-background-from-image" },
          { label: "Create transparent PNGs", href: "/transparent-png" },
          { label: "Product photo background remover", href: "/product-photo-background-remover" },
          { label: "Free background remover", href: "/free-background-remover" },
        ]}
      >
        <h2>What you get when you remove a background</h2>
        <p>
          Removing a background means keeping the subject and discarding everything around it.
          ClearPix returns a PNG file where the subject stays fully visible and the rest of the
          canvas is transparent. Because the transparency is stored in the file itself, the image
          drops onto a white product page, a dark slide deck or a rainbow gradient without a visible
          edge.
        </p>
        <p>
          The pixels inside the subject are your original pixels. The AI only predicts which areas
          should be visible — it does not repaint the photo or generate a new person. What you
          photographed is what you download.
        </p>

        <h2>Best photos for background removal</h2>
        <ul>
          <li>
            <strong>Clear separation:</strong> the subject and background differ in tone, colour or
            focus. A dark object in front of a bright wall is the easiest case.
          </li>
          <li>
            <strong>Reasonable resolution:</strong> anything from a phone photo up to 12,000 pixels
            on a side works. Very small thumbnails give the model too little to work with.
          </li>
          <li>
            <strong>Normal exposure:</strong> blown-out highlights or heavy motion blur reduce edge
            accuracy, especially around hair.
          </li>
        </ul>
        <p>
          Difficult images still produce usable results, but expect to check the edges. A photo where
          the subject wears the same colour as the wall is a genuinely hard problem for any
          segmentation model, including this one.
        </p>

        <h2>Transparent PNG, JPG or both</h2>
        <p>
          The primary download is always a transparent PNG, because that is the only common web
          format that stores transparency properly. Some marketplaces and print services insist on a
          JPG with a solid background, so the editor also lets you pick a preview colour and export a
          flattened JPG. Use the PNG unless a platform specifically asks otherwise.
        </p>

        <h2>Works on every screen</h2>
        <p>
          ClearPix is a responsive web app, so the same tool runs on an iPhone, an Android tablet, a
          Chromebook or a desktop browser. There is no app to install and no account to remember, and
          processing happens on the server rather than on your device — your phone does not need a
          powerful processor to get a good result.
        </p>

        <h2>Batch removal in one go</h2>
        <p>
          If you have a handful of images, upload up to five at once. Each image shows its own status
          and can be retried or downloaded separately, and the finished results can be bundled into a
          single ZIP file. That workflow is aimed at sellers preparing a small catalogue rather than
          designers processing hundreds of files.
        </p>
        <p>
          Ready to try it? <Link to="/#tool">Open the background remover</Link> and upload your first
          image — the download arrives without a watermark.
        </p>
      </ContentPage>
    </>
  );
}
