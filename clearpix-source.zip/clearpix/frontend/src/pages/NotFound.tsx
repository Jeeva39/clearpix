import { Link } from "react-router-dom";
import { Seo } from "../components/Seo";
import { Icon } from "../components/Icon";

export function NotFound() {
  return (
    <>
      <Seo
        title="Page Not Found | ClearPix"
        description="The page you are looking for does not exist. Return to the ClearPix background remover."
        path="/404"
        noindex
      />
      <section className="container-page flex min-h-[60vh] flex-col items-center justify-center py-16 text-center">
        <span className="eyebrow">404</span>
        <h1 className="mt-4 text-3xl font-extrabold tracking-tight text-ink sm:text-4xl">
          We couldn't find that page
        </h1>
        <p className="mt-3 max-w-md text-base leading-7 text-ink-soft">
          The link may be out of date. Head back to the background remover and pick up where you left
          off.
        </p>
        <div className="mt-6 flex flex-wrap justify-center gap-3">
          <Link to="/" className="btn-primary">
            Go to ClearPix home
          </Link>
          <Link to="/#tool" className="btn-secondary">
            <Icon name="upload" size={16} />
            Remove a background
          </Link>
        </div>
      </section>
    </>
  );
}
