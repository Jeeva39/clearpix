import { ContentPage } from "../components/ContentPage";
import { Seo, breadcrumbSchema } from "../components/Seo";

const BREADCRUMBS = [
  { name: "Home", path: "/" },
  { name: "Terms of Use", path: "/terms-of-use" },
];

export function TermsOfUse() {
  return (
    <>
      <Seo
        title="Terms of Use | ClearPix"
        description="The terms that apply when you use ClearPix, the free online AI background remover."
        path="/terms-of-use"
        jsonLd={[breadcrumbSchema(BREADCRUMBS)]}
      />
      <ContentPage
        breadcrumbs={BREADCRUMBS}
        title="Terms of Use"
        intro={<>Plain-language terms for using ClearPix, a free online background removal tool.</>}
        showCta={false}
        related={[
          { label: "Privacy Policy", href: "/privacy-policy" },
          { label: "Contact", href: "/contact" },
        ]}
      >
        <p className="text-sm text-ink-muted">Last updated: 18 November 2026</p>

        <h2>Using the service</h2>
        <p>
          ClearPix lets you upload an image and download a version with the background removed. The
          service is provided free of charge and without registration. By using it, you agree to
          these terms.
        </p>

        <h2>Your images and your rights</h2>
        <p>
          You keep all rights to the images you upload. You must own the image or have permission to
          edit and use it. Do not upload images that are unlawful, that depict other people in ways
          you are not allowed to use, or that infringe someone else's copyright. Because ClearPix
          does not store uploads, you are responsible for keeping your own copy of any source file.
        </p>

        <h2>Acceptable use</h2>
        <ul>
          <li>Do not attempt to overload, probe or bypass the service's rate limits.</li>
          <li>Do not use automated scripts to process large volumes of images through the free tool.</li>
          <li>Do not upload malware, archives or files that are not images.</li>
          <li>Do not use the service to create deceptive imagery of real people.</li>
        </ul>
        <p>
          Access may be limited or blocked if usage threatens the availability of the service for
          other people.
        </p>

        <h2>Limits</h2>
        <p>
          ClearPix accepts JPG, JPEG, PNG and WEBP images up to 10 MB, with a maximum of 12,000 pixels
          per side and 40 megapixels in total, and up to five images per batch. Requests are rate
          limited. These limits may change without notice if capacity requires it.
        </p>

        <h2>No guarantee of results</h2>
        <p>
          Automatic background removal is a prediction, not a guarantee. Results vary with the photo,
          the subject and the contrast between them. The service is provided “as is”, without
          warranties of any kind, and without a guarantee of uninterrupted availability. Always check
          an image before publishing or printing it.
        </p>

        <h2>Limitation of liability</h2>
        <p>
          To the extent permitted by law, the operator of ClearPix is not liable for indirect or
          consequential losses, lost profits, or losses arising from the use of, or inability to use,
          the service.
        </p>

        <h2>Intellectual property</h2>
        <p>
          The ClearPix name, site design and interface belong to the operator. The images you process
          belong to you. Nothing in these terms transfers ownership of your images to ClearPix.
        </p>

        <h2>Changes</h2>
        <p>
          Features, limits and these terms may change as the service evolves. Continued use after a
          change means you accept the updated terms. The date at the top of this page shows when it
          was last revised.
        </p>

        <h2>Contact</h2>
        <p>
          Questions about these terms can be sent through the <a href="/contact">contact page</a>.
        </p>
      </ContentPage>
    </>
  );
}
