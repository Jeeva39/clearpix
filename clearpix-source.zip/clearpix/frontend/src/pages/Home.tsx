import { Link } from "react-router-dom";
import { Seo, faqSchema, webAppSchema, websiteSchema } from "../components/Seo";
import { AdSlot } from "../components/AdSlot";
import { Icon } from "../components/Icon";
import { Hero } from "../features/home/Hero";
import { HowItWorks } from "../features/home/HowItWorks";
import { Features } from "../features/home/Features";
import { UseCases } from "../features/home/UseCases";
import { SEOContent } from "../features/home/SEOContent";
import { EditingTools } from "../features/home/EditingTools";
import { Faq } from "../features/home/Faq";
import { FAQ_ITEMS } from "../lib/faq";

export function Home() {
  return (
    <>
      <Seo
        title="Free Online Image Editor & AI Background Remover | ClearPix"
        description="Edit photos free with ClearPix: remove backgrounds with AI, change backgrounds, resize, crop, add text and filters, then export PNG, JPEG or WEBP. No signup."
        path="/"
        jsonLd={[websiteSchema(), webAppSchema(), faqSchema(FAQ_ITEMS)]}
      />
      <Hero />
      <EditingTools />
      <AdSlot />

      <section aria-labelledby="popular-pages-heading" className="container-page pb-4 pt-10">
        <div className="flex flex-col gap-4 rounded-xl2 border border-ink/[0.06] bg-white p-5 shadow-soft sm:flex-row sm:items-center sm:justify-between sm:p-6">
          <div>
            <h2 id="popular-pages-heading" className="text-base font-bold text-ink">
              Looking for a specific workflow?
            </h2>
            <p className="mt-1 text-sm text-ink-soft">
              Jump straight to a focused guide and tool for your use case.
            </p>
          </div>
          <div className="flex flex-wrap gap-2">
            {[
              { label: "Open the editor", href: "/editor" },
              { label: "Remove background", href: "/remove-background" },
              { label: "Image resizer", href: "/image-resizer" },
              { label: "Product photos", href: "/product-photo-background-remover" },
            ].map((link) => (
              <Link
                key={link.href}
                to={link.href}
                className="inline-flex items-center gap-1.5 rounded-full border border-ink/10 px-3.5 py-2 text-xs font-semibold text-ink-soft transition hover:border-brand-300 hover:bg-brand-50 hover:text-brand-700"
              >
                {link.label}
                <Icon name="arrow-right" size={13} />
              </Link>
            ))}
          </div>
        </div>
      </section>

      <HowItWorks />
      <AdSlot />
      <Features />
      <UseCases />
      <SEOContent />
      <Faq />
    </>
  );
}
