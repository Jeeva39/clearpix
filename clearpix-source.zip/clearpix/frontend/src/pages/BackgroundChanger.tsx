import { Link } from "react-router-dom";
import { ContentPage } from "../components/ContentPage";
import { Seo, breadcrumbSchema, webAppSchema } from "../components/Seo";

const BREADCRUMBS = [
  { name: "Home", path: "/" },
  { name: "Background Changer", path: "/background-changer" },
];

export function BackgroundChanger() {
  return (
    <>
      <Seo
        title="Background Changer — Replace Any Photo Background Free | ClearPix"
        description="Change the background of any photo for free. Remove the original background with AI, then use a solid colour, gradient, studio scene or your own image and download the result."
        path="/background-changer"
        jsonLd={[breadcrumbSchema(BREADCRUMBS), webAppSchema()]}
      />
      <ContentPage
        breadcrumbs={BREADCRUMBS}
        title="Background Changer — Replace the Background of Any Photo"
        intro={
          <>
            ClearPix cuts the subject out with AI, then puts it on whatever background you want: a
            clean product white, a coloured gradient for social posts, a studio scene, or a photo you
            upload yourself. The subject and the background stay separate until you export.
          </>
        }
        related={[
          { label: "Open the background changer", href: "/editor?tool=background" },
          { label: "Remove a background", href: "/remove-background" },
          { label: "Product photo editor", href: "/product-photo-background-remover" },
          { label: "Transparent PNG maker", href: "/transparent-png" },
        ]}
      >
        <h2>Why replace a background instead of deleting it?</h2>
        <p>
          A transparent cut-out is useful, but most places that publish an image need a background.
          Marketplaces ask for white or light grey, social feeds reward colour, and a product page
          looks more expensive on a soft studio backdrop than on the kitchen table where the photo was
          taken. Replacing the background lets you reuse one photo in all of those places without
          shooting it again.
        </p>

        <h2>What you can put behind the subject</h2>
        <ul>
          <li>
            <strong>Solid colours:</strong> white, black, grey and a full colour picker for matching a
            brand palette.
          </li>
          <li>
            <strong>Gradients:</strong> two or three colours, any direction, with ready-made presets.
          </li>
          <li>
            <strong>Background images:</strong> upload your own photo, then fit, fill, zoom and nudge it
            until the subject sits naturally.
          </li>
          <li>
            <strong>Preset scenes:</strong> studio, nature, office, home, beach, sky, luxury, abstract,
            product and social-media backdrops.
          </li>
        </ul>

        <h2>Positioning the subject</h2>
        <p>
          Once the cut-out is on a new background you can drag the subject directly on the canvas, scale
          it, and snap it left, centre or right. That matters for social formats: a portrait cropped for
          a story needs the face higher in the frame than the same photo cropped for a square post.
        </p>

        <h2>Keeping the edges clean</h2>
        <p>
          The AI model returns real transparency, so hair, fur and thin straps keep their soft edges.
          If the result needs help, switch between the general and people models and run it again. A
          drop shadow or a thin outline can also separate a dark subject from a dark background — both
          are options in the editor&apos;s effects panel.
        </p>

        <h2>Export without flattening by accident</h2>
        <p>
          PNG and WEBP keep transparency, so you can export the cut-out on its own and place it
          elsewhere later. JPEG cannot store transparency, so ClearPix flattens it onto the colour you
          choose rather than silently turning the background black or white.{" "}
          <Link to="/editor?tool=background">Open the background changer</Link> to try it with your own
          photo.
        </p>
      </ContentPage>
    </>
  );
}
