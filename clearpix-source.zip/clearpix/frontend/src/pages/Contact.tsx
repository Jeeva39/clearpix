import { useState, type FormEvent } from "react";
import { Seo, breadcrumbSchema } from "../components/Seo";
import { Breadcrumbs } from "../components/Breadcrumbs";
import { Icon } from "../components/Icon";
import { SITE } from "../lib/site";

const BREADCRUMBS = [
  { name: "Home", path: "/" },
  { name: "Contact", path: "/contact" },
];

type Fields = { name: string; email: string; subject: string; message: string };
type Errors = Partial<Record<keyof Fields, string>>;
type Status = "idle" | "sending" | "success" | "error";

const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

function validate(fields: Fields): Errors {
  const errors: Errors = {};
  if (fields.name.trim().length < 2) errors.name = "Please enter your name.";
  if (!EMAIL_PATTERN.test(fields.email.trim())) errors.email = "Please enter a valid email address.";
  if (fields.subject.trim().length < 3) errors.subject = "Please add a short subject.";
  if (fields.message.trim().length < 20) errors.message = "Please write at least 20 characters.";
  return errors;
}

export function Contact() {
  const [fields, setFields] = useState<Fields>({ name: "", email: "", subject: "", message: "" });
  const [errors, setErrors] = useState<Errors>({});
  const [status, setStatus] = useState<Status>("idle");
  const [feedback, setFeedback] = useState("");

  const endpoint = (import.meta.env.VITE_CONTACT_ENDPOINT as string | undefined) ?? "";

  const update = (key: keyof Fields, value: string) => {
    setFields((current) => ({ ...current, [key]: value }));
    setErrors((current) => ({ ...current, [key]: undefined }));
    if (status !== "idle") setStatus("idle");
  };

  const onSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const nextErrors = validate(fields);
    setErrors(nextErrors);
    if (Object.keys(nextErrors).length > 0) return;

    if (endpoint) {
      setStatus("sending");
      try {
        const response = await fetch(endpoint, {
          method: "POST",
          headers: { "Content-Type": "application/json", Accept: "application/json" },
          body: JSON.stringify(fields),
        });
        if (!response.ok) throw new Error("Request failed");
        setStatus("success");
        setFeedback("Thanks — your message has been sent. We usually reply within two business days.");
        setFields({ name: "", email: "", subject: "", message: "" });
      } catch {
        setStatus("error");
        setFeedback(
          "We could not send your message right now. Please try again in a moment, or email us directly.",
        );
      }
      return;
    }

    if (SITE.contactEmail) {
      const body = `${fields.message}\n\n— ${fields.name} (${fields.email})`;
      window.location.href = `mailto:${SITE.contactEmail}?subject=${encodeURIComponent(
        fields.subject,
      )}&body=${encodeURIComponent(body)}`;
      setStatus("success");
      setFeedback(
        `Your email app should open with the message ready to send. If it did not, write to ${SITE.contactEmail}.`,
      );
      return;
    }

    setStatus("error");
    setFeedback(
      "The contact inbox has not been configured yet. In the meantime you can reach us through the support address listed by the site operator.",
    );
  };

  return (
    <>
      <Seo
        title="Contact ClearPix | Support & Feedback"
        description="Contact the ClearPix team with questions, bug reports, feedback or partnership enquiries."
        path="/contact"
        jsonLd={[breadcrumbSchema(BREADCRUMBS)]}
      />

      <section className="border-b border-ink/[0.06] bg-mist">
        <div className="container-page py-10 sm:py-14">
          <Breadcrumbs items={BREADCRUMBS} />
          <h1 className="mt-4 text-3xl font-extrabold tracking-tight text-ink sm:text-4xl">
            Contact ClearPix
          </h1>
          <p className="mt-4 max-w-2xl text-base leading-7 text-ink-soft">
            Found a bug, have a question about background removal, or want to suggest a feature?
            Send a message and we will get back to you.
          </p>
        </div>
      </section>

      <section className="py-12 sm:py-16">
        <div className="container-page">
          <div className="mx-auto grid max-w-4xl gap-6 lg:grid-cols-[minmax(0,1fr)_300px]">
            <form onSubmit={onSubmit} noValidate className="card p-5 sm:p-7">
              <div className="grid gap-4 sm:grid-cols-2">
                <div>
                  <label htmlFor="contact-name" className="text-sm font-semibold text-ink">
                    Name
                  </label>
                  <input
                    id="contact-name"
                    name="name"
                    autoComplete="name"
                    value={fields.name}
                    onChange={(event) => update("name", event.target.value)}
                    aria-invalid={Boolean(errors.name)}
                    aria-describedby={errors.name ? "contact-name-error" : undefined}
                    className="mt-1.5 w-full rounded-xl border border-ink/15 bg-white px-3.5 py-2.5 text-sm text-ink placeholder:text-ink-muted/70 focus:border-brand-400 focus:outline-none focus:ring-2 focus:ring-brand-200"
                    placeholder="Your name"
                  />
                  {errors.name && (
                    <p id="contact-name-error" className="mt-1 text-xs font-medium text-red-600">
                      {errors.name}
                    </p>
                  )}
                </div>

                <div>
                  <label htmlFor="contact-email" className="text-sm font-semibold text-ink">
                    Email
                  </label>
                  <input
                    id="contact-email"
                    name="email"
                    type="email"
                    autoComplete="email"
                    value={fields.email}
                    onChange={(event) => update("email", event.target.value)}
                    aria-invalid={Boolean(errors.email)}
                    aria-describedby={errors.email ? "contact-email-error" : undefined}
                    className="mt-1.5 w-full rounded-xl border border-ink/15 bg-white px-3.5 py-2.5 text-sm text-ink placeholder:text-ink-muted/70 focus:border-brand-400 focus:outline-none focus:ring-2 focus:ring-brand-200"
                    placeholder="you@example.com"
                  />
                  {errors.email && (
                    <p id="contact-email-error" className="mt-1 text-xs font-medium text-red-600">
                      {errors.email}
                    </p>
                  )}
                </div>
              </div>

              <div className="mt-4">
                <label htmlFor="contact-subject" className="text-sm font-semibold text-ink">
                  Subject
                </label>
                <input
                  id="contact-subject"
                  name="subject"
                  value={fields.subject}
                  onChange={(event) => update("subject", event.target.value)}
                  aria-invalid={Boolean(errors.subject)}
                  aria-describedby={errors.subject ? "contact-subject-error" : undefined}
                  className="mt-1.5 w-full rounded-xl border border-ink/15 bg-white px-3.5 py-2.5 text-sm text-ink placeholder:text-ink-muted/70 focus:border-brand-400 focus:outline-none focus:ring-2 focus:ring-brand-200"
                  placeholder="How can we help?"
                />
                {errors.subject && (
                  <p id="contact-subject-error" className="mt-1 text-xs font-medium text-red-600">
                    {errors.subject}
                  </p>
                )}
              </div>

              <div className="mt-4">
                <label htmlFor="contact-message" className="text-sm font-semibold text-ink">
                  Message
                </label>
                <textarea
                  id="contact-message"
                  name="message"
                  rows={6}
                  value={fields.message}
                  onChange={(event) => update("message", event.target.value)}
                  aria-invalid={Boolean(errors.message)}
                  aria-describedby={errors.message ? "contact-message-error" : undefined}
                  className="mt-1.5 w-full resize-y rounded-xl border border-ink/15 bg-white px-3.5 py-2.5 text-sm text-ink placeholder:text-ink-muted/70 focus:border-brand-400 focus:outline-none focus:ring-2 focus:ring-brand-200"
                  placeholder="Tell us what you need help with. Please do not attach or paste image contents."
                />
                {errors.message && (
                  <p id="contact-message-error" className="mt-1 text-xs font-medium text-red-600">
                    {errors.message}
                  </p>
                )}
              </div>

              <div aria-live="polite" className="mt-4">
                {status === "success" && (
                  <p className="flex items-start gap-2 rounded-xl border border-emerald-200 bg-emerald-50 px-3.5 py-3 text-sm text-emerald-800">
                    <Icon name="check" size={17} className="mt-0.5 shrink-0" />
                    {feedback}
                  </p>
                )}
                {status === "error" && (
                  <p className="flex items-start gap-2 rounded-xl border border-red-200 bg-red-50 px-3.5 py-3 text-sm text-red-700">
                    <Icon name="alert" size={17} className="mt-0.5 shrink-0" />
                    {feedback}
                  </p>
                )}
              </div>

              <button type="submit" disabled={status === "sending"} className="btn-primary mt-5 w-full sm:w-auto">
                <Icon name={status === "sending" ? "loader" : "mail"} size={17} className={status === "sending" ? "animate-spin" : ""} />
                {status === "sending" ? "Sending…" : "Send message"}
              </button>
            </form>

            <aside className="space-y-4">
              <div className="card p-5">
                <h2 className="text-sm font-bold text-ink">Before you write</h2>
                <ul className="mt-3 space-y-3 text-sm text-ink-soft">
                  <li className="flex gap-2">
                    <Icon name="info" size={16} className="mt-0.5 shrink-0 text-brand-600" />
                    Most answers are in the <a href="/#faq" className="font-semibold text-brand-700">FAQ</a>.
                  </li>
                  <li className="flex gap-2">
                    <Icon name="shield" size={16} className="mt-0.5 shrink-0 text-brand-600" />
                    Never share passwords or private images by email.
                  </li>
                  <li className="flex gap-2">
                    <Icon name="file" size={16} className="mt-0.5 shrink-0 text-brand-600" />
                    For a processing bug, mention the file type and approximate size.
                  </li>
                </ul>
              </div>

              <div className="card p-5">
                <h2 className="text-sm font-bold text-ink">Response time</h2>
                <p className="mt-1.5 text-sm leading-6 text-ink-muted">
                  ClearPix is a small independent project. Messages are usually answered within two
                  business days.
                </p>
              </div>
            </aside>
          </div>
        </div>
      </section>
    </>
  );
}
