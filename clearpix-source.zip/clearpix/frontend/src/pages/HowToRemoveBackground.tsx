import { Link } from "react-router-dom";
import { ContentPage } from "../components/ContentPage";
import { Seo, breadcrumbSchema } from "../components/Seo";

const BREADCRUMBS = [
  { name: "Home", path: "/" },
  { name: "How to Remove a Background", path: "/how-to-remove-background" },
];

export function HowToRemoveBackground() {
  return (
    <>
      <Seo
        title="How to Remove a Background From a Photo (Free Guide) | ClearPix"
        description="A practical guide to removing a background from a photo with ClearPix: prepare the image, run the AI, fix common edge problems and download a transparent PNG."
        path="/how-to-remove-background"
        jsonLd={[breadcrumbSchema(BREADCRUMBS)]}
      />
      <ContentPage
        breadcrumbs={BREADCRUMBS}
        title="How to Remove a Background From a Photo"
        intro={
          <>
            This guide walks through the whole process — from choosing a good source photo to
            checking the cut-out edges and exporting a transparent PNG you can actually use.
          </>
        }
        related={[
          { label: "Free background remover", href: "/free-background-remover" },
          { label: "Transparent PNG maker", href: "/transparent-png" },
          { label: "Product photo cut-outs", href: "/product-photo-background-remover" },
          { label: "Remove background from an image", href: "/remove-background-from-image" },
        ]}
      >
        <h2>1. Start with the right photo</h2>
        <p>
          Background removal is a segmentation problem, and segmentation improves with contrast. The
          ideal photo has a subject that stands out from its surroundings: different brightness,
          different colour, or a background that is slightly out of focus. If you can still choose
          the photo, take one more shot with the subject a step away from the wall.
        </p>
        <ul>
          <li>Use the largest version of the image you have — at least around 1,000 pixels wide.</li>
          <li>Avoid heavy filters; strong colour grading flattens the difference between subject and background.</li>
          <li>Keep the whole subject in frame. A cropped elbow or foot is fine; a cropped face is not.</li>
        </ul>

        <h2>2. Upload and run the AI</h2>
        <p>
          Open the <Link to="/#tool">ClearPix background remover</Link>, drag your image into the
          upload area and let the model run. For a single image, processing usually takes a few
          seconds. You will see an upload indicator while the file travels to the server, then the
          processing states — detecting the subject, removing the background, preparing the
          transparent image. There is no invented percentage during processing, because the model
          does not report progress; the stage messages tell you what is happening instead.
        </p>
        <p>
          If you are cutting out a person, switch the model selector to “People”. It uses a
          segmentation model tuned for human subjects, which can help with hair and shoulders.
        </p>

        <h2>3. Check the edges before downloading</h2>
        <p>
          Use the comparison slider to flip between the original and the cut-out. Zoom in on the
          areas that usually fail:
        </p>
        <ul>
          <li><strong>Hair and fur:</strong> look for a hard outline or a grey fringe.</li>
          <li><strong>Thin straps, glasses and handles:</strong> check that they were not swallowed by the mask.</li>
          <li><strong>Gaps inside the subject:</strong> the area between an arm and the body should be removed, not filled.</li>
          <li><strong>Contact points:</strong> where the subject meets the floor, some background may remain.</li>
        </ul>
        <p>
          Preview the result on white and on black. A fringe that looks clean on white sometimes
          shows a halo on black, which is a sign the mask edge needs softening in a design tool.
        </p>

        <h2>4. Download the transparent PNG</h2>
        <p>
          Use “Download Transparent PNG”. The filename is
          <code>clearpix-background-removed.png</code> and the alpha channel is preserved. Keep that
          file as your master copy. If you need a JPG with a solid background, choose a preview
          colour and use the JPG export instead — that produces a flattened file while the PNG stays
          transparent.
        </p>

        <h2>5. Fixing the remaining problems</h2>
        <p>
          No automatic cut-out is perfect on every image. If a stubborn patch of background remains,
          open the PNG in an editor and erase it with a soft brush; the mask edge is already smooth,
          so small touch-ups take seconds. If a fine detail disappeared, the most reliable fix is a
          slightly different source photo where the detail has more contrast.
        </p>

        <h2>6. Processing several images</h2>
        <p>
          Upload up to five images at once to see them in one queue. Each item has its own status and
          download button, and the “Download all (ZIP)” button bundles the finished results. Failed
          items can be retried without re-uploading, which is useful on a slow connection.
        </p>

        <h2>Common mistakes</h2>
        <ul>
          <li>Exporting the cut-out as JPG by accident, which fills the transparency with white.</li>
          <li>Uploading a screenshot of a photo instead of the photo itself — resolution drops and edges suffer.</li>
          <li>Judging the result at 25% zoom. Always check hair and edges at 100%.</li>
          <li>Re-editing a cut-out instead of keeping the original. Save your source photo.</li>
        </ul>
        <p>
          That is the whole workflow. <Link to="/#tool">Remove your first background</Link> and you
          will have a transparent PNG in under a minute.
        </p>
      </ContentPage>
    </>
  );
}
