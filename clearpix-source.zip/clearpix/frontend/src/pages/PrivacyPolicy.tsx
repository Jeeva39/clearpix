import { ContentPage } from "../components/ContentPage";
import { Seo, breadcrumbSchema } from "../components/Seo";
import { SITE } from "../lib/site";

const BREADCRUMBS = [
  { name: "Home", path: "/" },
  { name: "Privacy Policy", path: "/privacy-policy" },
];

export function PrivacyPolicy() {
  return (
    <>
      <Seo
        title="Privacy Policy | ClearPix"
        description="How ClearPix handles uploaded images, temporary processing files, rate limiting, optional analytics and your privacy."
        path="/privacy-policy"
        jsonLd={[breadcrumbSchema(BREADCRUMBS)]}
      />
      <ContentPage
        breadcrumbs={BREADCRUMBS}
        title="Privacy Policy"
        intro={<>What ClearPix does with your images and the limited technical data needed to run the service.</>}
        showCta={false}
        related={[
          { label: "Terms of Use", href: "/terms-of-use" },
          { label: "Contact", href: "/contact" },
        ]}
      >
        <p className="text-sm text-ink-muted">Last updated: 18 November 2026</p>

        <h2>Images you upload</h2>
        <p>
          Uploaded images are used for one purpose: removing the background you asked us to remove.
          Each file is written to a private temporary directory on the processing server, passed to
          the segmentation model, and converted into a PNG. The temporary directory is deleted
          immediately after the response is generated, whether processing succeeded or failed.
        </p>
        <p>
          Images are not added to a gallery, not used to train models, not sold and not shared with
          third parties. There is no account or history page on ClearPix, so there is no way to
          retrieve an earlier upload later — download your result while the page is open.
        </p>

        <h2>Temporary storage</h2>
        <p>
          Temporary files exist only for the duration of a request. Processed results are streamed
          back to your browser in the same response and are not stored on the server. If the server
          restarts or a request fails, the temporary directory is cleaned up on the next run as well.
        </p>

        <h2>Technical data and rate limiting</h2>
        <p>
          To keep the service available, the API limits how many requests one connection can make in
          a given time window. That requires processing your IP address in memory for a short period.
          Rate-limit counters are not written to a database and expire automatically. Server logs may
          record standard request information such as time, route and response status; they do not
          include image contents.
        </p>

        <h2>Cookies</h2>
        <p>
          ClearPix itself does not require cookies to remove a background. If the site operator
          enables Google Analytics or advertising, those services may set cookies in your browser.
          In that case, analytics is configured with IP anonymisation and only records anonymous
          interaction events — never image data, filenames or contact details.
        </p>

        <h2>Analytics</h2>
        <p>
          Analytics is optional and only loads when a measurement ID is configured by the site
          operator. When enabled, it records events such as “upload started”, “background removal
          completed”, “download completed”, “batch processing started” and “error occurred”, together
          with non-identifying details like the processing mode. You can block these requests with a
          browser content blocker or an extension without affecting the background remover.
        </p>

        <h2>Advertising</h2>
        <p>
          ClearPix may display advertising in the future to cover server costs. Advertisements are
          placed outside the upload, processing and download flow so they never interfere with the
          tool. Advertising providers may use cookies under their own policies. No advertising code
          loads on this site unless the operator configures an advertising account.
        </p>

        <h2>Children</h2>
        <p>
          ClearPix is a general-purpose utility and is not directed at children under 13. We do not
          knowingly collect personal information from children.
        </p>

        <h2>Your rights</h2>
        <p>
          Because we do not store accounts or image archives, there is generally no personal data
          held about you to access, correct or delete. If you have sent a message through the contact
          form and would like it removed, contact us and we will delete the correspondence.
        </p>

        <h2>Changes to this policy</h2>
        <p>
          If the way ClearPix handles data changes, this page will be updated and the date above will
          change. Material changes will be reflected in the behaviour described here, not only in the
          text.
        </p>

        <h2>Contact</h2>
        <p>
          Questions about privacy can be sent through the{" "}
          <a href="/contact">contact page</a>. {SITE.contactEmail && <>The operator's address is {SITE.contactEmail}.</>}
        </p>
      </ContentPage>
    </>
  );
}
