import { Link } from "react-router-dom";
import { ContentPage } from "../components/ContentPage";
import { Seo, breadcrumbSchema } from "../components/Seo";

const BREADCRUMBS = [
  { name: "Home", path: "/" },
  { name: "Remove Background From Image", path: "/remove-background-from-image" },
];

export function RemoveBackgroundFromImage() {
  return (
    <>
      <Seo
        title="Remove Background From Image Online | Free AI Tool | ClearPix"
        description="Remove the background from an image online with AI. ClearPix works with JPG, PNG and WEBP files up to 10 MB and gives you a transparent PNG — free, no account."
        path="/remove-background-from-image"
        jsonLd={[breadcrumbSchema(BREADCRUMBS)]}
      />
      <ContentPage
        breadcrumbs={BREADCRUMBS}
        title="Remove the Background From Any Image Online"
        intro={
          <>
            Got a JPG from a phone, a PNG screenshot or a WEBP export from a design tool? Drop it in
            and ClearPix will cut out the subject and hand back a transparent PNG. Format conversion
            and background removal happen in one step.
          </>
        }
        related={[
          { label: "Remove a photo background", href: "/remove-background" },
          { label: "Transparent PNG maker", href: "/transparent-png" },
          { label: "Free background remover", href: "/free-background-remover" },
          { label: "Step-by-step guide", href: "/how-to-remove-background" },
        ]}
      >
        <h2>Supported input formats</h2>
        <p>
          ClearPix accepts JPG, JPEG, PNG and WEBP files up to 10 MB. The extension alone is never
          trusted: the server opens the file, reads its real format and confirms it is a valid,
          decodable image before any processing starts. That protects the service from renamed
          archives or corrupted downloads, and it means you get a clear error instead of a failed
          job when a file is not what it claims to be.
        </p>
        <p>
          A file that is actually a JPG but named <code>.png</code> is still accepted, because the
          content is what matters. A text file renamed to <code>.png</code> is rejected with a
          readable message.
        </p>

        <h2>What happens to your image, step by step</h2>
        <ul>
          <li>The upload is received and checked for size, type and real image dimensions.</li>
          <li>EXIF orientation is applied so portrait photos are not processed sideways.</li>
          <li>The image is written to a private temporary directory on the server.</li>
          <li>An AI segmentation model predicts a mask for the subject.</li>
          <li>The mask is applied to your original pixels and encoded as a PNG with alpha.</li>
          <li>The temporary directory is deleted as soon as the response is sent.</li>
        </ul>
        <p>
          The processed PNG is returned directly in the response. It is not written to long-term
          storage, and there is no gallery or history page where old uploads could be viewed later.
        </p>

        <h2>Large images and long edges</h2>
        <p>
          Photos straight from a modern camera can be tens of megapixels. ClearPix accepts up to
          12,000 pixels on a side and 40 megapixels in total. Bigger files are rejected with an
          explanation rather than silently downscaled, so the dimensions you download always match
          what you uploaded. If a file is rejected for size, resizing it to around 4,000 pixels on
          the long edge is more than enough for web and print-at-home use.
        </p>

        <h2>Images with more than one subject</h2>
        <p>
          The model treats the main subject as one region. Two people standing together are usually
          kept as a group, which is what you want for a couple photo or a team shot. If the subjects
          are far apart with a busy background between them, results can vary — in that case run the
          image once, check the result, and trim the composition if necessary.
        </p>

        <h2>Retrying a failed image</h2>
        <p>
          Network interruptions happen. Every failed item in the queue keeps its original file, so
          you can press retry without selecting the file again. Errors are shown in plain language —
          file too large, unsupported type, server busy, processing timeout — and temporary failures
          can simply be retried after a moment.
        </p>
        <p>
          <Link to="/#tool">Upload an image</Link> to see the whole process for yourself.
        </p>
      </ContentPage>
    </>
  );
}
