import { Link } from "react-router-dom";
import { ContentPage } from "../components/ContentPage";
import { Seo, breadcrumbSchema, webAppSchema } from "../components/Seo";

const BREADCRUMBS = [
  { name: "Home", path: "/" },
  { name: "Photo Editor Online", path: "/photo-editor-online" },
];

export function PhotoEditorOnline() {
  return (
    <>
      <Seo
        title="Free Photo Editor Online — Background, Filters, Text & Export | ClearPix"
        description="Edit photos online free in ClearPix: AI background removal, background replacement, resize, crop, rotate, filters, text, stickers and real PNG/JPEG/WEBP export. No signup."
        path="/photo-editor-online"
        jsonLd={[breadcrumbSchema(BREADCRUMBS), webAppSchema()]}
      />
      <ContentPage
        breadcrumbs={BREADCRUMBS}
        title="A Free Photo Editor That Runs in Your Browser"
        intro={
          <>
            ClearPix is a focused editor rather than a full design suite. Upload a photo and you get the
            tools most people actually reach for: a clean AI cut-out, a different background, crop and
            resize, a handful of real colour adjustments, text and a few stickers — then a file you can
            use anywhere.
          </>
        }
        related={[
          { label: "Open the photo editor", href: "/editor" },
          { label: "Background changer", href: "/background-changer" },
          { label: "Image resizer", href: "/image-resizer" },
          { label: "Image cropper", href: "/image-cropper" },
        ]}
      >
        <h2>What the editor includes</h2>
        <ul>
          <li>
            <strong>Background removal:</strong> the same U²-Net model as the main ClearPix tool, with a
            general and a people mode.
          </li>
          <li>
            <strong>Backgrounds:</strong> transparent, solid colour, gradient, preset scenes or your own
            uploaded image, plus subject position and scale.
          </li>
          <li>
            <strong>Geometry:</strong> resize with presets, crop with ratio locks, rotate in quarter
            turns, straighten and flip.
          </li>
          <li>
            <strong>Colour:</strong> brightness, contrast, saturation, exposure, temperature, tint,
            highlights, shadows, sharpness, blur and opacity, with filters on top.
          </li>
          <li>
            <strong>Overlays:</strong> text layers with fonts, spacing, outlines and shadows, plus
            shapes and stickers.
          </li>
          <li>
            <strong>Export:</strong> PNG, JPEG or WEBP, with custom dimensions and a quality setting.
          </li>
        </ul>

        <h2>Undo is real</h2>
        <p>
          Every edit is recorded as state, not as a saved copy of the whole image, so undo and redo stay
          light even with a large photo loaded. Ctrl/Cmd+Z steps back, Ctrl/Cmd+Shift+Z steps forward,
          and the reset button returns to the untouched original at any point.
        </p>

        <h2>What stays on your device</h2>
        <p>
          Crop, resize, adjustments, filters, text, layers and export all happen locally in the browser
          canvas. Only the background removal request is sent to the server, and the temporary file is
          deleted as soon as the cut-out comes back. There is no account and no permanent image storage.
        </p>

        <h2>Project files</h2>
        <p>
          You can save the current edit as a <code>.clearpix.json</code> project from the export panel.
          It contains the original image, the cut-out, all layers and every adjustment, so you can reopen
          it later and continue. The file is downloaded, not uploaded anywhere.
        </p>

        <h2>Start with a photo</h2>
        <p>
          <Link to="/editor">Open the ClearPix editor</Link> and drag in a JPG, PNG or WEBP up to 10 MB.
          The preview appears immediately, before any processing starts.
        </p>
      </ContentPage>
    </>
  );
}
