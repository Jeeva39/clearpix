import { Link } from "react-router-dom";
import { ContentPage } from "../components/ContentPage";
import { Seo, breadcrumbSchema, webAppSchema } from "../components/Seo";

const BREADCRUMBS = [
  { name: "Home", path: "/" },
  { name: "Image Resizer", path: "/image-resizer" },
];

export function ImageResizer() {
  return (
    <>
      <Seo
        title="Free Image Resizer — Resize Photos to Any Size Online | ClearPix"
        description="Resize images online for free by pixels or percentage. Keep proportions, use presets for Instagram, YouTube, Facebook and product photos, then download the real resized file."
        path="/image-resizer"
        jsonLd={[breadcrumbSchema(BREADCRUMBS), webAppSchema()]}
      />
      <ContentPage
        breadcrumbs={BREADCRUMBS}
        title="Free Image Resizer — Exact Pixels, Real Output"
        intro={
          <>
            Set a width and height, type a percentage, or pick a preset for a social network or
            marketplace. ClearPix re-renders the image at the size you chose and exports that exact
            pixel grid — not a stretched preview.
          </>
        }
        related={[
          { label: "Open the image resizer", href: "/editor?tool=resize" },
          { label: "Crop an image", href: "/image-cropper" },
          { label: "Photo editor", href: "/photo-editor-online" },
          { label: "Transparent PNG maker", href: "/transparent-png" },
        ]}
      >
        <h2>Resize by pixels, percentage or preset</h2>
        <p>
          Pixel input is the precise option: type 1080 by 1080 and the exported file is exactly 1080 by
          1080. Percentage scaling is quicker when you just need something smaller or larger than the
          original. Presets cover the sizes people ask for most often, including 256×256, 512×512,
          1024×1024, 1080×1350, 1080×1920 and 1920×1080, plus Instagram post and story, YouTube
          thumbnail, Facebook post, profile picture, website banner and a 1000×1000 product image.
        </p>

        <h2>Lock the proportions or not</h2>
        <p>
          With the lock on, typing a width updates the height automatically so the photo does not
          distort. Turn it off when you deliberately need a different shape — the editor still draws the
          photo without stretching it, filling the canvas and keeping the centre of the image.
        </p>

        <h2>What resizing does to quality</h2>
        <p>
          Making an image smaller discards pixels, which is normally fine and reduces file size. Making
          it much larger cannot invent detail: the browser has to interpolate, so a 600-pixel photo
          enlarged to 3000 pixels will look soft. Start from the largest original you have, resize once,
          and export as PNG if the image has transparency or WEBP/JPEG for photographs.
        </p>

        <h2>Sensible limits</h2>
        <p>
          ClearPix accepts images up to 12,000 pixels on a side and blocks exports above 40 megapixels,
          because a canvas that large can exhaust memory on a phone. If you need a bigger master file,
          resize in two passes or work from a smaller crop.
        </p>

        <h2>Resize and keep the rest of your edits</h2>
        <p>
          Resizing is one step in the editor, not a separate tool that throws away your work. Remove the
          background, change it, add text, then resize for each platform and export a separate file.{" "}
          <Link to="/editor?tool=resize">Open the image resizer</Link> to try it on your own photo.
        </p>
      </ContentPage>
    </>
  );
}
