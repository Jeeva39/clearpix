import { Link } from "react-router-dom";
import { ContentPage } from "../components/ContentPage";
import { Seo, breadcrumbSchema } from "../components/Seo";

const BREADCRUMBS = [
  { name: "Home", path: "/" },
  { name: "Product Photo Background Remover", path: "/product-photo-background-remover" },
];

export function ProductPhoto() {
  return (
    <>
      <Seo
        title="Product Photo Background Remover for E-commerce | ClearPix"
        description="Remove backgrounds from product photos for free. Create clean white-background or transparent product images for Amazon, Etsy, Shopify and social media."
        path="/product-photo-background-remover"
        jsonLd={[breadcrumbSchema(BREADCRUMBS)]}
      />
      <ContentPage
        breadcrumbs={BREADCRUMBS}
        title="Product Photo Background Remover for Online Sellers"
        intro={
          <>
            Listings live and die by the first image. ClearPix turns a product photo taken on a
            table, carpet or doorstep into a clean cut-out you can place on white, brand colours or
            a transparent background — without a studio.
          </>
        }
        related={[
          { label: "Transparent PNG maker", href: "/transparent-png" },
          { label: "Remove background from an image", href: "/remove-background-from-image" },
          { label: "Remove a photo background", href: "/remove-background" },
          { label: "How to remove a background", href: "/how-to-remove-background" },
        ]}
      >
        <h2>Why marketplace photos need a clean background</h2>
        <p>
          Amazon, for example, requires the main product image to sit on a pure white background for
          most categories. Etsy rewards consistency across a shop, and a uniform background makes a
          grid of thumbnails look curated instead of cluttered. Even on your own store, a consistent
          background is one of the cheapest ways to look more established.
        </p>
        <p>
          Reshooting every item in a lightbox is slow and expensive, especially for a seller with
          dozens of SKUs. Background removal gives you the same presentation from ordinary photos: a
          cheap phone camera, a window and a clear table are enough.
        </p>

        <h2>A simple product photo workflow</h2>
        <ul>
          <li>
            <strong>Shoot plainly.</strong> Fill the frame with the product and keep the background
            uncluttered. A white sheet or a wooden table both work.
          </li>
          <li>
            <strong>Light evenly.</strong> Daylight from a window is ideal. Avoid harsh shadows that
            merge the product with the surface underneath.
          </li>
          <li>
            <strong>Remove the background.</strong> Upload the photo to ClearPix and let the AI
            separate the product. Shiny surfaces, glass and thin handles are the usual tricky cases
            — check the edges on the preview.
          </li>
          <li>
            <strong>Pick your output.</strong> Keep the transparent PNG for design work, or export a
            JPG with a pure white background for a marketplace that requires one.
          </li>
          <li>
            <strong>Keep the master file.</strong> Store the transparent PNG so future listings,
            ads and banners can reuse the same cut-out.
          </li>
        </ul>

        <h2>Batch a small catalogue</h2>
        <p>
          Upload up to five product photos at once, watch the status of each one, retry any that
          fail, and download the finished set as a ZIP. For a ten-item shop, that means two quick
          rounds instead of ten separate uploads.
        </p>

        <h2>Shadows, reflections and glass</h2>
        <p>
          The model separates the product from what is behind it, so a soft shadow cast on the table
          is usually removed with the background. That is what you want for a clean listing. If you
          rely on a natural shadow for realism, add it back in your design tool after placing the
          cut-out on a background. Reflective or transparent products are harder: a glass bottle may
          lose some of its subtle transparency, so review the result before publishing.
        </p>

        <h2>Consistent sizing across a catalogue</h2>
        <p>
          Transparency makes consistency easier. Export every product as a PNG, then place each
          cut-out on a canvas of the same dimensions in your design tool, with the same padding and
          background colour. The result is a grid where every item appears the same size and distance
          from the edge — the detail that separates a professional shop from a hobby listing.
        </p>
        <p>
          <Link to="/#tool">Remove the background from your first product photo</Link> — it is free
          and does not require an account.
        </p>
      </ContentPage>
    </>
  );
}
