import { Suspense, lazy, useEffect } from "react";
import { Route, Routes, useLocation } from "react-router-dom";
import { Header } from "./components/Header";
import { Footer } from "./components/Footer";
import { Home } from "./pages/Home";
import { initAnalytics } from "./lib/analytics";

const RemoveBackground = lazy(() =>
  import("./pages/RemoveBackground").then((module) => ({ default: module.RemoveBackground })),
);
const RemoveBackgroundFromImage = lazy(() =>
  import("./pages/RemoveBackgroundFromImage").then((module) => ({
    default: module.RemoveBackgroundFromImage,
  })),
);
const TransparentPng = lazy(() =>
  import("./pages/TransparentPng").then((module) => ({ default: module.TransparentPng })),
);
const ProductPhoto = lazy(() =>
  import("./pages/ProductPhoto").then((module) => ({ default: module.ProductPhoto })),
);
const FreeBackgroundRemover = lazy(() =>
  import("./pages/FreeBackgroundRemover").then((module) => ({
    default: module.FreeBackgroundRemover,
  })),
);
const HowToRemoveBackground = lazy(() =>
  import("./pages/HowToRemoveBackground").then((module) => ({
    default: module.HowToRemoveBackground,
  })),
);
const PrivacyPolicy = lazy(() =>
  import("./pages/PrivacyPolicy").then((module) => ({ default: module.PrivacyPolicy })),
);
const TermsOfUse = lazy(() =>
  import("./pages/TermsOfUse").then((module) => ({ default: module.TermsOfUse })),
);
const Contact = lazy(() =>
  import("./pages/Contact").then((module) => ({ default: module.Contact })),
);
const NotFound = lazy(() =>
  import("./pages/NotFound").then((module) => ({ default: module.NotFound })),
);
const BackgroundChanger = lazy(() =>
  import("./pages/BackgroundChanger").then((module) => ({ default: module.BackgroundChanger })),
);
const ImageResizer = lazy(() =>
  import("./pages/ImageResizer").then((module) => ({ default: module.ImageResizer })),
);
const ImageCropper = lazy(() =>
  import("./pages/ImageCropper").then((module) => ({ default: module.ImageCropper })),
);
const RotateImage = lazy(() =>
  import("./pages/RotateImage").then((module) => ({ default: module.RotateImage })),
);
const PhotoEditorOnline = lazy(() =>
  import("./pages/PhotoEditorOnline").then((module) => ({ default: module.PhotoEditorOnline })),
);
const EditorPage = lazy(() =>
  import("./editor/EditorPage").then((module) => ({ default: module.EditorPage })),
);

function ScrollManager() {
  const { pathname, hash } = useLocation();

  useEffect(() => {
    if (hash) {
      const target = document.getElementById(hash.replace("#", ""));
      if (target) {
        window.requestAnimationFrame(() =>
          target.scrollIntoView({ behavior: "smooth", block: "start" }),
        );
        return;
      }
    }
    window.scrollTo({ top: 0, left: 0, behavior: "auto" });
  }, [pathname, hash]);

  return null;
}

function RouteFallback() {
  return (
    <div className="container-page flex min-h-[50vh] items-center justify-center" role="status">
      <span className="h-8 w-8 animate-spin rounded-full border-2 border-brand-200 border-t-brand-600" />
      <span className="sr-only">Loading page</span>
    </div>
  );
}

export default function App() {
  const { pathname } = useLocation();
  const bareLayout = pathname.startsWith("/editor");

  useEffect(() => {
    initAnalytics();
  }, []);

  return (
    <div className="flex min-h-screen flex-col">
      <a
        href="#main-content"
        className="sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-3 focus:z-[60] focus:rounded-lg focus:bg-brand-600 focus:px-4 focus:py-2 focus:text-sm focus:font-semibold focus:text-white"
      >
        Skip to content
      </a>
      {!bareLayout && <Header />}
      <ScrollManager />
      <main id="main-content" className="flex-1">
        <Suspense fallback={<RouteFallback />}>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/remove-background" element={<RemoveBackground />} />
            <Route path="/remove-background-from-image" element={<RemoveBackgroundFromImage />} />
            <Route path="/transparent-png" element={<TransparentPng />} />
            <Route path="/product-photo-background-remover" element={<ProductPhoto />} />
            <Route path="/free-background-remover" element={<FreeBackgroundRemover />} />
            <Route path="/background-changer" element={<BackgroundChanger />} />
            <Route path="/image-resizer" element={<ImageResizer />} />
            <Route path="/image-cropper" element={<ImageCropper />} />
            <Route path="/rotate-image" element={<RotateImage />} />
            <Route path="/photo-editor-online" element={<PhotoEditorOnline />} />
            <Route path="/editor" element={<EditorPage />} />
            <Route path="/how-to-remove-background" element={<HowToRemoveBackground />} />
            <Route path="/privacy-policy" element={<PrivacyPolicy />} />
            <Route path="/terms-of-use" element={<TermsOfUse />} />
            <Route path="/contact" element={<Contact />} />
            <Route path="*" element={<NotFound />} />
          </Routes>
        </Suspense>
      </main>
      {!bareLayout && <Footer />}
    </div>
  );
}
