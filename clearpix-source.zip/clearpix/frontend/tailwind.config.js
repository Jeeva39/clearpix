/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        ink: {
          DEFAULT: "#1c1c28",
          soft: "#3f3f52",
          muted: "#6b6b80",
        },
        brand: {
          50: "#f2f1ff",
          100: "#e8e6ff",
          200: "#d4d0ff",
          300: "#b5adff",
          400: "#9284ff",
          500: "#7a63f6",
          600: "#6b46e5",
          700: "#5a37c9",
          800: "#4a2fa3",
          900: "#3e2b80",
        },
        mist: "#f7f7fb",
      },
      fontFamily: {
        sans: [
          "Inter",
          "ui-sans-serif",
          "system-ui",
          "-apple-system",
          "Segoe UI",
          "Roboto",
          "Helvetica Neue",
          "Arial",
          "sans-serif",
        ],
      },
      boxShadow: {
        soft: "0 1px 2px rgba(28, 28, 40, 0.04), 0 8px 24px -12px rgba(28, 28, 40, 0.12)",
        card: "0 1px 3px rgba(28, 28, 40, 0.05), 0 20px 48px -24px rgba(28, 28, 40, 0.18)",
        lift: "0 2px 6px rgba(28, 28, 40, 0.06), 0 28px 60px -28px rgba(90, 55, 201, 0.35)",
      },
      borderRadius: {
        xl2: "1.25rem",
      },
      maxWidth: {
        content: "72rem",
      },
      keyframes: {
        "fade-up": {
          from: { opacity: "0", transform: "translateY(10px)" },
          to: { opacity: "1", transform: "translateY(0)" },
        },
        shimmer: {
          "100%": { transform: "translateX(100%)" },
        },
        float: {
          "0%, 100%": { transform: "translateY(0)" },
          "50%": { transform: "translateY(-8px)" },
        },
      },
      animation: {
        "fade-up": "fade-up 0.5s ease-out both",
        shimmer: "shimmer 1.8s infinite",
        float: "float 6s ease-in-out infinite",
      },
    },
  },
  plugins: [],
};
