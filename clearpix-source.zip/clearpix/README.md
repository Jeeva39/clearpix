# ClearPix

**Free AI background remover and online photo editor** — upload an image, let a real segmentation model isolate the subject, then change the background, resize, crop, add text and export a real PNG, JPEG or WEBP. No account, no watermark, batch processing included.

- Tagline: *Remove backgrounds instantly. Create something amazing.*
- Frontend: React + TypeScript + Vite + Tailwind CSS
- Backend: Python + FastAPI + [rembg](https://github.com/danielgatis/rembg) (U²-Net ONNX models)
- Routes: `/` (landing + batch remover), `/editor` (full editing workspace), 9 SEO pages

This is a working application, not a mock: `POST /api/remove-background` runs a real U²-Net model on the uploaded pixels and returns an RGBA PNG, and every editor control changes the canvas and the exported file.

---

## Quick start

### 1. Backend (FastAPI + rembg)

```bash
cd backend
python3 -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python download_model.py u2net     # optional warm-up, downloads ~176 MB once
uvicorn main:app --reload --port 8000
```

The API is available at <http://localhost:8000>, interactive docs at <http://localhost:8000/api/docs>.

Model files are cached in `~/.rembg/models`. The first request also triggers the download automatically if the warm-up step was skipped.

### 2. Frontend (Vite)

```bash
cd frontend
npm install
cp .env.example .env
npm run dev
```

Open <http://localhost:5173>. The Vite dev server proxies `/api` to `http://127.0.0.1:8000`, so no CORS setup is needed in development. The editing workspace is at <http://localhost:5173/editor>.

If you open the frontend on a non-default port (for example 3000), add that origin to the backend's `ALLOWED_ORIGINS` — the API rejects unknown browser origins by design.

---

## Environment variables

### Frontend (`frontend/.env`)

| Variable | Purpose |
| --- | --- |
| `VITE_SITE_URL` | Production domain. Used for canonical URLs, Open Graph tags and the generated sitemap. |
| `VITE_API_BASE_URL` | Backend origin. Leave empty when the API is on the same origin (proxy). `frontend/public/config.js` can override it at runtime without a rebuild. |
| `VITE_CONTACT_EMAIL` | Address used by the contact form's `mailto:` fallback. |
| `VITE_CONTACT_ENDPOINT` | Optional POST endpoint for the contact form (e.g. Formspree). |
| `VITE_GA_MEASUREMENT_ID` | Optional GA4 ID (`G-XXXXXXXXXX`). Analytics never loads without it. |
| `VITE_ADSENSE_CLIENT` | Optional AdSense publisher ID (`ca-pub-...`). Ad slots stay hidden without it. |
| `VITE_GOOGLE_SITE_VERIFICATION` | Optional Search Console verification token. |

Only `VITE_*` values reach the browser. Never put secrets in them.

### Backend (`backend/.env` or platform environment)

| Variable | Default | Purpose |
| --- | --- | --- |
| `ALLOWED_ORIGINS` | localhost and 127.0.0.1 on ports 3000/4173/5173/8000/8080 | Comma-separated CORS allowlist. **Add your deployed frontend origin.** |
| `ALLOWED_ORIGIN_REGEX` | `https?://([a-z0-9-]+\.)*style\.dev` | Optional regex for extra allowed origins. Empty disables it (the default). |
| `MAX_UPLOAD_BYTES` | `10485760` | 10 MB upload cap. |
| `MAX_BATCH_IMAGES` | `5` | Maximum images per batch request. |
| `MAX_IMAGE_PIXELS` | `40000000` | Decompression-bomb guard. |
| `MAX_IMAGE_DIMENSION` | `12000` | Maximum width/height in pixels. |
| `PROCESS_TIMEOUT_SECONDS` | `180` | Per-image processing timeout. |
| `MAX_CONCURRENT_JOBS` | `2` | Concurrent model runs per worker (CPU-bound). |
| `REMBG_MODEL` | `u2net` | General segmentation model. |
| `REMBG_PORTRAIT_MODEL` | `u2net_human_seg` | Model used when the client requests `mode=portrait`. |
| `RATE_LIMIT_REQUESTS` / `RATE_LIMIT_WINDOW_SECONDS` | `20` / `600` | In-memory rate limit per IP. |
| `TEMP_DIR` | system temp | Where per-request temporary directories are created. |
| `LOG_LEVEL` | `INFO` | Logging level. |

---

## Image editor (`/editor`)

The editor is a client-side canvas workspace. Everything except background removal runs in the browser; only the cut-out request touches the API.

| Area | What works |
| --- | --- |
| Upload | Click, drag and drop, clipboard paste (Ctrl/⌘+V), mobile file picker, replace, remove. The local preview appears immediately. |
| Background | Real AI cut-out (general or people model), retry, original/cut-out toggle, transparent, solid colour, two/three-stop gradients, preset scenes, uploaded background images with fit/cover, subject scale and position. |
| Geometry | Resize by pixels or percentage with 14 presets, crop with 8 ratio locks and a draggable box, rotate 90° left/right/180°, straighten ±45°, flip H/V. |
| Colour | Brightness, contrast, saturation, exposure, temperature, tint, highlights, shadows, sharpness, blur, opacity, plus 19 filters with an intensity slider. Applied pixel-by-pixel to the photo layer and baked into exports. |
| Overlays | Text layers (font, size, bold, italic, alignment, line/letter spacing, colour, opacity, shadow, outline), 5 shapes with fill/border/width, 17 stickers in 6 categories, layer list with visibility, lock, rename, reorder and delete. |
| Effects | Drop shadow (blur, opacity, distance, angle, colour) and outline around the cut-out subject. |
| History | Undo/redo for every edit, coalesced slider history, reset to the original. Shortcuts: Ctrl/⌘+Z, Ctrl/⌘+Shift+Z, Ctrl/⌘+S, Delete, Esc. |
| Export | PNG (keeps transparency), JPEG (flattens onto a chosen colour), WEBP with quality, custom dimensions, filename. Downloads the composed canvas at full resolution. |
| Projects | Save and reopen a `.clearpix.json` file containing the original image, the cut-out, every layer and all settings. Stored locally; nothing is uploaded. |
| Batch | The homepage batch tool (up to 5 images, queue of 2, retry, ZIP) is also available inside the editor. |

Design notes:

- The preview is capped at 1700 px for responsiveness; exports render at the document's real dimensions (blocked above 40 megapixels).
- History stores serialisable state, not image copies, so large photos do not multiply memory use.
- The cut-out is a separate layer, so background, subject effects and export transparency stay independent.
- Rotate, flip and straighten are applied to the cut-out as well as the photo.

---

## API

Base URL: `https://your-api-host` (development: `http://localhost:8000`).

### `GET /api/health`

```json
{ "status": "ok", "service": "clearpix-api", "model": "u2net", "model_loaded": true,
  "max_upload_mb": 10.0, "max_batch_images": 5, "max_concurrent_jobs": 2 }
```

### `POST /api/remove-background`

Multipart form:

| Field | Type | Required | Notes |
| --- | --- | --- | --- |
| `image` | file | yes | JPG, JPEG, PNG or WEBP, ≤ 10 MB |
| `mode` | string | no | `general` (default) or `portrait` |
| `alpha_matting` | boolean | no | Extra edge refinement, slower |

Returns `image/png` with a transparent background. Response headers include `X-Processing-Ms` and `Cache-Control: no-store`.

```bash
curl -o result.png -F "image=@photo.jpg" http://localhost:8000/api/remove-background
```

### `POST /api/remove-background-batch`

Multipart form with repeated `images` fields (max 5) and optional `mode`. Returns a ZIP with one PNG per successful image plus `errors.txt` when some items failed. Partial results are returned with the failures listed rather than failing the whole request.

### `POST /api/zip`

Bundles already-processed PNGs into a ZIP without re-running the model. Fields: repeated `images` files, optional comma-separated `filenames`. Used by the "Download all (ZIP)" action.

### Error format

```json
{ "error": { "code": "file_too_large", "message": "Your image is too large. Please upload an image smaller than 10 MB." } }
```

| Status | Codes |
| --- | --- |
| 400 | `empty_file`, `no_files` |
| 413 | `file_too_large` |
| 415 | `unsupported_type`, `invalid_image` |
| 422 | `image_too_small`, `image_dimensions_too_large`, `invalid_mode`, `too_many_files`, `batch_failed` |
| 429 | `rate_limited` (with `Retry-After`) |
| 503 | `server_busy`, `model_unavailable` |
| 504 | `processing_timeout` |
| 500 | `processing_failed` |

Validation is content-based: the server decodes the file and checks its actual format, dimensions and integrity, never trusting the extension or the declared MIME type alone. Stack traces are logged server-side and never returned to clients.

### Processing and cleanup

Each request gets a private temp directory (`tempfile.mkdtemp`) that is deleted in a `finally` block. Images are decoded with Pillow, EXIF orientation is applied, and the result is encoded as an optimised PNG. Concurrency is capped by a semaphore; excess requests wait up to 30 seconds, then receive `503 server_busy`.

---

## Project structure

```
frontend/
  index.html                 Base metadata, fonts, favicon
  public/                    robots.txt, sitemap.xml, OG image, demo illustrations
  scripts/generate-seo.mjs   Generates robots.txt + sitemap.xml from VITE_SITE_URL
  src/
    components/              Header, Footer, Seo (Helmet + JSON-LD), CompareSlider, …
    features/home/           Hero, HowItWorks, Features, UseCases, SEOContent, Faq
    features/tool/           Upload zone, processing queue, results editor, batch list
    editor/                  Editing workspace: model/reducer, presets, canvas renderer,
                             workspace hook, toolbar, panels, interactive canvas stage
    lib/                     API client, analytics, validation, site config, hooks
    pages/                   Home + 9 SEO pages + guide, privacy, terms, contact, 404
backend/
  main.py                    FastAPI app, validation, rate limiting, rembg pipeline
  download_model.py          Model warm-up helper
  requirements.txt           Pinned dependencies
```

---

## SEO

- Unique `<title>`, meta description and canonical URL on every route (`react-helmet-async`).
- Open Graph and Twitter Card metadata with a 1200×630 social image.
- One `<h1>` per page, semantic sections, breadcrumbs, descriptive alt text, internal linking.
- JSON-LD: `WebSite`, `SoftwareApplication`, `FAQPage` (matching the visible FAQ), `BreadcrumbList`.
- `robots.txt` allows all public pages and blocks `/api/`; `sitemap.xml` lists every public route.
- Both files are regenerated at build time from `VITE_SITE_URL`:

```bash
cd frontend
VITE_SITE_URL=https://<your-frontend-domain> npm run build
```

### Google Search Console

1. Deploy the site and confirm it loads on your domain.
2. Add a **Domain** property (DNS verification) or a **URL prefix** property.
3. For URL-prefix verification with the HTML tag method, set `VITE_GOOGLE_SITE_VERIFICATION` to the token and redeploy. A verification HTML file placed in `frontend/public/` works too.
4. Submit `https://<your-frontend-domain>/sitemap.xml` under **Sitemaps**.
5. Use **URL Inspection** on `/` and each SEO page, then **Request indexing**.
6. Indexing and ranking are decided by Google; nothing here guarantees placement or timing.

Because the frontend is a single-page app, rich metadata is applied client-side. Google renders JavaScript and indexes these routes, but for maximum reliability across crawlers you can prerender at deploy time — the routes are static and the content is present in the bundle.

---

## Deployment

The site is live at **https://clearpix-peach.vercel.app** (Vercel Hobby, free). It is a static build and needs no server.

### How background removal runs

The website ships its own AI model: `frontend/public/models/u2netp.onnx` (4.4 MB) runs in the visitor's browser through `onnxruntime-web` inside a Web Worker. Images never leave the device, there is no API to keep awake and nothing to pay for. The first run of a tool downloads the model plus the ~12 MB WASM runtime once; the browser caches both, and later images are processed from cache.

`backend/` is optional. It keeps the full-size `u2net` model for anyone who prefers server-side processing: set `VITE_API_BASE_URL` to that API's origin at build time and the app uses it instead of the in-browser engine.

### Frontend deployment checklist (the deployed site)

1. Set `VITE_SITE_URL` to the final public origin. It is the only source for canonical URLs, Open Graph URLs, `sitemap.xml` and the `Sitemap:` line in `robots.txt`.
2. Build with `npm ci && npm run build` and publish `dist/`. The build verifies (and downloads if missing) the AI model, then typechecks and bundles the app.
3. Leave `VITE_API_BASE_URL` empty. That is what selects the in-browser engine; setting it points the app at the Python API instead.
4. SPA routing: `vercel.json` (Vercel) and `public/_redirects` (Netlify) are included. On nginx use `try_files $uri /index.html;`. The rewrite must not swallow files with extensions.
5. Confirm `dist/sitemap.xml` contains 16 absolute URLs and `dist/robots.txt` ends with the `Sitemap:` line.
6. Confirm `dist/models/u2netp.onnx` and the `dist/assets/*.wasm` runtime are served with `Content-Type: application/wasm` for the `.wasm` file.
7. After deploying, load `/`, `/editor` and one SEO page, then remove the background from one real image and download the PNG.

### Python backend deployment checklist (optional)

1. Create a Python 3.11+ service and set the root directory to `backend`.
2. Build command: `pip install -r requirements.txt`.
3. Start command: `uvicorn main:app --host 0.0.0.0 --port $PORT` (use the port your host injects).
4. Choose at least ~1 GB RAM. The ONNX model uses roughly 300–500 MB, and CPU inference takes a few seconds per image.
5. Warm the model at deploy time (`python download_model.py u2net`) or mount a persistent disk for `~/.rembg/models`; otherwise the first request downloads ~176 MB.
6. Set the environment variables below in the host's dashboard (or a `backend/.env` file). `backend/.env.example` lists the same names.
7. Set `ALLOWED_ORIGINS` to the exact deployed frontend origin(s), with no trailing slash. Leave `ALLOWED_ORIGIN_REGEX` empty so only that allowlist is accepted.
8. Deploy, then check `GET /api/health` returns `"status": "ok"` and `model_loaded: true`.
9. Send an `OPTIONS` preflight from the deployed frontend origin and confirm `200` with `access-control-allow-origin` echoing that origin; confirm a different origin gets `400` with no CORS header.
10. Upload one real image through `POST /api/remove-background` and confirm a transparent PNG comes back.

Backend environment variables:

| Variable | Required | Notes |
| --- | --- | --- |
| `ALLOWED_ORIGINS` | Yes in production | Comma-separated frontend origins. Defaults to localhost ports only. |
| `ALLOWED_ORIGIN_REGEX` | No | Leave empty. Only for pattern-matched preview hosts. |
| `MAX_UPLOAD_BYTES` | No | Default `10485760` (10 MB). |
| `MAX_BATCH_IMAGES` | No | Default `5`. |
| `MAX_IMAGE_PIXELS` | No | Default `40000000`. |
| `MAX_IMAGE_DIMENSION` | No | Default `12000`. |
| `PROCESS_TIMEOUT_SECONDS` | No | Default `180`. |
| `MAX_CONCURRENT_JOBS` | No | Default `2`. |
| `REMBG_MODEL` | No | Default `u2net`. |
| `REMBG_PORTRAIT_MODEL` | No | Default `u2net_human_seg`. |
| `RATE_LIMIT_REQUESTS` / `RATE_LIMIT_WINDOW_SECONDS` | No | Default `20` per `600` s, per IP. |
| `TEMP_DIR` | No | Defaults to the system temp directory. |
| `LOG_LEVEL` | No | Default `INFO`. |

The backend needs Python and the native ONNX runtime, so it cannot run on static-only hosting or Cloudflare Workers. A `Dockerfile` is included:

```bash
docker build -t clearpix-api ./backend
docker run -p 8000:8000 -e ALLOWED_ORIGINS=https://<your-frontend-domain> clearpix-api
```

Free tiers usually sleep when idle, so the first request after a sleep is slower and may need a retry.

If you do deploy it, add the frontend origin to the backend's `ALLOWED_ORIGINS` and set `VITE_API_BASE_URL` in the frontend build.

Frontend environment variables (build time, all public):

| Variable | Required | Notes |
| --- | --- | --- |
| `VITE_SITE_URL` | Yes | Public origin, no trailing slash. Without it `sitemap.xml` is skipped and `robots.txt` has no `Sitemap:` line. |
| `VITE_API_BASE_URL` | No | Empty (recommended) runs the AI in the browser. Set it to a deployed Python API to use the server engine instead. |
| `VITE_CONTACT_EMAIL` | No | Shown on the contact page. |
| `VITE_CONTACT_ENDPOINT` | No | JSON endpoint for contact submissions. |
| `VITE_GA_MEASUREMENT_ID` | No | `G-XXXXXXXXXX`; analytics stays off without it. |
| `VITE_ADSENSE_CLIENT` | No | `ca-pub-...`; ad slots stay hidden without it. |
| `VITE_GOOGLE_SITE_VERIFICATION` | No | Search Console HTML-tag token. |

Never put secrets in `VITE_*` variables: they are compiled into the public bundle. `frontend/public/config.js` can override the API base URL at runtime without a rebuild.

---

## Analytics and ads (optional)

- GA4 loads only when `VITE_GA_MEASUREMENT_ID` matches `G-XXXXXXXXXX`. Events: `upload_started`, `background_removal_completed`, `download_completed`, `batch_processing_started`, `error_occurred`. No filenames, image data or personal details are sent.
- AdSense slots render only when `VITE_ADSENSE_CLIENT` is set. They sit below the tool, between content sections and above the footer — never inside the upload, processing or download flow. There are no placeholder or fake ads.

---

## Privacy and security behaviour

- No login, no accounts, no image history.
- Uploads are written to a per-request temp directory and deleted immediately after the response.
- Content-based validation (real format, dimensions, decode check), 10 MB limit, pixel-count guard.
- In-memory per-IP rate limiting (per process; use a shared store such as Redis if you run multiple workers behind one host).
- Per-image processing timeout and a concurrency semaphore to avoid overload.
- Errors are user-friendly; no stack traces are exposed.
- CORS is an explicit allowlist from `ALLOWED_ORIGINS`; pattern matching is off unless you set `ALLOWED_ORIGIN_REGEX`. There is no wildcard origin.
- The Privacy Policy describes exactly this behaviour; update it if you change the implementation.

---

## Verification performed

This is what was actually executed in a real Chromium session and against the running FastAPI process, not a claim of deployment.

**Upload and API**

- File picker, drag-and-drop and clipboard paste all loaded the image (500×400 drop, 640×480 paste, 1200×1600 picker). Replace loaded new dimensions each time.
- `POST /api/remove-background`: 200, `image/png`, RGBA, alpha 0 in the background and 255 on the subject.
- Failure path: an aborted request showed a readable network message and a Retry button; Retry then completed and returned a transparent cut-out.
- Validation: fake `.png` text file → 415, GIF → 415, 11 MB upload → 413, 8×8 image → 422, missing file → 422.
- `GET /api/health` → 200; `/api/docs` and `/api/openapi.json` → 200; unknown route → 404; GET on a POST route → 405.
- Batch: two images queued and processed, `clearpix-results.zip` contained two valid transparent PNGs named `clearpix-01-…` and `clearpix-02-…`.

**CORS**

- Preflight from `http://localhost:3000` → 200 with `access-control-allow-origin` echoing the origin.
- Preflight from `https://evil.example.net` → 400 with no CORS header.
- With the new default, pattern matching is off unless `ALLOWED_ORIGIN_REGEX` is set, so the allowlist is the only source of truth.

**Editor**

- Background: solid `#22c55e` exported exactly `[34,197,94]`; gradient sampled differently top and bottom; preset scenes and an uploaded background image (solid `[220,20,60]` returned at the corner) both rendered; subject position buttons moved the cut-out; drop shadow and outline changed the composed pixels.
- Geometry: resize preset 512×512, aspect-locked width 800 → 800×800, 16:9 crop → 800×450, rotate 90° → 450×800, flip and straighten ± changed pixels.
- Undo/redo: brightness 20 → 40 → 60, three undos returned 40 → 20 → 0, redo returned 20. No history entry is lost or duplicated.
- Layers: add, hide (pixels changed), show (pixels restored), reorder, delete; text content and outline rendered; shapes rendered.
- Stickers: this audit found that sticker layers stored a preset id while the image cache was keyed by asset URL, so stickers never drew. Fixed; a gold star now exports with 862 matching gold samples.
- Export: PNG RGBA with alpha 0 (transparency preserved), JPEG RGB flattened to white at the same dimensions, WEBP RGBA with transparency preserved and quality affecting size (28,886 bytes at 30% vs 45,910 bytes at 95%).
- Project files: saved and reopened `.clearpix.json` with layers intact (verified in an earlier session), filenames are `clearpix-edited-image.*`.
- Performance and memory: a 6000×4000 JPEG (3.1 MB) loaded in ~5.0 s, exported a full-resolution PNG in ~2.3 s; after six loads the JS heap was 35 MB with no canvas or console errors; object URLs were created 16 times and revoked 19 times, so nothing was left dangling.

**SEO and links**

- All 16 public routes returned 200 in the browser with one `<h1>`, a canonical URL equal to the visited URL, `robots: index, follow`, a meta description, JSON-LD (`WebSite`, `SoftwareApplication`, `FAQPage`, `BreadcrumbList`) and no image without `alt`.
- An unknown route rendered the 404 page with `robots: noindex, follow`.
- 15 unique internal links across six pages were collected and none pointed to a missing route.

**Accessibility and responsiveness**

- `/` and `/remove-background` at 360, 768 and 1440 px: zero horizontal overflow, no unnamed buttons, no unlabeled inputs, one `<h1>`.
- Editor at 360 px: upload, canvas and tool sheet work with zero overflow. The mobile Export button had no accessible name because its label is hidden below 640 px; fixed with an explicit `aria-label`. The editor workspace also now exposes a single screen-reader heading, and its hidden file inputs are labeled.
- Known gap: some inline text links and footer links are shorter than the 44 px touch-target guideline (28 px minimum measured). They are links, not buttons, and remain usable.

**Build**

- `npx tsc --noEmit` and `npm run build` pass. The sitemap is generated only when `VITE_SITE_URL` is set; without it the generator removes any stale `sitemap.xml` and writes `robots.txt` without a `Sitemap:` line.

### Not verified

- No physical Android or iOS device and no Safari were available. Mobile behaviour was tested with Chromium device emulation at a 360 px viewport, not on real hardware.
- The public deployment was verified in a real browser: a 1200×1600 photo was uploaded on `https://clearpix-peach.vercel.app`, the in-browser model produced an RGBA PNG with 1,533,853 transparent pixels, and "Download Transparent PNG" saved a 132 KB PNG. No `/api` request was made at any point. Safari, Firefox and real phones were not tested.
- Sticker/font combinations were not checked exhaustively, and the visual quality of the AI edges was not judged on hard photos (hair, glass).
- Keyboard-only navigation was checked only for focusable controls and names, not for a full tab-order and screen-reader pass.

## Limitations

- U²-Net is strong on general subjects but not perfect on very low-contrast edges, fine hair or transparent objects; expect occasional manual touch-ups.
- In-memory rate limiting is per process.
- Batch processing is capped at 5 images per request by design.
- Single-page app metadata is applied client-side (see SEO note above).
